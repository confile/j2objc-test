package majestella.core.bootstrap;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import majestella.core.app.database.AppDatabaseHelper;
import majestella.core.app.hotelRestaurant.HotelRestaurantPresenter;
import majestella.core.app.hotelSpa.HotelSpaPresenter;
import majestella.core.app.locationInfo.LocationInfoPresenter;
import majestella.core.app.locationMain.LocationMainPresenter;
import majestella.core.app.locationSetting.LocationSettingPresenter;
import majestella.core.app.mainNavigation.MainNavigationPresenter;
import majestella.core.app.roomService.RoomServicePresenter;
import majestella.core.app.roomServiceCard.RoomServiceCardPresenter;
import majestella.core.app.serviceDetails.ServiceDetailsPresenter;
import majestella.core.app.serviceSelection.ServiceSelectionPresenter;
import majestella.core.app.setting.SettingPresenter;
import majestella.core.app.start.StartPresenter;
import majestella.core.app.wishList.WishListPresenter;
import majestella.core.dagger.ApplicationComponent;
import majestella.core.dagger.ComponentHolder;
import majestella.core.dagger.EagerSingletons;
import majestella.core.i18n.BMessage;
import majestella.core.i18n.MessageKey;
import majestella.core.navigation.BRootPresenter;
import majestella.core.place.NameTokens;
import majestella.core.plugins.AbstractPluginAdapter;
import majestella.core.plugins.BPluginType;
import majestella.core.plugins.PluginAdapterHolder;
import majestella.core.plugins.appInfo.AppInfo;
import majestella.core.plugins.cookie.Cookie;
import majestella.core.plugins.inappbrowser.Inappbrowser;
import majestella.core.plugins.notification.ConfirmCallback;
import majestella.core.plugins.notification.Notification;
import majestella.core.plugins.uniqueDeviceId.UniqueDeviceId;
import majestella.core.prototype.eventBus.BEventBus;
import majestella.core.prototype.mvp.AppViewType;
import majestella.core.prototype.mvp.BBaseView;
import majestella.core.prototype.mvp.PresenterHolder;
import majestella.core.prototype.mvp.proxy.BAsyncCallback;
import majestella.core.prototype.navigation.BPlaceManager;
import majestella.core.prototype.navigation.BPlaceRequest;
import majestella.core.rest.SessionStartRestService;
import majestella.core.rest.dto.DeviceDto;
import majestella.core.rest.dto.GetResult;
import majestella.core.rest.dto.SessionStartResultDto;

import com.google.common.base.Strings;

import core.helper.timer.BTimer;
import core.helper.timer.BTimerCallback;

/**
 * EntryPoint class of the application.
 * 
 * @author Dr. Michael Gorski
 *
 */
public final class AppStarter { // implements LoginResponseHandler {

  private boolean isInitialize = false;
  private boolean isStarted = false;
  private Map<AppViewType, ViewFactory> viewFactoryMap = new HashMap<>();
//  private DeviceEvents deviceEvents;
  
  private final BEventBus eventBus;
  private final BPlaceManager placeManager;
  private final Logger logger;
  private BRootPresenter rootPresenter;
  private EagerSingletons eagerSingletons;
  private final ApplicationComponent component;
  private final DeviceDto deviceDto;
  private final AppInfo appInfo;
  private final Cookie cookie;
  private final CurrentUser currentUser;
  
  private AppStarter(Map<AppViewType, ViewFactory> viewMap) {
    logger = Logger.getLogger(ParameterConfig.LOGGER_MAJESTELLA_NAME);
    logger.info("AppStarter() before create"); 
    component = ComponentHolder.get();
    eventBus = component.getEventBus();
    placeManager = component.getBPlaceManager();
    this.viewFactoryMap = viewMap;
    this.deviceDto = component.getDeviceDto();
    this.currentUser = component.getCurrentUser();
    this.appInfo = component.getAppInfo();
    this.cookie = component.getCookie();
    
    rootPresenter = component.getBRootPresenter();
    eagerSingletons = new EagerSingletons();  
    PresenterHolder.getInstance();
    
//    eventBus.addHandler(PageRevealedEvent.getType(), this);
//    eventBus.addHandler(LoginResponseEvent.getType(), this);
    
    enableDeviceEvents();
    setDeviceInfo();
    logger.info("AppStarter() after create"); 
  }

  
  private void setDeviceInfo() {
    logger.info("AppStarter - setDeviceInfo()");
    UniqueDeviceId uniqueDeviceId = component.getUniqueDeviceId();
    final AppDatabaseHelper appDatabaseHelper = component.getAppDatabaseHelper();
        
    deviceDto.setUuid(uniqueDeviceId.getUUID());
    logger.info("AppStarter - setDeviceInfo(): getUUID: "+deviceDto.getUuid());
    
    deviceDto.setPlatform(appInfo.getPlatform());
    deviceDto.setModel(appInfo.getModel());
    deviceDto.setVersion(appInfo.getOSVersion());
    deviceDto.setLocale(appInfo.getLocale());
    deviceDto.setAppVersion(appInfo.getAppVersion());
    logger.info("AppStarter - setDeviceInfo(): app version: "+deviceDto.getAppVersion());
    deviceDto.setClientWidth(appInfo.getClientWidth() * appInfo.getPixelRatio());
    deviceDto.setClientHeight(appInfo.getClientHeight() * appInfo.getPixelRatio());
    deviceDto.setPixelRatio(appInfo.getPixelRatio());
  }
  
  
  private void enableDeviceEvents() {
    logger.info("AppStarter - enableDeviceEvents()");
//    deviceEvents = component.getDeviceEvents();
//    
//    deviceEvents.setOfflineHandler(new DeviceEventCallback() {
//      
//      @Override
//      public void onEvent() {
//        eventBus.fireEvent(new ConnectionChangedEvent(ConnectionType.OFFLINE));
//      }
//    });
//    
//    deviceEvents.setOnlineHandler(new DeviceEventCallback() {
//      
//      @Override
//      public void onEvent() {
//        eventBus.fireEvent(new ConnectionChangedEvent(ConnectionType.ONLINE));
//      }
//    });
//    
//    deviceEvents.setPauseHandler(new DeviceEventCallback() {
//      
//      @Override
//      public void onEvent() {
//        eventBus.fireEvent(new DevicePausedEvent());
//      }
//    });
//    
//    deviceEvents.setResumeHandler(new DeviceEventCallback() {
//      
//      @Override
//      public void onEvent() {
//        eventBus.fireEvent(new DeviceResumedEvent());
//      }
//    });    
  }
  

  public void start() {
    logger.info("AppStarter - start()");
    
    if (!isStarted) {
      isStarted = true;
      bootstrap();  
      
      // the authentication should run after the user page has been revealed the first time
      BTimer timer = new BTimer();
      timer.setRun(new BTimerCallback() {
        
        @Override
        public void run() {
          // check if the user is logged in
          tryToAuthenticateUser();
        }
      });
      timer.schedule(10);
    }
  }
  
  
  private BBaseView getBaseView(AppViewType type) {
    ViewFactory viewFactory = viewFactoryMap.get(type);
    if (viewFactory == null) {
      throw new NullPointerException("AppStarter - getView() with name "+type+" is not available!");
    }
    return viewFactory.getView();
  }
  
  private void bootstrap() {
    logger.info("AppStarter - bootstrap()");
  
    rootPresenter.init();

    // create PresenterWidgets
  
 
    // create the Presenters
      
    BBaseView startView = getBaseView(AppViewType.START); 
    PresenterHolder.getInstance().add(StartPresenter.class, component.getStartPresenterFactory().create(startView));
    
    BBaseView  mainNavigationView = getBaseView(AppViewType.MAIN_NAVIGATION); 
    PresenterHolder.getInstance()
    	.add(MainNavigationPresenter.class, component.getMainNavigationPresenterFactory().create(mainNavigationView));
    
    BBaseView serviceSelectionView = getBaseView(AppViewType.SERVICE_SELECTION);
    PresenterHolder.getInstance()
    	.add(ServiceSelectionPresenter.class, component.getServiceSelectionPresenterFactory().create(serviceSelectionView));
    
    BBaseView locationMainView = getBaseView(AppViewType.LOCATION_MAIN);
    PresenterHolder.getInstance()
		.add(LocationMainPresenter.class, component.getLocationMainPresenterFactory().create(locationMainView));
    
    BBaseView wishListView = getBaseView(AppViewType.WISH_LIST);
    PresenterHolder.getInstance()
		.add(WishListPresenter.class, component.getWishListPresenterPresenterFactory().create(wishListView));
    
    BBaseView locationSettingView = getBaseView(AppViewType.LOCATION_SETTING);
    PresenterHolder.getInstance()
    	.add(LocationSettingPresenter.class, component.getLocationSettingPresenterFactory().create(locationSettingView));
    
    BBaseView locationInfoView = getBaseView(AppViewType.LOCATION_INFO);
    PresenterHolder.getInstance()
      .add(LocationInfoPresenter.class, component.getLocationInfoPresenterFactory().create(locationInfoView));
    
    BBaseView serviceDetailsView = getBaseView(AppViewType.SERVICE_DETAILS);
    PresenterHolder.getInstance()
      .add(ServiceDetailsPresenter.class, component.getServiceDetailsPresenterFactory().create(serviceDetailsView));
    
    BBaseView roomServiceView = getBaseView(AppViewType.ROOM_SERVICE);
    PresenterHolder.getInstance()
      .add(RoomServicePresenter.class, component.getRoomServicePresenterFactory().create(roomServiceView));
    
    BBaseView roomServiceCardView = getBaseView(AppViewType.ROOM_SERVICE_CARD);
    PresenterHolder.getInstance()
      .add(RoomServiceCardPresenter.class, component.getRoomServiceCardPresenterFactory().create(roomServiceCardView));
    
    BBaseView hotelRestaurantView = getBaseView(AppViewType.HOTEL_RESTAURANT);
    PresenterHolder.getInstance()
      .add(HotelRestaurantPresenter.class, component.getHotelRestaurantPresenterFactory().create(hotelRestaurantView));
    
    BBaseView hotelSpaView = getBaseView(AppViewType.HOTEL_SPA);
    PresenterHolder.getInstance()
      .add(HotelSpaPresenter.class, component.getHotelSpaPresenterFactory().create(hotelSpaView));
    
    BBaseView settingView = getBaseView(AppViewType.SETTING);
    PresenterHolder.getInstance()
      .add(SettingPresenter.class, component.getSettingPresenterFactory().create(settingView));
    
    
//    placeManager.revealCurrentPlace();
    
    // TODO for testing
    BPlaceRequest request = new BPlaceRequest.Builder()
      .nameToken(NameTokens.start)
      .build();
    placeManager.revealPlace(request);
    
    // register device
    callServerSessionStartAction();

    logger.info("AppStarter - bootstrap() finished");
  }

  
  public static final class Builder {
    
    private Map<AppViewType, ViewFactory> viewMap = new HashMap<>();
    private final ApplicationComponent component;
    private final Logger logger;
    
    public Builder() {
      component = ComponentHolder.get();
      logger = Logger.getLogger(ParameterConfig.LOGGER_MAJESTELLA_NAME);
   
      logger.info("AppStarter_Builder - init() warning");
    }
    
    
    public Builder registerView(AppViewType type, ViewFactory viewFactory) {
      this.viewMap.put(type, viewFactory);
      return this;
    }
    
    public Builder registerPlugin(BPluginType type, AbstractPluginAdapter adapter) {
      PluginAdapterHolder holder = component.getPluginAdapterHolder();
      holder.addPlugin(type, adapter);
      return this;
    }  
    
    public AppStarter build() {
      return new AppStarter(viewMap);
    }
    
  }
    

  /**
   * Tries to login the user if it has a cookie stored.
   */
  private void tryToAuthenticateUser() {
    logger.info("AppStarter - tryToAuthenticateUser()");
    
    String cookieString = cookie.getLoggedInCookie();
    
    if (!Strings.isNullOrEmpty(cookieString)) {
      logger.info("AppStarter - tryToAuthenticateUser(): cookie found: " + cookieString);
//      LoginRequestDto loginRequestDto = new LoginRequestDto(cookieString, deviceDto);
//      eventBus.fireEvent(new LoginRequestEvent(loginRequestDto, RedirectType.NONE, false));      
    }
    else {
      // user is not logged in
//      registerPushNotification();
    }    
  }
  
  

  
  /**
   * Register a new session on the server.
   */
  private void callServerSessionStartAction() {
    logger.info("<<< AppStarter - callServerSessionStartAction()");
    
    SessionStartRestService sessionStartRestService = component.getSessionStartRestService();
    
    sessionStartRestService.saveOrCreate(new BAsyncCallback<GetResult<SessionStartResultDto>>() {
      
      @Override
      public void onFailure(Exception e) {
        logger.log(Level.SEVERE, 
            "AppStarter - callServerSessionStartAction(): Server failed to callServerSessionStartAction create call.",
            e);
      }
      
      @Override
      public void onSuccess(GetResult<SessionStartResultDto> result) {
        logger.info(">>> AppStarter - callServerSessionStartAction(): callServerSessionStartAction succeeded");
        SessionStartResultDto sessionStartResultDto = result.getResult();
        
        String requiredVersion = sessionStartResultDto.getRequiredAppVersion();
        logger.info("AppStarter - callServerSessionStartAction(): requiredVersion: "+requiredVersion);
        
        if (DeviceDto.compareAppVersion(requiredVersion, deviceDto.getAppVersion()) == 1) {
          Notification notification = component.getNotification();
          BMessage message = component.getMessage();
          
          notification.confirm(message.lookup(MessageKey.appVersionToLow), 
              new ConfirmCallback() {
                
                @Override
                public void onConfirm(int button) {
                  if (button == 1) {
                    Inappbrowser inappbrowser = component.getInappbrowser();
                    inappbrowser.openWindow(ParameterConfig.APP_STORE_LINK_IN_APP_IOS);
                  }
                }
              }, 
              message.lookup(MessageKey.appVersionToLowTitle), 
              new String[] {message.lookup(MessageKey.no), message.lookup(MessageKey.yes)});
        }        
      }
    });
    
  }
  
  
  // ---------------------------------------------
  // Events
  // ---------------------------------------------




}
