package majestella.core.bootstrap;

import majestella.core.prototype.mvp.BBaseView;

/**
 * This factory is used to create a view upon request.
 * @author Dr. Michael Gorski
 *
 */
public interface ViewFactory {

  BBaseView getView();
}
