package majestella.core.bootstrap;

public final class ParameterConfig {

  private ParameterConfig() {}
  
  public static final String CODE_BUILD_VERSION = "1.0.2";
  
  // mobile Web App
//  public static final String GOOGLE_ANALYTICS_ACCOUNT = "UA-41559853-3";  // Buddy.is Mobile-Web-App
  
  // mobile iPhone App
//  public static final String GOOGLE_ANALYTICS_ACCOUNT = "UA-35737386-6";  // Majestella IOS App
  
  // mobile Android App
//  public static final String GOOGLE_ANALYTICS_ACCOUNT = "UA-41559853-5";  // Buddy.is Android App

  
  
  public static final String BASE_URL = "http://confile.no-ip.biz:8080/majestella/";
  public static final String FACEBOOK_APP_ID = "320785618025226"; // buddy.is test
  public static final String GOOGLE_ANALYTICS_ACCOUNT = "0000";    // Test Account Majestella iOS TestApp
  
  
  // prod mode
//  public static final String BASE_URL = "http://www.majestella.de/";
//  public static final String FACEBOOK_APP_ID = "130110020502710"; // www.buddy.is 

  
  
  // Constants
  public static final long SERVER_REQUEST_TIMEOUT = 45L;
  public static final String UPLOAD_IMAGE_PATH = "upload/save";
  public static final String LOGGER_MAJESTELLA_NAME = "majestellaLogger";
  public static final String API_BASE_URL = BASE_URL+"api"; // for REST calls
  public static final String PROBLEM_REPORT_EMAIL = "info@majestella.de"; 
  public static final String PRIVACY_URL = "http://www.majestella.de/home/terms";
  public static final String APP_STORE_LINK = "https://itunes.apple.com/de/app/Majestella/id1001085129?mt=8&uo=4";
  public static final String GOOGLE_PLAY_STORE_LINK = "https://play.google.com/store/apps/details?id=de.majestella.buddyis";
  public static final String FACEBOOK_FANEPAGE_LINK = "https://www.facebook.com/Majestella";
  public static final String FACEBOOK_PERMISSIONS = "email,user_birthday,user_likes,user_friends";
  
  //http://stackoverflow.com/questions/17662377/open-play-store-with-phonegap
  public static final String APP_STORE_LINK_IN_APP_IOS = "itms-apps://itunes.apple.com/app/id1001085129";
  public static final String APP_STORE_LINK_IN_APP_ANDROID = "market://details?id=de.majestella.buddyis";
  
  public static final int MAX_ITEMS_LOADED = 9;   // the number of items loaded on a request
  
  public static final int DATA_REFRESH_TIMER_CANCEL_DURATION = 5000; // this is the timer at which a refresh timer is canceled finally
  public static final int STICKER_INDEX_MAX_STICKER_GROUPS_PER_PAGE = 15; // number of sticker groups loaded per request on the index page
  public static final int STICKER_MAX_STICKERS_PER_PAGE = 15; //30;  // number of stickers loaded on each request for the preview page

  
  /**
   * The frequency at which incomplete requests (< max per page) are send to the server
   */
  public static final long MAX_SERVER_INCOMPLETE_REQUEST_FREQUENCY = 300000L; // 5 minute
  public static final long DATABASE_MAX_STICKER_GROUP_AGE = 259200000L; // 3 days
  public static final long DATABASE_MAX_STICKER_AGE = 1728000000L; // 20 days
  public static final long DATABASE_MAX_ITEM_AGE = 1728000000L; // 20 days
  
  // for Google GCM (Could messaging service)
  public static final String GCM_SENDER_ID = "8336522043";
  
  
  public static final String getBaseUrl() {
    return BASE_URL;
  }
  
  
  public static final String getApiBaseUrl() {
    return API_BASE_URL;
  }
  
  
  /**
   * Return the url to upload an image for an item to.
   * @return
   */
  public static String getUploadImageUrl() {
    return BASE_URL + UPLOAD_IMAGE_PATH; // Achtung muss BASE_URL sein nicht getBaseUrl()
  }
  
}
