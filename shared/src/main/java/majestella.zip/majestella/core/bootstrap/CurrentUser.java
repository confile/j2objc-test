package majestella.core.bootstrap;

import majestella.core.rest.dto.LoginResultDto;
import majestella.core.rest.dto.UserDetailsDto;

public class CurrentUser {

  private UserDetailsDto userDetailsDto;

  
  /**
   * Create a user from a LoginResult.
   * 
   * @param result
   */
  public void fromLoginResult(LoginResultDto result) {
    setUser(result.getUserDetailsDto());
  }

  public void fromUserDetailsDto(UserDetailsDto dto) {
    setUser(dto);
  }

  /**
   * Delete all user information as well as the loggedIn status.
   */
  public void reset() {
    setUser(null);
  }

  /**
   * Check if the user is loggedIn.
   * 
   * @return
   */
  public boolean isLoggedin() {
    if (userDetailsDto != null) {
      return true;
    } else {
      return false;
    }
  }

  public boolean isCurrentUser(String username) {
    if (isLoggedin()) {
      if (username.equals(userDetailsDto.getUsername())) {
        return true;
      }
    }
    return false;
  }

  public UserDetailsDto getUser() {
    return userDetailsDto;
  }

  public void setUser(UserDetailsDto userDetailsDto) {
    this.userDetailsDto = userDetailsDto;
  }

  public boolean getUserFromPage() {
    return false;
  }
  
}
