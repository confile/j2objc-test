package majestella.core.i18n;

/**
 * This class contains the lookup keys for {@link BMessage}.
 * @author Dr. Michael Gorski
 *
 */
public class MessageKey {

  public static final String signupTitle = "signupTitle";  
  public static final String appVersionToLowTitle = "appVersionToLowTitle";
  public static final String appVersionToLow = "appVersionToLow";
  public static final String no = "no";
  public static final String yes = "yes";
  public static final String chooseLocation = "chooseLocation";
  public static final String guestInfo = "guestInfo";
  public static final String roomservice = "roomservice";
  public static final String restaurantsAndBars = "restaurantsAndBars";
  public static final String feedback = "feedback";
  public static final String spa = "spa";
  public static final String reception = "reception";
  public static final String orderOverview = "orderOverview";
  public static final String edit = "edit";
  public static final String total = "total";
  public static final String done = "done";
  public static final String shoppingCardEmptyText = "shoppingCardEmptyText";
  public static final String delete = "delete";
  public static final String settings = "settings";
  public static final String reservation = "reservation";
  public static final String version = "version";
  public static final String recommendTheApp = "recommendTheApp";
  public static final String rateTheApp = "rateTheApp";
  public static final String likeTheAppOnFacebook = "likeTheAppOnFacebook";
  public static final String reportABug = "reportABug";
  public static final String submitOrder = "submitOrder";
  public static final String tourText1 = "tourText1";
  public static final String tourText2 = "tourText2";
  public static final String tourText3 = "tourText3";
  public static final String tourStartButtonText = "tourStartButtonText";
  public static final String prePermissionLocationTitle = "prePermissionLocationTitle";
  public static final String prePermissionLocationDescription = "prePermissionLocationDescription";
  public static final String prePermissionLocationDeny = "prePermissionLocationDeny";
  public static final String prePermissionLocationAuthorize = "prePermissionLocationAuthorize";
  public static final String currentLocation = "currentLocation";
  public static final String permissionLocationDeniedDescription = "permissionLocationDeniedDescription";
  public static final String ok = "ok";
  public static final String permissionLocationRestrictedDescription = "permissionLocationRestrictedDescription";
  public static final String hotel = "hotel";
  public static final String place = "place";
  public static final String tourism = "tourism";
  public static final String proximitySearch = "proximitySearch";
  public static final String copyright = "copyright";
  public static final String restartServiceCardButtonTitle = "restartServiceCardButtonTitle";
  public static final String cancel = "cancel";
  public static final String likeButtonTourTitle = "likeButtonTourTitle";
  public static final String likeButtonTourDescription = "likeButtonTourDescription";
  public static final String likeButtonTourLike = "likeButtonTourLike";
  public static final String nopeButtonTourTitle = "nopeButtonTourTitle";
  public static final String nopeButtonTourDescription = "nopeButtonTourDescription";
  public static final String nopeButtonTourNope = "nopeButtonTourNope";
  public static final String likeSwipeTourTitle = "likeSwipeTourTitle";
  public static final String likeSwipeTourDescription = "likeSwipeTourDescription";
  public static final String nopeSwipeTourTitle = "nopeSwipeTourTitle";
  public static final String nopeSwipeTourDescription = "nopeSwipeTourDescription";
  public static final String orderUserDetailsTitle = "orderUserDetailsTitle";
  public static final String lastName = "lastName";
  public static final String roomNumber = "roomNumber";
  public static final String departureDate = "departureDate";
  public static final String orderConfirmationTitle = "orderConfirmationTitle";
  public static final String orderConfirmationMessage = "orderConfirmationMessage";
  public static final String bookNow = "bookNow";
  public static final String booking = "booking";
  public static final String callNow = "callNow";
  public static final String enquireNow = "enquireNow";
  
  
}
