package majestella.core.i18n;

import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import majestella.core.bootstrap.ParameterConfig;

/**
 * Plural forms see: https://docs.oracle.com/javase/tutorial/i18n/format/choiceFormat.html
 * @author Dr. Michael Gorski
 *
 */
public class MessageImpl implements BMessage {

  private ResourceBundle resourceBundle;
  private final Logger logger;

  public MessageImpl() {
    this.logger = Logger.getLogger(ParameterConfig.LOGGER_MAJESTELLA_NAME);
  }

  @Override
  public void setLocale(String localeString) {
    Locale locale = new Locale(localeString);
    logger.info("MessageImpl locale: "+locale);
    try {
      resourceBundle = ResourceBundle.getBundle("Messages", locale);
//      resourceBundle = ResourceBundle.getBundle("./buddyis/core/i18n/Messages", locale);
    } catch (MissingResourceException ex) {
      logger.log(Level.SEVERE, ex.getMessage(), ex);
    }
  }

  @Override
  public String lookup(String key) {
    if (resourceBundle == null) {
      throw new NullPointerException("MessageImpl - locale cannot be null you have to call setLocale first");
    }
    return resourceBundle.getString(key);
  }

}
