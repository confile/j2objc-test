package majestella.core.i18n;

public interface BMessage {

  void setLocale(String localeString);
  
  String lookup(String key);
  
}
