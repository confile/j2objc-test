package majestella.core.place;

public class UrlTokens {

  private UrlTokens() {
  }
  
  public static final String SERVICE_CARD_ID = "serviceCardId";
  public static final String LOCATION_ID = "locationId";
  public static final String LOCATION_NAME = "locationName";
  public static final String PRESENT_MODAL = "presentModal"; 
  public static final String LOCATION_TYPE = "locationType";
  public static final String SHOW_IN_WISHLIST = "showInWishList";
  
}

