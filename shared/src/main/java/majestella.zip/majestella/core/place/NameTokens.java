package majestella.core.place;

public class NameTokens {

  private NameTokens() {
  }

  public static final String start = "/start";
  public static final String serviceSelection = "/serviceSelection";
  public static final String locationMain = "/locationMain";
  public static final String wishList = "/wishList";
  public static final String locationSetting = "/locationSetting";
  public static final String locationInfo = "/locationInfo";
  public static final String serviceDetails = "/serviceDetails";
  public static final String roomService = "/roomService";
  public static final String roomServiceCard = "/roomServiceCard";
  public static final String hotelRestaurant = "/hotelRestaurant";
  public static final String hotelSpa = "/hotelSpa";
  public static final String setting = "/setting";
  
  
  public static String getStart() {
    return start;
  }

  public static String getServiceSelection() {
    return serviceSelection;
  }

  public static String getLocationMain() {
    return locationMain;
  }

  public static String getWishList() {
    return wishList;
  }

  public static String getLocationSetting() {
    return locationSetting;
  }

  public static String getLocationInfo() {
    return locationInfo;
  }

  public static String getServiceDetails() {
    return serviceDetails;
  }
  
  public static String getRoomService() {
    return roomService;
  }
  
  public static String getRoomServiceCard() {
    return roomServiceCard;
  }
  
  public static String getHotelRestaurant() {
    return hotelRestaurant;
  }
  
  public static String getHotelSpa() {
    return hotelSpa;
  }
  
  public static String getSetting() {
    return setting;
  }
  
 
  
}
