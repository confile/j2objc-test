package majestella.core.app.start;

 
import javax.inject.Inject;

import majestella.core.app.locationSetting.LocationHolder;
import majestella.core.place.NameTokens;
import majestella.core.place.UrlTokens;
import majestella.core.plugins.appInfo.AppInfo;
import majestella.core.plugins.appInfo.AppInfoUserDefaultKey;
import majestella.core.prototype.annotation.NameToken;
import majestella.core.prototype.eventBus.BEventBus;
import majestella.core.prototype.mvp.BAbstractPresenter;
import majestella.core.prototype.mvp.BBaseView;
import majestella.core.prototype.mvp.BHasUiHandlers;
import majestella.core.prototype.mvp.proxy.ProxyPlace;
import majestella.core.prototype.navigation.BPlaceManager;
import majestella.core.prototype.navigation.BPlaceRequest;

import com.google.auto.factory.AutoFactory;
import com.google.auto.factory.Provided;
import com.google.common.base.Strings;

import dagger.Lazy;
 
@AutoFactory(className="StartPresenterFactory")
public class StartPresenter extends BAbstractPresenter<StartPresenter.MyView, StartPresenter.MyProxy> implements StartViewUiHandlers {

  public interface MyView extends BBaseView, BHasUiHandlers<StartViewUiHandlers> {
  }
  
  @NameToken(NameTokens.start)
  public interface MyProxy extends ProxyPlace<StartPresenter> {
  }
  

  private final BPlaceManager placeManager; 
  private final Lazy<AppInfo> lazyAppinfo;
  
  @Inject
  public StartPresenter(@Provided BEventBus eventBus, BBaseView view, @Provided MyProxy proxy,
      @Provided BPlaceManager placeManager, @Provided Lazy<AppInfo> lazyAppinfo) {
    super(eventBus, (MyView)view, proxy, RevealType.Root); 
	  
    logger.info("StartPresenter - proxy: "+proxy.getNameToken());
    
    this.placeManager = placeManager;   
    this.lazyAppinfo = lazyAppinfo;
    
    getView().setUiHandlers(this);     
  }
  
  
  @Override
  protected void onBind() {
    super.onBind();
    logger.info("StartPresenter - onBind()"); 
  }
    
  @Override
  protected void onReveal() {
    super.onReveal();
    logger.info("StartPresenter - onReveal()");
    
    // check if the user has selected a location before
    String lastLocationId = lazyAppinfo.get().getUserDefaultString(AppInfoUserDefaultKey.lastLocationId);
    if (!Strings.isNullOrEmpty(lastLocationId)) {
      int lastLoctionType = (int)lazyAppinfo.get().getUserDefaultDouble(AppInfoUserDefaultKey.lastLocationType);
      
      logger.info("StartPresenter - onReveal(): found preveous location: "+lastLocationId+" type: "+lastLoctionType);
      
      BPlaceRequest request = new BPlaceRequest.Builder()
        .nameToken(NameTokens.getLocationMain())
        .with(UrlTokens.LOCATION_ID, lastLocationId) 
        .with(UrlTokens.LOCATION_TYPE, ""+lastLoctionType)
        .build();
      placeManager.revealPlace(request); 
    }    
  }
  
  @Override
  protected void onHide() {
    super.onHide();
    logger.info("StartPresenter - onHide()");
     
  }
  

  
  @Override
  public void loginButtonTapped() {
    logger.info("StartPresenter - loginButtonTapped()");
     
    
//    BPlaceRequest request = new BPlaceRequest.Builder()
//      .nameToken(NameTokens.getLogin())
//      .build();
//    placeManager.revealPlace(request);    
  }



  @Override
  public void signupButtonTapped() {
//    BPlaceRequest request = new BPlaceRequest.Builder()
//        .nameToken(NameTokens.getSignup())
//        .build();
//    placeManager.revealPlace(request);
    
    logger.info("StartPresenter - signupButtonTapped()");
  }

  
  @Override 
  public void continueWithoutLogin() {
	  BPlaceRequest request = new BPlaceRequest.Builder()
	  	.nameToken(NameTokens.getServiceSelection())
	  	.build();
	  placeManager.revealPlace(request);	  
  }


  @Override
  public void locationButtonTapped() {
    // check if a location is predefined
    if (!LocationHolder.getSharedInstance().getId().equals("")) {
      logger.info("StartPresenter - locationButtonTapped(): found predefined location");
      
      BPlaceRequest request = new BPlaceRequest.Builder()
        .nameToken(NameTokens.getLocationMain())
        .with(UrlTokens.LOCATION_ID, LocationHolder.getSharedInstance().getId()) 
        .with(UrlTokens.LOCATION_TYPE, ""+LocationHolder.getSharedInstance().getType())
        .build();
      placeManager.revealPlace(request); 
    }
    else {
      BPlaceRequest request = new BPlaceRequest.Builder()
        .nameToken(NameTokens.getLocationSetting())
        .build();
      placeManager.revealPlace(request);  
    }
  }
  
  
  // ---------------------------------------------
  // Events
  // ---------------------------------------------

  
 
  
}
