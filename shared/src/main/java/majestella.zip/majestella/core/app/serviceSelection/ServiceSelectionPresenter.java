package majestella.core.app.serviceSelection;

 
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import javax.inject.Inject;

import majestella.core.app.locationMain.events.LocationChangedEvent;
import majestella.core.app.locationMain.events.LocationChangedEvent.LocationChangedHandler;
import majestella.core.app.mainNavigation.MainNavigationPresenter;
import majestella.core.app.serviceSelection.events.ServiceDetailsUpdateEvent;
import majestella.core.app.serviceSelection.server.ServiceSelectionGetLoaderTask;
import majestella.core.app.serviceSelection.server.ServiceSelectionGetRequestList;
import majestella.core.app.serviceSelection.server.ServiceSelectionPostLoaderTask;
import majestella.core.app.serviceSelection.server.ServiceSelectionPostRequestList;
import majestella.core.app.wishList.WishList;
import majestella.core.app.wishList.events.WishListAppendEvent;
import majestella.core.app.wishList.events.WishListItemRemoveEvent;
import majestella.core.app.wishList.events.WishListItemRemoveEvent.WishListItemRemoveHandler;
import majestella.core.app.wishList.events.WishListSizeRequestEvent;
import majestella.core.app.wishList.events.WishListSizeResponseEvent;
import majestella.core.app.wishList.events.WishListSizeResponseEvent.WishListSizeResponseHandler;
import majestella.core.i18n.BMessage;
import majestella.core.i18n.MessageKey;
import majestella.core.place.NameTokens;
import majestella.core.place.UrlTokens;
import majestella.core.plugins.appInfo.AppInfo;
import majestella.core.plugins.appInfo.AppInfoUserDefaultKey;
import majestella.core.plugins.googleAnalytics.GoogleAnalytics;
import majestella.core.plugins.notification.ConfirmCallback;
import majestella.core.plugins.notification.Notification;
import majestella.core.plugins.spinner.Spinner;
import majestella.core.prototype.annotation.ContentSlot;
import majestella.core.prototype.annotation.NameToken;
import majestella.core.prototype.annotation.ProxyEvent;
import majestella.core.prototype.eventBus.AbstractBEvent.Type;
import majestella.core.prototype.eventBus.BEventBus;
import majestella.core.prototype.mvp.BAbstractPresenter;
import majestella.core.prototype.mvp.BBaseView;
import majestella.core.prototype.mvp.BHasUiHandlers;
import majestella.core.prototype.mvp.proxy.BRevealContentHandler;
import majestella.core.prototype.mvp.proxy.ProxyPlace;
import majestella.core.prototype.navigation.BPlaceManager;
import majestella.core.prototype.navigation.BPlaceRequest;
import majestella.core.rest.ServiceCardRestService;
import majestella.core.rest.dto.BooleanDto;
import majestella.core.rest.dto.GetResult;
import majestella.core.rest.dto.GetResults;
import majestella.core.rest.dto.LocationDto;
import majestella.core.rest.dto.ServiceCardDto;

import com.google.auto.factory.AutoFactory;
import com.google.auto.factory.Provided;

import core.helper.timer.BTimer;
import core.helper.timer.BTimerCallback;
import dagger.Lazy;
 
@AutoFactory(className="ServiceSelectionPresenterFactory")
public class ServiceSelectionPresenter extends BAbstractPresenter<ServiceSelectionPresenter.MyView, ServiceSelectionPresenter.MyProxy> 
	implements ServiceSelectionViewUiHandlers, LocationChangedHandler, WishListItemRemoveHandler, WishListSizeResponseHandler {

  public interface MyView extends BBaseView, BHasUiHandlers<ServiceSelectionViewUiHandlers> {
    
    /**
     * Set the segment names for the segments.
     * @param segmentNames
     */
    void setSegnents(List<String> segmentNames);
    
    /**
     * Reload the ServiceCards in the view.
     */
    void reloadServiceCards();
    
    /**
     * Set the size of the WishList.
     * @param size
     */
    void setWishListSize(int size);
    
  }
  
  @NameToken(NameTokens.serviceSelection)
  public interface MyProxy extends ProxyPlace<ServiceSelectionPresenter> {
  }
  
  @ContentSlot
  public static final Type<BRevealContentHandler<?>> SLOT_DETAILS = new Type<BRevealContentHandler<?>>();
  
  
  // if the queue size is below 4 the server is requested for new items
  private static final int MIN_QUEUE_SIZE_TO_RELOAD = 4;
  
  private LocationDto locationDto = null; 
  private boolean isViewInitialized = false;
  private boolean isDataInitialized = false;
  private List<String> segmentNames = new ArrayList<>();
  private int selectedSegment = 0; 
  private Queue<ServiceCardDto> locationServiceCardDtoQueue = new LinkedList<>();
  private int locationOffset = 0;
  private boolean hasRunningRequestLocation = false;
  private Queue<ServiceCardDto> aroundMeServiceCardDtoQueue = new LinkedList<>();
  private int aroundMeOffset = 0;  
  private boolean hasRunningRequestAroundMe = false;
  private boolean shouldReloadServiceCards = false;
  
  private final BPlaceManager placeManager; 
  private final Lazy<ServiceCardRestService> lazyServiceCardRestService;
  private final BMessage message;
  private final Lazy<Spinner> lazySpinner;
  private final Lazy<AppInfo> lazyAppinfo;
  private final Lazy<Notification> lazyNotification; 
  private final Lazy<GoogleAnalytics> lazyGoogleAnalytics;
  
  
  @Inject
  public ServiceSelectionPresenter(@Provided BEventBus eventBus, BBaseView view, @Provided MyProxy proxy,
      @Provided BPlaceManager placeManager, @Provided Lazy<ServiceCardRestService> lazyServiceCardRestService,
      @Provided final BMessage message, @Provided final Lazy<Spinner> lazySpinner, 
      @Provided Lazy<AppInfo> lazyAppinfo, @Provided Lazy<Notification> lazyNotification,
      @Provided Lazy<GoogleAnalytics> lazyGoogleAnalytics) {
    super(eventBus, (MyView)view, proxy, MainNavigationPresenter.SLOT_MAIN); 
    
    this.placeManager = placeManager;   
    this.lazyServiceCardRestService = lazyServiceCardRestService;
    this.message = message; 
    this.lazySpinner = lazySpinner;
    this.lazyAppinfo = lazyAppinfo;
    this.lazyNotification = lazyNotification;
    this.lazyGoogleAnalytics = lazyGoogleAnalytics;
    
    getView().setUiHandlers(this);     
  }
  
  
  @Override
  protected void onBind() {
    super.onBind();
    logger.info("ServiceSelectionPresenter - onBind()"); 
    
    addRegisteredHandler(WishListSizeResponseEvent.getType(), this);
  }
    
  @Override
  public void prepareFromRequest(BPlaceRequest request) {
    super.prepareFromRequest(request);
    logger.info("ServiceSelectionPresenter - prepareFromRequest()"); 
    clearSlot(SLOT_DETAILS);
  }
  
  
  @Override
  protected void onReveal() {
    super.onReveal();
    logger.info("ServiceSelectionPresenter - onReveal()");
  }
  
  @Override
  protected void onHide() {
    super.onHide();
    logger.info("ServiceSelectionPresenter - onHide()");
     
  }
  
  
  private void callServerServiceCardAction(final boolean aroundMe) {
    assert(locationDto != null);    
//    logger.info("<<< ServiceSelectionPresenter - callServerServiceCardAction(): company: "+locationDto.getName());
    
    if (aroundMe) {
      if (hasRunningRequestAroundMe) {
        return;
      }
      else {
        hasRunningRequestAroundMe = true;
      }
    }
    else {
      if (hasRunningRequestLocation) {
        return;
      }
      else {
        hasRunningRequestLocation = true;
      }
    }
    
    int offset = locationOffset;
    if (selectedSegment == 1) {
      offset = aroundMeOffset;
    }
    
    
    ServiceSelectionGetRequestList requestList = new ServiceSelectionGetRequestList(locationDto.getType(), 
        locationDto.getId(), offset, aroundMe, lazyServiceCardRestService.get(), 
        new ServiceSelectionGetRequestList.ResultCallback() {
          
          @Override
          public void onResult(GetResults<ServiceCardDto> result) {
            
            if (result != null) {
              insertCardsToQueue(result.getResults(), aroundMe);
            }
            
            if (aroundMe) {
              hasRunningRequestAroundMe = false;
            }
            else {
              hasRunningRequestLocation = false;
            }
            
            if (result != null) {
              logger.info("ServiceSelectionPresenter - callServerServiceCardAction(): shouldReloadServiceCards: "+shouldReloadServiceCards);
              if (shouldReloadServiceCards) {
                shouldReloadServiceCards = false;
                getView().reloadServiceCards();                  
              }   
            }
            
            lazySpinner.get().hide();
          }
        });
    
    // call server on a background thread
    new ServiceSelectionGetLoaderTask().execute(requestList);
    
    
    // TODO delete OLD
    
//    lazyServiceCardRestService.get().get(locationDto.getType(), locationDto.getId(), offset, aroundMe,
//        new BAsyncCallback<GetResults<ServiceCardDto>>() {
//      
//          @Override
//          public void onFailure(Exception e) {
//            logger.log(Level.SEVERE, 
//            "ServiceSelectionPresenter - callServerServiceCardAction(): Cannot contact server.",
//            e);
//            lazySpinner.get().hide();
//            
//            if (aroundMe) {
//              hasRunningRequestAroundMe = false;
//            }
//            else {
//              hasRunningRequestLocation = false;
//            }
//          }
//      
//          @Override
//          public void onSuccess(GetResults<ServiceCardDto> result) {
//            logger.info(">>> ServiceSelectionPresenter - callServerServiceCardAction(): count: "+result.getResults().size());
//            insertCardsToQueue(result.getResults(), aroundMe);
//            lazySpinner.get().hide();
//            
//            if (aroundMe) {
//              hasRunningRequestAroundMe = false;
//            }
//            else {
//              hasRunningRequestLocation = false;
//            }
//            
//            logger.info(">>> ServiceSelectionPresenter - callServerServiceCardAction(): shouldReloadServiceCards: "+shouldReloadServiceCards); 
//            if (shouldReloadServiceCards) {              
//              shouldReloadServiceCards = false;
//              getView().reloadServiceCards();                  
//            }           
//          }          
//        });    
  }
  
  
  private void insertCardsToQueue(List<ServiceCardDto> serviceCardDtos, boolean aroundMe) {
    
    // update the offset
    int size = serviceCardDtos.size();
    
    if (aroundMe) { 
      aroundMeOffset += size;
      for (ServiceCardDto dto : serviceCardDtos) {
        aroundMeServiceCardDtoQueue.add(dto);
      }      
    }
    else {
      locationOffset += size;
      for (ServiceCardDto dto : serviceCardDtos) {
        locationServiceCardDtoQueue.add(dto);
      }
    }
    
  }
  

  private void callServerServiceCardChoiceAction(String serviceCardId, boolean liked, boolean removedFromWishList) {
    
    ServiceSelectionPostRequestList requestList = new ServiceSelectionPostRequestList(serviceCardId, liked, 
        removedFromWishList, lazyServiceCardRestService.get(), 
        new ServiceSelectionPostRequestList.ResultCallback() {
          
          @Override
          public void onResult(GetResult<BooleanDto> result) {
          }
        });
    
    // call server on a background thread
    new ServiceSelectionPostLoaderTask().execute(requestList);
    
    
    // TODO delete OLD
//    logger.info("<<< ServiceSelectionPresenter - callServerServiceCardChoiceAction(): liked: "+liked);
//    
//    lazyServiceCardRestService.get().post(serviceCardId, liked, removedFromWishList, 
//        new BAsyncCallback<GetResult<BooleanDto>>() {
//      
//      @Override
//      public void onFailure(Exception e) {
//        logger.log(Level.SEVERE, 
//            "ServiceSelectionPresenter - callServerServiceCardChoiceAction(): Cannot contact server.",
//            e);
//      }
//      
//      @Override
//      public void onSuccess(GetResult<BooleanDto> result) {
//        logger.info(">>> ServiceSelectionPresenter - callServerServiceCardChoiceAction(): result: "+result.getResult().getValue());
//      }
//    });    
  }
  
  private void updateViewSegments() {
    if (isViewInitialized) {
      getView().setSegnents(segmentNames);
    }
  }
  
 
  // ---------------------------------------------
  // UiHandlers
  // ---------------------------------------------

  
  @Override
  public void viewDidLoad() {
    logger.info("ServiceSelectionPresenter - viewDidLoad()");
    isViewInitialized = true;
    updateViewSegments();
  }
  
  @Override
  public void viewDidAppear() {
    logger.info("ServiceSelectionPresenter - viewDidAppear() isDataInitialized: "+isDataInitialized);
    if (!isDataInitialized) {
      isDataInitialized = true;
      shouldReloadServiceCards = true;
      callServerServiceCardAction(false);
    }  
    
    WishListSizeRequestEvent.fire(this);
  }
  
  @Override
  public boolean hasNextServiceCardDto() {
    ServiceCardDto dto = null;
    if (selectedSegment == 0) {
      dto = locationServiceCardDtoQueue.peek();
    }
    else {
      dto = aroundMeServiceCardDtoQueue.peek();
    }
      
    if (dto != null) {
      return true;
    }    
    return false;
  }
  
  @Override
  public ServiceCardDto popServiceCardDto() {   
    logger.info("ServiceSelectionPresenter - popServiceCardDto()");
    int queueSize = 0;
    ServiceCardDto nextServiceCardDto = null;
    if (selectedSegment == 0) {
      queueSize = locationServiceCardDtoQueue.size();
      if (queueSize <= MIN_QUEUE_SIZE_TO_RELOAD) {
        BTimer timer = new BTimer();
        timer.setRun(new BTimerCallback() {
          
          @Override
          public void run() {
            callServerServiceCardAction(false);
          }
        });
        timer.schedule(100);
      } 
      nextServiceCardDto = locationServiceCardDtoQueue.poll();
    }
    else {
      queueSize = aroundMeServiceCardDtoQueue.size();
      if (queueSize <= MIN_QUEUE_SIZE_TO_RELOAD) {
        BTimer timer = new BTimer();
        timer.setRun(new BTimerCallback() {
          
          @Override
          public void run() {
            callServerServiceCardAction(true);
          }
        });
        timer.schedule(100);
      } 
      nextServiceCardDto = aroundMeServiceCardDtoQueue.poll();
    }   
        
    if (nextServiceCardDto != null) {
      // cache the card which are currently on screen
      ServiceCardCache.getSharedInstance().append(nextServiceCardDto);
    }
    logger.info("ServiceSelectionPresenter - popServiceCardDto(): nextServiceCardDto: "+nextServiceCardDto.getTitle());
    return nextServiceCardDto;
  }
  
  
  @Override
  public void cardTapped(ServiceCardDto serviceCardDto) {
    
    ServiceDetailsUpdateEvent.fire(this, serviceCardDto);
    
    BPlaceRequest request = new BPlaceRequest.Builder()
      .nameToken(NameTokens.getServiceDetails())
      .with(UrlTokens.SERVICE_CARD_ID, serviceCardDto.getId())
      .build();
    placeManager.revealPlace(request); 
  }
  
  
  @Override
  public void cardAction(ServiceCardDto serviceCardDto, boolean liked) {
    logger.info("ServiceSelectionPresenter - cardAction()");
    if (liked) {
      WishListAppendEvent.fire(this, serviceCardDto);      
    }
    // pop the last card from the screen cache
    ServiceCardCache.getSharedInstance().getNext();
    callServerServiceCardChoiceAction(serviceCardDto.getId(), liked, false);
    
    if (liked) {
      lazyGoogleAnalytics.get().trackEvent("ServiceCard LIKE", serviceCardDto.getTitle()+"("+serviceCardDto.getId()+")", serviceCardDto.getCompanyName(), 1);
    }
    else {
      lazyGoogleAnalytics.get().trackEvent("ServiceCard NOPE", serviceCardDto.getTitle()+"("+serviceCardDto.getId()+")", serviceCardDto.getCompanyName(), 0);
    }
    
  }
  
  @Override
  public void segmentSelected(int index) {
    logger.info("ServiceSelectionPresenter - segmentSelected(): index: "+index);
    
    // put all cached cards back at the top of the queue
    Queue<ServiceCardDto> tmpServiceCardDtoQueue = new LinkedList<>(); 
    for (int i=0; i < 2; i++) {
      ServiceCardDto cachedServiceCardDto = ServiceCardCache.getSharedInstance().getNext();
      if (cachedServiceCardDto != null) {
        tmpServiceCardDtoQueue.add(cachedServiceCardDto);
      }
    }
    
    if (selectedSegment == 0) {
      tmpServiceCardDtoQueue.addAll(locationServiceCardDtoQueue);
      locationServiceCardDtoQueue = tmpServiceCardDtoQueue;
    }
    else {
      tmpServiceCardDtoQueue.addAll(aroundMeServiceCardDtoQueue);
      aroundMeServiceCardDtoQueue = tmpServiceCardDtoQueue;
    }
    
    // clear screen cache
    ServiceCardCache.getSharedInstance().clear();
    // update selectedSegment
    selectedSegment = index;
    
    logger.info("ServiceSelectionPresenter - segmentSelected(): new selectedSegment: "+selectedSegment);
    // check if queue is empty
    if (selectedSegment == 0) {
      if (locationServiceCardDtoQueue.size() == 0) {
        logger.info("ServiceSelectionPresenter - segmentSelected(): locationServiceCardDtoQueue.size() == 0");
        lazySpinner.get().show();
        shouldReloadServiceCards = true;
        BTimer timer = new BTimer();
        timer.setRun(new BTimerCallback() {
          
          @Override
          public void run() {
            callServerServiceCardAction(false);
          }
        });
        timer.schedule(100);        
      }
      else {
        logger.info("ServiceSelectionPresenter - segmentSelected(): locationServiceCardDtoQueue.size() > 0");
        getView().reloadServiceCards();
      }
    }
    else {
      if (aroundMeServiceCardDtoQueue.size() == 0) {
        logger.info("ServiceSelectionPresenter - segmentSelected(): aroundMeServiceCardDtoQueue.size() == 0");
        lazySpinner.get().show();
        shouldReloadServiceCards = true;
        BTimer timer = new BTimer();
        timer.setRun(new BTimerCallback() {
          
          @Override
          public void run() {
            callServerServiceCardAction(true);
          }
        });
        timer.schedule(100);
      }
      else {
        logger.info("ServiceSelectionPresenter - segmentSelected(): aroundMeServiceCardDtoQueue.size() > 0");
        getView().reloadServiceCards();
      }
    }
    
  }
  
  
  @Override
  public void restartServiceCards() {
    logger.info("ServiceSelectionPresenter - restartServiceCards()");
    shouldReloadServiceCards = true;
    
    if (selectedSegment == 0) {
      locationOffset = 0;
      callServerServiceCardAction(false);
    }
    else {
      aroundMeOffset = 0;
      callServerServiceCardAction(true);
    }
  }
  
  
  /**
   * Check if the tour description should be 
   * shown to the user if he performs an action for 
   * the first time.
   */
  @Override
  public boolean shouldBeChosen(boolean like, boolean button) {
    // check if user has seen tour message before
    boolean presented = false;
    
    if (like) {
      if (button) {
        presented = lazyAppinfo.get().getUserDefaultBoolean(AppInfoUserDefaultKey.tourLikeButtonShown);
        lazyAppinfo.get().setUserDefaultBoolean(AppInfoUserDefaultKey.tourLikeButtonShown, true);             
      }
      else {
        presented = lazyAppinfo.get().getUserDefaultBoolean(AppInfoUserDefaultKey.tourLikeSwipeShown);
        lazyAppinfo.get().setUserDefaultBoolean(AppInfoUserDefaultKey.tourLikeSwipeShown, true);
      }
    }
    else {
      if (button) {
        presented = lazyAppinfo.get().getUserDefaultBoolean(AppInfoUserDefaultKey.tourNopeButtonShown);
        lazyAppinfo.get().setUserDefaultBoolean(AppInfoUserDefaultKey.tourNopeButtonShown, true);
      }
      else {
        presented = lazyAppinfo.get().getUserDefaultBoolean(AppInfoUserDefaultKey.tourNopeSwipeShown);
        lazyAppinfo.get().setUserDefaultBoolean(AppInfoUserDefaultKey.tourNopeSwipeShown, true);
      }
    }
    
    if (!presented) { 
      return false;
    }    
    else {
      return true;
    }
  }
  
  
  /**
   * Show a tour dialog to the user.
   */
  @Override
  public void showTourIntro(final boolean like, boolean button, final ServiceSelectionCallback callback) {

    String title = "";
    String description = "";
    String okButton = "";
    
    if (like) {
      if (button) {       
        title = message.lookup(MessageKey.likeButtonTourTitle);
        description = message.lookup(MessageKey.likeButtonTourDescription);        
      }
      else {        
        title = message.lookup(MessageKey.likeSwipeTourTitle);
        description = message.lookup(MessageKey.likeSwipeTourDescription);        
      }
      okButton = message.lookup(MessageKey.likeButtonTourLike);
    }
    else {
      if (button) {        
        title = message.lookup(MessageKey.nopeButtonTourTitle);
        description = message.lookup(MessageKey.nopeButtonTourDescription);
      }
      else {        
        title = message.lookup(MessageKey.nopeSwipeTourTitle);
        description = message.lookup(MessageKey.nopeSwipeTourDescription);
      }
      okButton = message.lookup(MessageKey.nopeButtonTourNope);
    }
         
    final String cancelButton = message.lookup(MessageKey.cancel);
    
    final String myDescription = description;
    final String myTitle = title;
    final String myOkButton = okButton;
    
    // show tour dialog
    lazyNotification.get().confirm(myDescription, new ConfirmCallback() {
      
      @Override
      public void onConfirm(int button) {  
        if (button == 0) {
          callback.onCallback(false, like);
        }
        else {
          callback.onCallback(true, like);
        }
      }
    }, myTitle, new String[] {cancelButton, myOkButton});  
  }
  
  
  @Override
  public int getWishListSize() {
    return WishList.getSharedInstance().getSize();
  }
  
  // ---------------------------------------------
  // Events
  // ---------------------------------------------

  
  @ProxyEvent
  @Override
  public void onLocationChanged(LocationChangedEvent event) {
    logger.info("ServiceSelectionPresenter - onLocationChanged()");
    if (!event.getLocationDto().equals(locationDto)) {
      locationDto = event.getLocationDto();
      
      locationOffset = 0;
      locationServiceCardDtoQueue.clear();
      hasRunningRequestLocation = false;
      aroundMeOffset = 0;
      aroundMeServiceCardDtoQueue.clear();
      selectedSegment = 0;
      hasRunningRequestAroundMe = false;
      
      // set segmentNames
      this.segmentNames.clear();
      this.segmentNames.add(locationDto.getName());
      // TODO: use it when needed
      if ( (locationDto.getHotelDto() != null) || (locationDto.getTouristOrganizationDto() != null) ) {
        this.segmentNames.add(message.lookup(MessageKey.proximitySearch));
      }      
      updateViewSegments();
      
      isDataInitialized = false; 
      
      // reload ServiceCards after load
      shouldReloadServiceCards = true;
      
      // clear screen cache
      ServiceCardCache.getSharedInstance().clear();
      
    }
  }
  
  
  @ProxyEvent
  @Override
  public void onWishListItemRemoved(final WishListItemRemoveEvent event) {
    logger.info("ServiceSelectionPresenter - onWishListItemRemoved()");
    BTimer timer = new BTimer();
    timer.setRun(new BTimerCallback() {
      
      @Override
      public void run() {
        callServerServiceCardChoiceAction(event.getServiceCardDto().getId(), true, true);  
      }
    });
    timer.schedule(1);  
  }
  
  
  
  @Override
  public void onWishListSizeResponse(WishListSizeResponseEvent event) {
    logger.info("ServiceSelectionPresenter - onWishListSizeResponse()");
    getView().setWishListSize(event.getSize());
  }
  
  
  
}
