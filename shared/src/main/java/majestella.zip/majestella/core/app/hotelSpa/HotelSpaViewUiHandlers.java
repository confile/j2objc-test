package majestella.core.app.hotelSpa;

import majestella.core.prototype.mvp.BUiHandlers;

public interface HotelSpaViewUiHandlers extends BUiHandlers {
  
  
  /**
   * View has been initialized.
   */
  void viewDidLoad();
  
  void backTapped();
 
  
}
