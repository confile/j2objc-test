package majestella.core.app.mainNavigation;

 
import javax.inject.Inject;

import majestella.core.place.NameTokens;
import majestella.core.prototype.annotation.ContentSlot;
import majestella.core.prototype.annotation.ProxyStandard;
import majestella.core.prototype.eventBus.AbstractBEvent.Type;
import majestella.core.prototype.eventBus.BEventBus;
import majestella.core.prototype.mvp.BAbstractPresenter;
import majestella.core.prototype.mvp.BBaseView;
import majestella.core.prototype.mvp.BHasUiHandlers;
import majestella.core.prototype.mvp.proxy.BRevealContentHandler;
import majestella.core.prototype.mvp.proxy.Proxy;
import majestella.core.prototype.navigation.BPlaceManager;
import majestella.core.prototype.navigation.BPlaceRequest;

import com.google.auto.factory.AutoFactory;
import com.google.auto.factory.Provided;
 
@AutoFactory(className="MainNavigationPresenterFactory")
public class MainNavigationPresenter extends BAbstractPresenter<MainNavigationPresenter.MyView, MainNavigationPresenter.MyProxy> 
   implements MainNavigationViewUiHandlers {

  public interface MyView extends BBaseView, BHasUiHandlers<MainNavigationViewUiHandlers> {
  }
  
  @ProxyStandard
  public interface MyProxy extends Proxy<MainNavigationPresenter> {
  }  

  @ContentSlot
  public static final Type<BRevealContentHandler<?>> SLOT_MAIN = new Type<BRevealContentHandler<?>>();
  
  private final BPlaceManager placeManager; 
  
  @Inject
  public MainNavigationPresenter(@Provided BEventBus eventBus, BBaseView view, @Provided MyProxy proxy,
      @Provided BPlaceManager placeManager) {
    super(eventBus, (MyView)view, proxy, RevealType.Root); 
    
    this.placeManager = placeManager;   
    
    getView().setUiHandlers(this);     
  }
  
  @Override
  protected void onBind() {
    super.onBind();
    logger.info("MainNavigationPresenter - onBind()"); 
  }
    
  @Override
  protected void onReveal() {
    super.onReveal();
    logger.info("MainNavigationPresenter - onReveal()");
     
  }
  
  @Override
  protected void onHide() {
    super.onHide();
    logger.info("MainNavigationPresenter - onHide()");
  }
  
  @Override
  public void goToPage(int number) {
  	logger.info("MainNavigationPresenter - goToPage: "+number);
  	
  	String nameToken = "";
  	if (number == 0) {
  		nameToken = NameTokens.getLocationMain();
  	}
  	else if (number == 1) {
  		nameToken = NameTokens.getServiceSelection();
  	}
  	else if (number == 2) {
  		nameToken = NameTokens.getWishList();
  	}
  	else {
  		logger.severe("MainNavigationPresenter page: "+number+" is undefined");
  	}
  	
  	assert(nameToken != "");
  	
  	BPlaceRequest request = new BPlaceRequest.Builder()
  	  .nameToken(nameToken)
  	  .build();
  	placeManager.revealPlace(request);	  
  }
    
  
  // ---------------------------------------------
  // Events
  // ---------------------------------------------

 
  
}
