package majestella.core.app.locationMain;

import majestella.core.prototype.mvp.BUiHandlers;

public interface LocationMainViewUiHandlers extends BUiHandlers {
  
  
  /**
   * View has been initialized.
   */
  void viewDidLoad();
  
  
  /**
   * Requests that the presenter sets the
   * temperature in the view.
   */
  void requestSetTemperature();
  
  void serviceSelectionTapped();
  
  void hotelInfoTapped();
  
  void roomServiceTapped();
  
  void restaurantTapped();
  
  void hotelSpaTapped();
  
  void settingTapped();
  
}
