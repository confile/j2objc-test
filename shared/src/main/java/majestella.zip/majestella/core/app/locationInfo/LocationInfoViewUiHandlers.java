package majestella.core.app.locationInfo;

import majestella.core.prototype.mvp.BUiHandlers;

public interface LocationInfoViewUiHandlers extends BUiHandlers {
  
  
  /**
   * View has been initialized.
   */
  void viewDidLoad();
  
  void backTapped();
 
}
