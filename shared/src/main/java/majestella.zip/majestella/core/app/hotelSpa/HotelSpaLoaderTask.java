package majestella.core.app.hotelSpa;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import majestella.core.bootstrap.ParameterConfig;
import majestella.core.prototype.mvp.proxy.BAsyncCallback;
import majestella.core.rest.dto.GetResult;
import majestella.core.rest.dto.HotelSpaDto;
import android.os.AsyncTask;

/**
 * This class is used to comunicate with the server on a 
 * background thread.
 * @author Dr. Michael Gorski
 *
 */
public class HotelSpaLoaderTask extends AsyncTask<HotelSpaRequestList, Void, GetResult<HotelSpaDto>> {

  private final CountDownLatch latch = new CountDownLatch(1);
  private HotelSpaRequestList requestList = null;
  private GetResult<HotelSpaDto> callbackResult = null;
  
  
  @Override
  protected GetResult<HotelSpaDto> doInBackground(HotelSpaRequestList... params) {
    
    requestList = params[0];
    
    final Logger logger = Logger.getLogger(ParameterConfig.LOGGER_MAJESTELLA_NAME);
    logger.info("<<< HotelSpaLoaderTask - callServerHotelSpaActivity(): hotelId: "+requestList.hotelId);
    
    try { 
          
      requestList.hotelSpaRestService.get(requestList.hotelId, new BAsyncCallback<GetResult<HotelSpaDto>>() {
        
        @Override
        public void onFailure(Exception e) {
          logger.log(Level.SEVERE, 
              "HotelSpaLoaderTask - callServerHotelSpaActivity(): Cannot contact server.",
              e);
          callbackResult = null;
          latch.countDown();
        }
        
        @Override
        public void onSuccess(GetResult<HotelSpaDto> result) {
          logger.info(">>> HotelSpaLoaderTask - callServerHotelSpaActivity()");
          
          callbackResult = result;
          latch.countDown();
        }
      });
      
      if (latch.await(ParameterConfig.SERVER_REQUEST_TIMEOUT, TimeUnit.SECONDS)) {
        return callbackResult;
      }
      else {
        return null; // timeout
      }
    }
    catch(InterruptedException ex) {
      logger.severe("HotelSpaLoaderTask request interrupted error: "+ex);
      return null;
    } 
  }
  
  
  @Override
  protected void onPostExecute(GetResult<HotelSpaDto> result) {
    if (requestList.resultCallback != null) {
      requestList.resultCallback.onResult(result);
    } 
  }

}
