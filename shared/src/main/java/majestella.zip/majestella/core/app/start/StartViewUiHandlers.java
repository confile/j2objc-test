package majestella.core.app.start;

import majestella.core.prototype.mvp.BUiHandlers;

public interface StartViewUiHandlers extends BUiHandlers {
  
  /**
   * Login button tapped.
   */
  void loginButtonTapped();
  
  /**
   * Signup button was tapped.
   */
  void signupButtonTapped();
  
  void continueWithoutLogin();

  
  /**
   * Choose location button tapped.
   */
  void locationButtonTapped();
  
  
}
