package majestella.core.app.roomService;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import majestella.core.bootstrap.ParameterConfig;
import majestella.core.prototype.mvp.proxy.BAsyncCallback;
import majestella.core.rest.dto.GetResult;
import majestella.core.rest.dto.RoomServiceDomainDto;
import android.os.AsyncTask;

public class RoomServiceLoaderTask extends AsyncTask<RoomServiceRequestList, Void, GetResult<RoomServiceDomainDto>> {

  private final CountDownLatch latch = new CountDownLatch(1);
  private RoomServiceRequestList requestList = null;
  private GetResult<RoomServiceDomainDto> callbackResult = null;
  
  
  @Override
  protected GetResult<RoomServiceDomainDto> doInBackground(RoomServiceRequestList... params) {

    requestList = params[0];
    
    final Logger logger = Logger.getLogger(ParameterConfig.LOGGER_MAJESTELLA_NAME);
    logger.info("<<< RoomServiceLoaderTask - callServerRoomServiceActivity(): hotelId: "+requestList.hotelId);
    
    try {  
      requestList.roomServiceRestService.get(requestList.hotelId, new BAsyncCallback<GetResult<RoomServiceDomainDto>>() {
        
        @Override
        public void onFailure(Exception e) {
          logger.log(Level.SEVERE, 
              "RoomServiceLoaderTask - callServerRoomServiceActivity(): Cannot contact server.",
              e);
          callbackResult = null;
          latch.countDown();
        }
        
        @Override
        public void onSuccess(GetResult<RoomServiceDomainDto> result) {
          logger.info(">>> RoomServiceLoaderTask - callServerRoomServiceActivity(): count: "+
                result.getResult().getRoomServiceCategoryDtos().size());
          
          callbackResult = result;
          latch.countDown();
        }
      });
            
      if (latch.await(ParameterConfig.SERVER_REQUEST_TIMEOUT, TimeUnit.SECONDS)) {
        return callbackResult;
      }
      else {
        return null; // timeout
      }
    }
    catch(InterruptedException ex) {
      logger.severe("RoomServiceLoaderTask request interrupted error: "+ex);
      return null;
    } 
  }
  
  @Override
  protected void onPostExecute(GetResult<RoomServiceDomainDto> result) {
    if (requestList.resultCallback != null) {
      requestList.resultCallback.onResult(result);
    }    
  }
  
}
