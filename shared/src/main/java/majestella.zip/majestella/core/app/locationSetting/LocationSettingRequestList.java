package majestella.core.app.locationSetting;

import majestella.core.rest.LocationListRestService;
import majestella.core.rest.dto.LocationListDto;

public class LocationSettingRequestList {

  public interface ResultCallback {
    void onResult(LocationListDto locationListDto);
  }
  
  public double latitude;
  public double longitude;
  public int type;
  public String objectId;
  public LocationListRestService locationListRestService;
  public ResultCallback resultCallback;
  
  public LocationSettingRequestList(double latitude, double longitude, int type, String objectId, 
      LocationListRestService locationListRestService, ResultCallback resultCallback) {
    this.latitude = latitude;
    this.longitude = longitude;
    this.type = type;
    this.objectId = objectId;
    this.locationListRestService = locationListRestService;
    this.resultCallback = resultCallback;
  }
  
}
