package majestella.core.app.wishList.events;

 
import majestella.core.prototype.eventBus.AbstractBEvent;
import majestella.core.prototype.eventBus.BEventHandler;
import majestella.core.prototype.eventBus.BHasHandlers;


/**
 * This event is fired when the ServiceSelectionPresenter asks for the WishList size.
 * @author Dr. Michael Gorski
 *
 */
public class WishListSizeRequestEvent extends AbstractBEvent<WishListSizeRequestEvent.WishListSizeRequestHandler> {

  
  public static Type<WishListSizeRequestHandler> TYPE = new Type<WishListSizeRequestHandler>();
  
  public interface WishListSizeRequestHandler extends BEventHandler {
    void onWishListSizeRequested(WishListSizeRequestEvent event);
  }
   
  public WishListSizeRequestEvent() {
  }
  
  @Override
  public AbstractBEvent.Type<WishListSizeRequestHandler> getAssociatedType() {
    return TYPE;
  }
  
  public static Type<WishListSizeRequestHandler> getType() {
    return TYPE;
  }

  @Override
  protected void dispatch(WishListSizeRequestHandler handler) {
    handler.onWishListSizeRequested(this);
  }
  
  public static void fire(BHasHandlers source) {
    source.fireEvent(new WishListSizeRequestEvent());
  }
  
 
  
}
