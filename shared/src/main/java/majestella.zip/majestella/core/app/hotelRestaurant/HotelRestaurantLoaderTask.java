package majestella.core.app.hotelRestaurant;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import majestella.core.bootstrap.ParameterConfig;
import majestella.core.prototype.mvp.proxy.BAsyncCallback;
import majestella.core.rest.dto.GetResults;
import majestella.core.rest.dto.HotelRestaurantDto;
import android.os.AsyncTask;

/**
 * Handle server request on a background thread.
 * @author Dr. Michael Gorski
 *
 */
public class HotelRestaurantLoaderTask extends AsyncTask<HotelRestaurantRequestList, Void, GetResults<HotelRestaurantDto>> {

  private final CountDownLatch latch = new CountDownLatch(1);
  private GetResults<HotelRestaurantDto> callbackResult = null;
  private HotelRestaurantRequestList requestList = null;
  
  @Override
  protected GetResults<HotelRestaurantDto> doInBackground(HotelRestaurantRequestList... params) {
    
    requestList = params[0];
    
    final Logger logger = Logger.getLogger(ParameterConfig.LOGGER_MAJESTELLA_NAME);
    logger.info("<<< HotelRestaurantLoaderTask - callServerHotelRestaurantActivity(): hotelId: "+requestList.hotelId);
    
    try { 
      requestList.hotelRestaurantRestService.get(requestList.hotelId, new BAsyncCallback<GetResults<HotelRestaurantDto>>() {
        
        @Override
        public void onFailure(Exception e) {
          logger.log(Level.SEVERE, 
            "HotelRestaurantLoaderTask - callServerHotelRestaurantActivity(): Cannot contact server.",
            e);
          callbackResult = null;
          latch.countDown();
        }
        
        @Override
        public void onSuccess(GetResults<HotelRestaurantDto> result) {
          logger.info(">>> HotelRestaurantLoaderTask - callServerHotelRestaurantActivity(): count: "+result.getResults().size());

          callbackResult = result;
          latch.countDown();
        }
      });
      
      if (latch.await(ParameterConfig.SERVER_REQUEST_TIMEOUT, TimeUnit.SECONDS)) {
        return callbackResult;
      }
      else {
        return null; // timeout
      }
    }
    catch(InterruptedException ex) {
      logger.severe("HotelRestaurantLoaderTask request interrupted error: "+ex);
      return null;
    }     
  }
  
  
  @Override
  protected void onPostExecute(GetResults<HotelRestaurantDto> result) {
    if (requestList.resultCallback != null) {
      requestList.resultCallback.onResult(result);
    }
  }

}
