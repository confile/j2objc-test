package majestella.core.app.roomService;

import majestella.core.prototype.mvp.BUiHandlers;
import majestella.core.rest.dto.RoomServiceItemDto;

public interface RoomServiceViewUiHandlers extends BUiHandlers {
  
  /**
   * View has been initialized.
   */
  void viewDidLoad();
    
  void backTapped();
  
  void shoppingCardTapped();  
    
  /**
   * Check if a certain RoomServiceItemDto is present on 
   * the shopping card.
   * @param roomServiceItemDto
   * @return
   */
  boolean isItemOnCard(RoomServiceItemDto roomServiceItemDto);
  

  /**
   * Return the total number of all 
   * item on the shopping card.
   * @return
   */
  int getTotelItemsOnCard(); 
  
  
  /**
   * Return the total number of items 
   * of one type on the shopping card.
   * @param roomServiceItemDto
   * @return
   */
  int getTotalItemsByTypeOnCard(RoomServiceItemDto roomServiceItemDto);
  
  
  void addItemToCard(RoomServiceItemDto roomServiceItemDto);
  
    
}
