package majestella.core.app.hotelRestaurant;

import majestella.core.prototype.mvp.BUiHandlers;

public interface HotelRestaurantViewUiHandlers extends BUiHandlers {
  
  /**
   * View has been initialized.
   */
  void viewDidLoad();
  
  void backTapped();
  
   
}
