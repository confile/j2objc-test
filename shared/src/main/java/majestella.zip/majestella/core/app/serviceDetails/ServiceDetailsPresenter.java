package majestella.core.app.serviceDetails;

 
import javax.inject.Inject;

import majestella.core.app.serviceSelection.ServiceSelectionPresenter;
import majestella.core.app.serviceSelection.events.ServiceDetailsUpdateEvent;
import majestella.core.app.serviceSelection.events.ServiceDetailsUpdateEvent.ServiceDetailsUpdateHandler;
import majestella.core.app.wishList.WishListPresenter;
import majestella.core.i18n.BMessage;
import majestella.core.i18n.MessageKey;
import majestella.core.place.NameTokens;
import majestella.core.place.UrlTokens;
import majestella.core.plugins.email.EmailComposer;
import majestella.core.plugins.email.EmailComposerOptions;
import majestella.core.plugins.inappbrowser.Inappbrowser;
import majestella.core.prototype.annotation.NameToken;
import majestella.core.prototype.annotation.ProxyEvent;
import majestella.core.prototype.eventBus.BEventBus;
import majestella.core.prototype.mvp.BAbstractPresenter;
import majestella.core.prototype.mvp.BBaseView;
import majestella.core.prototype.mvp.BHasUiHandlers;
import majestella.core.prototype.mvp.proxy.BRevealContentEvent;
import majestella.core.prototype.mvp.proxy.ProxyPlace;
import majestella.core.prototype.navigation.BPlaceManager;
import majestella.core.prototype.navigation.BPlaceRequest;
import majestella.core.rest.ServiceDetailsRestService;
import majestella.core.rest.dto.BooleanDto;
import majestella.core.rest.dto.GetResult;
import majestella.core.rest.dto.ServiceCardDto;

import com.google.auto.factory.AutoFactory;
import com.google.auto.factory.Provided;
import com.google.common.base.Strings;

import dagger.Lazy;
 
@AutoFactory(className="ServiceDetailsPresenterFactory")
public class ServiceDetailsPresenter extends BAbstractPresenter<ServiceDetailsPresenter.MyView, ServiceDetailsPresenter.MyProxy> 
	implements ServiceDetailsViewUiHandlers, ServiceDetailsUpdateHandler {

  public interface MyView extends BBaseView, BHasUiHandlers<ServiceDetailsViewUiHandlers> {
    
    void callPhoneNumber(String number);
    
  }
  
  @NameToken(NameTokens.serviceDetails)
  public interface MyProxy extends ProxyPlace<ServiceDetailsPresenter> {
  }
  
  private ServiceCardDto serviceCardDto = null;
  private boolean showInWishList = false;
  
  
  private final BPlaceManager placeManager; 
  private final Lazy<Inappbrowser> lazyInappbrowser;
  private final Lazy<EmailComposer> lazyEmailComposer;
  private final BMessage message;
  private final Lazy<ServiceDetailsRestService> lazyServiceDetailsRestService;
  
  
  @Inject
  public ServiceDetailsPresenter(@Provided BEventBus eventBus, BBaseView view, @Provided MyProxy proxy,
      @Provided BPlaceManager placeManager, @Provided Lazy<Inappbrowser> lazyInappbrowser, 
      @Provided Lazy<EmailComposer> lazyEmailComposer, @Provided BMessage message, 
      @Provided Lazy<ServiceDetailsRestService> lazyServiceDetailsRestService) {
    super(eventBus, (MyView)view, proxy, ServiceSelectionPresenter.SLOT_DETAILS); 
    
    this.placeManager = placeManager;   
    this.lazyInappbrowser = lazyInappbrowser;
    this.lazyEmailComposer = lazyEmailComposer;
    this.message = message;
    this.lazyServiceDetailsRestService = lazyServiceDetailsRestService;
    
    getView().setUiHandlers(this);     
  }
  
  
  @Override
  protected void onBind() {
    super.onBind();
    logger.info("ServiceDetailsPresenter - onBind()"); 
  }
  
  
  @Override
  public void prepareFromRequest(BPlaceRequest request) {
    super.prepareFromRequest(request);
    
    // check if presenter should be revealed in wishList 
    showInWishList = Boolean.valueOf(request.getParameter(UrlTokens.SHOW_IN_WISHLIST, "false"));
    
    logger.info("ServiceDetailsPresenter - prepareFromRequest()"); 
  }
  
  
  @Override
  protected void revealInParent() {
    logger.info("ServiceDetailsPresenter - revealInParent()"); 
    if (showInWishList) {
      BRevealContentEvent.fire(this, WishListPresenter.SLOT_MAIN, this);
    }
    else {
      super.revealInParent();
    }
  }
  
    
  @Override
  protected void onReveal() {
    super.onReveal();
    logger.info("ServiceDetailsPresenter - onReveal()");
  }
  
  @Override
  protected void onHide() {
    super.onHide();
    logger.info("ServiceDetailsPresenter - onHide()");
     
  }
  
  private void callServerServiceDetailsAction() {
    
    ServiceDetailsRequestList requestList = new ServiceDetailsRequestList(serviceCardDto.getId(), 
        lazyServiceDetailsRestService.get(), 
        new ServiceDetailsRequestList.ResultCallback() {
          
          @Override
          public void onResult(GetResult<BooleanDto> result) {
          }
        });
    
    // call server on a background thread
    new ServiceDetailsLoaderTask().execute(requestList);
    
    
    // TODO: delete OLD
//    logger.info("<<< ServiceDetailsPresenter - callServerServiceDetailsAction()");
//    
//    lazyServiceDetailsRestService.get().post(serviceCardDto.getId(), 
//        new BAsyncCallback<GetResult<BooleanDto>>() {
//      
//      @Override
//      public void onFailure(Exception e) {
//        logger.log(Level.SEVERE, 
//            "ServiceDetailsPresenter - callServerServiceDetailsAction(): Cannot contact server.",
//            e);
//      }
//      
//      @Override
//      public void onSuccess(GetResult<BooleanDto> result) {
//        logger.info(">>> ServiceDetailsPresenter - callServerServiceDetailsAction(): result: "+result);
//      }
//    });
 }
   
 
  // ---------------------------------------------
  // UiHandlers
  // ---------------------------------------------

  
  @Override
  public ServiceCardDto getData() {
    return this.serviceCardDto;
  }
  
  
  @Override
  public void backTapped() {
    placeManager.navigateBack();
  }
 
  @Override
  public void bookingTapped() {
    logger.info("ServiceDetailsPresenter - bookingTapped()");
    if (!Strings.isNullOrEmpty(serviceCardDto.getBookingUrl())) {
      lazyInappbrowser.get().openWindow(serviceCardDto.getBookingUrl());
    }
    else if (!Strings.isNullOrEmpty(serviceCardDto.getBookingEmail())) {
      EmailComposerOptions data = new EmailComposerOptions();
      data.setTo(serviceCardDto.getBookingEmail());
      data.setSubject(message.lookup(MessageKey.booking)+" "+serviceCardDto.getTitle());
      lazyEmailComposer.get().open(data);
    }
    else if (!Strings.isNullOrEmpty(serviceCardDto.getBookingPhone())) {
      getView().callPhoneNumber(serviceCardDto.getBookingPhone());
    }
     
    // report booking to server
    callServerServiceDetailsAction();
  } 
  
  
  // ---------------------------------------------
  // Events
  // ---------------------------------------------

  @ProxyEvent
  @Override
  public void onServiceDetailsUpdated(ServiceDetailsUpdateEvent event) {
    logger.info("ServiceDetailsPresenter - onServiceDetailsUpdated()");
    this.serviceCardDto = event.getServiceCardDto();
  }
  
  
}
