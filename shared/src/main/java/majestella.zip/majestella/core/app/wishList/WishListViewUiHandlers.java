package majestella.core.app.wishList;

import majestella.core.prototype.mvp.BUiHandlers;
import majestella.core.rest.dto.ServiceCardDto;

public interface WishListViewUiHandlers extends BUiHandlers {

  /**
   * Return the number of items on the wish list.
   * @return
   */
  int getWishListSize();
 
  /**
   * Get the wish list item at a certain index.
   * @param index
   * @return
   */
  ServiceCardDto getWishListItem(int index);
  
  void removeWishListItem(int index);
  
  /**
   * User tapped an item in the wishList.
   * @param index
   */
  void wishListItemTapped(int index);
  
}
