package majestella.core.app.database;

import java.util.logging.Logger;

import javax.inject.Inject;

import majestella.core.app.wishList.events.WishListSizeRequestEvent;
import majestella.core.app.wishList.events.WishListSizeRequestEvent.WishListSizeRequestHandler;
import majestella.core.app.wishList.events.WishListSizeResponseEvent;
import majestella.core.bootstrap.ParameterConfig;
import majestella.core.plugins.database.ScalarCallback;
import majestella.core.plugins.database.VoidCallback;
import majestella.core.plugins.database.serviceCard.ServiceCardDataService;
import majestella.core.prototype.eventBus.BEventBus;
import dagger.Lazy;


public class ServiceCardDatabaseHelper implements WishListSizeRequestHandler {

  private final Lazy<ServiceCardDataService> lazyServiceCardDataService;
  private final Logger logger;
  private final BEventBus eventBus;
  
  
  @Inject
  public ServiceCardDatabaseHelper(Lazy<ServiceCardDataService> lazyServiceCardDataService, BEventBus eventBus) {

    this.lazyServiceCardDataService = lazyServiceCardDataService;
    this.eventBus = eventBus;
    
    logger = Logger.getLogger(ParameterConfig.LOGGER_MAJESTELLA_NAME); // set the buddyis logger
    logger.info("=== ServiceCardDatabaseHelper() init :"+this);
    logger.info("=== ServiceCardDatabaseHelper() init AppDataService :"+lazyServiceCardDataService.get());
    
    // register event handler
    eventBus.addHandler(WishListSizeRequestEvent.getType(), this);
    
    lazyServiceCardDataService.get().initTable(new VoidCallback() {
      
      @Override
      public void onFailure(String error) {
        logger.severe("### ServiceCardDatabaseHelper(): initTable(): onFailure(): "+error);
      }
      
      @Override
      public void onSuccess() {
        logger.info("||| ServiceCardDatabaseHelper(): initTable(): onSuccess()");        
      }
    }); 
  }
  
  // ---------------------------------------------
  // Events
  // ---------------------------------------------

  
  @Override
  public void onWishListSizeRequested(WishListSizeRequestEvent event) {
    lazyServiceCardDataService.get().countAll(new ScalarCallback<Integer>() {
      
      @Override
      public void onFailure(String error) {
        logger.severe("### ServiceCardDatabaseHelper(): countAll(): onFailure(): "+error);
      }
      
      @Override
      public void onSuccess(Integer result) {
        logger.info("||| ServiceCardDatabaseHelper(): countAll(): result: "+result);
        eventBus.fireEvent(new WishListSizeResponseEvent(result.intValue())); 
      }
    });
  }
  
  
}
