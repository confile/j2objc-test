package majestella.core.app.database;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.inject.Inject;

import majestella.core.bootstrap.ParameterConfig;
import majestella.core.plugins.database.ListCallback;
import majestella.core.plugins.database.VoidCallback;
import majestella.core.plugins.database.app.AppDataService;
import dagger.Lazy;


public class AppDatabaseHelper {

  private final Lazy<AppDataService> lazyAppDataService;
  private final Logger logger;
//  private final Lazy<StickerDataService> lazyStickerDataService;
//  private final Lazy<StickerGroupDataService> lazyStickerGroupDataService;
//  private final Lazy<UserDataService> lazyUserDataService;
//  private final Lazy<ItemDataService> lazyItemDataService; 
  
  @Inject
  public AppDatabaseHelper(Lazy<AppDataService> lazyAppDataService) {
    this.lazyAppDataService = lazyAppDataService;
//    this.lazyStickerDataService = lazyStickerDataService; 
//    this.lazyStickerGroupDataService = lazyStickerGroupDataService;
//    this.lazyUserDataService = lazyUserDataService;
//    this.lazyItemDataService = lazyItemDataService; 
    
    logger = Logger.getLogger(ParameterConfig.LOGGER_MAJESTELLA_NAME); // set the buddyis logger
    logger.info("=== AppDatabaseHelper() init :"+this);
    logger.info("=== AppDatabaseHelper() init AppDataService :"+lazyAppDataService.get());
    
    lazyAppDataService.get().initTable(new VoidCallback() {
      @Override
      public void onFailure(String error) { 
        logger.log(Level.SEVERE, "### AppDatabaseHelper(): initTable(): onFailure(): "+error);
      }
      
      @Override
      public void onSuccess() {
        logger.info("||| AppDatabaseHelper(): initTable(): onSuccess()");
      }
    });
  }
 
  
  public void update(String newAppVersion) {
    logger.info("AppDatabaseHelper - update(): appVersion: "+newAppVersion);
    
    final String appVersion = newAppVersion;
     
    lazyAppDataService.get().get(new ListCallback<String>() {
      
      @Override
      public void onFailure(String error) { 
//        logger.log(Level.SEVERE, "### AppDatabaseHelper - update(): onFailure(): "+error);
        reInitializeAllTables(appVersion);
      }
      
      @Override
      public void onSuccess(List<String> result) {
        logger.info("||| AppDatabaseHelper - update(): onSuccess()");
        if (result.size() > 0) {
          String databaseVersion = result.get(0);
          if (!appVersion.equals(databaseVersion)) {
            logger.info("AppDatabaseHelper - update(): appVersion("+appVersion+") != databaseVersion("+databaseVersion+")");
            reInitializeAllTables(appVersion);
          }
          else {
            logger.info("AppDatabaseHelper - update(): database structure is in sync");
          }
        }
        else {
          reInitializeAllTables(appVersion);
        }        
      }
    });
  }
  
  
  private void reInitializeAllTables(final String appVersion) {
    logger.info("AppDatabaseHelper - reInitializeAllTables()");
    
    lazyAppDataService.get().dropTable(new VoidCallback() {
      
      @Override
      public void onFailure(String error) {
        logger.info("### AppDatabaseHelper - reInitializeAllTables(): appDataService.dropTable(): onFailure(): "+error);
      }
      
      @Override
      public void onSuccess() { 
        lazyAppDataService.get().initTable(new VoidCallback() {
          
          @Override
          public void onFailure(String error) {
            logger.info("### AppDatabaseHelper - reInitializeAllTables(): appDataService.initTable(): onFailure(): "+error);
          }
          
          @Override
          public void onSuccess() { 
            lazyAppDataService.get().insertOrReplace(appVersion, new VoidCallback() {
              
              @Override
              public void onFailure(String error) {
                logger.severe("### AppDatabaseHelper - reInitializeAllTables(): appDataService.insertOrReplace(): onFailure(): "+error);
              }
              
              @Override
              public void onSuccess() {
                logger.info("AppDatabaseHelper - reInitializeAllTables(): created appData table");
              }
            });
            
          }
        });
      }
    });
    
    
    // user table
//    lazyUserDataService.get().dropTable(new VoidCallback() {
//      
//      @Override
//      public void onFailure(String error) {
//        logger.severe("### AppDatabaseHelper - reInitializeAllTables(): userDataService.dropTable(): onFailure(): "+error);
//      }
//      
//      @Override
//      public void onSuccess() {
//        lazyUserDataService.get().initTable(new VoidCallback() {
//          
//          @Override
//          public void onFailure(String error) {
//            logger.severe("### AppDatabaseHelper - reInitializeAllTables(): userDataService.initTable(): onFailure(): "+error);
//          }
//          
//          @Override
//          public void onSuccess() {
//            logger.info("AppDatabaseHelper - reInitializeAllTables(): created user table");
//          }
//        });
//      }
//    });
    
    
    // item table
//    lazyItemDataService.get().dropTable(new VoidCallback() {
//      
//      @Override
//      public void onFailure(String error) {
//        logger.severe("### AppDatabaseHelper - reInitializeAllTables(): itemDataService.dropTable(): onFailure(): "+error);
//      }
//      
//      @Override
//      public void onSuccess() {
//        lazyItemDataService.get().initTable(new VoidCallback() {
//          
//          @Override
//          public void onFailure(String error) {
//            logger.severe("### AppDatabaseHelper - reInitializeAllTables(): itemDataService.initTable(): onFailure(): "+error);
//          }
//          
//          @Override
//          public void onSuccess() {
//            logger.info("AppDatabaseHelper - reInitializeAllTables(): created item table");
//          }
//        });
//      }
//    });
    
    
    // sticker table
//    lazyStickerDataService.get().dropTable(new VoidCallback() {
//      
//      @Override
//      public void onFailure(String error) {
//        logger.severe("### AppDatabaseHelper - reInitializeAllTables(): stickerDataService.dropTable(): onFailure(): "+error);
//      }
//      
//      @Override
//      public void onSuccess() {
//        lazyStickerDataService.get().initTable(new VoidCallback() {
//          
//          @Override
//          public void onFailure(String error) {
//            logger.severe("### AppDatabaseHelper - reInitializeAllTables(): stickerDataService.initTable(): onFailure(): "+error);
//          }
//          
//          @Override
//          public void onSuccess() {
//            logger.info("AppDatabaseHelper - reInitializeAllTables(): created sticker table");
//          }
//        });
//      }
//    });

    
    // stickerGroup table
//    lazyStickerGroupDataService.get().dropTable(new VoidCallback() {
//      
//      @Override
//      public void onFailure(String error) {
//        logger.severe("### AppDatabaseHelper - reInitializeAllTables(): stickerGroupDataService.dropTable(): onFailure(): "+error);
//      }
//      
//      @Override
//      public void onSuccess() {
//        lazyStickerGroupDataService.get().initTable(new VoidCallback() {
//          
//          @Override
//          public void onFailure(String error) {
//            logger.severe("### AppDatabaseHelper - reInitializeAllTables(): stickerGroupDataService.initTable(): onFailure(): "+error);
//          }
//          
//          @Override
//          public void onSuccess() {
//            logger.info("AppDatabaseHelper - reInitializeAllTables(): created stickerGroup table");
//          }
//        });
//      }
//    });
    
    

    
    
  }
  
  
}
