package majestella.core.app.locationSetting;


/**
 * This class is used to store location informations 
 * when the app is started with location specific parameters 
 * in the meta tag from mobile Safari.
 * 
 * @author Dr. Michael Gorski
 *
 */
public class LocationHolder {

  private static LocationHolder instance;
  
  private String id = "";
  private int type = -1;
  
  
  private LocationHolder() {
  }
  
  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public int getType() {
    return type;
  }

  public void setType(int type) {
    this.type = type;
  }
  
  public void setType(String typeText) {
    if (typeText.equals("place")) {
      type = 0;
    }
    else if (typeText.equals("hotel")) {
      type = 1;
    }
    else if (typeText.equals("tourismn")) {
      type = 2;
    }    
  }
  
  
  public static LocationHolder getSharedInstance() {
    if (instance == null) {
      instance = new LocationHolder();
    }
    return instance;
  }
  
   
  
  
}
