package majestella.core.app.roomServiceCard;

 
import java.util.Date;
import java.util.Map;

import javax.inject.Inject;

import majestella.core.app.locationMain.events.LocationChangedEvent;
import majestella.core.app.locationMain.events.LocationChangedEvent.LocationChangedHandler;
import majestella.core.app.roomService.RoomServicePresenter;
import majestella.core.app.roomServiceCard.RoomServiceCardRequestList.ResultCallback;
import majestella.core.place.NameTokens;
import majestella.core.place.UrlTokens;
import majestella.core.plugins.appInfo.AppInfo;
import majestella.core.plugins.appInfo.AppInfoUserDefaultKey;
import majestella.core.prototype.annotation.NameToken;
import majestella.core.prototype.eventBus.BEventBus;
import majestella.core.prototype.mvp.BAbstractPresenter;
import majestella.core.prototype.mvp.BBaseView;
import majestella.core.prototype.mvp.BHasUiHandlers;
import majestella.core.prototype.mvp.proxy.ProxyPlace;
import majestella.core.prototype.navigation.BPlaceManager;
import majestella.core.prototype.navigation.BPlaceRequest;
import majestella.core.rest.RoomServiceRestService;
import majestella.core.rest.dto.BooleanDto;
import majestella.core.rest.dto.GetResult;
import majestella.core.rest.dto.RoomServiceItemDto;
import majestella.core.rest.dto.RoomServiceOrderDto;

import com.google.auto.factory.AutoFactory;
import com.google.auto.factory.Provided;
import com.google.common.base.Strings;

import dagger.Lazy;
 
@AutoFactory(className="RoomServiceCardPresenterFactory")
public class RoomServiceCardPresenter extends BAbstractPresenter<RoomServiceCardPresenter.MyView, RoomServiceCardPresenter.MyProxy> 
	implements RoomServiceCardViewUiHandlers, LocationChangedHandler {

  public interface MyView extends BBaseView, BHasUiHandlers<RoomServiceCardViewUiHandlers> {
  
     void getUserData(String lastName, int roomNumber, long departureDateNumber);
  
  }
  
  @NameToken(NameTokens.roomServiceCard)
  public interface MyProxy extends ProxyPlace<RoomServiceCardPresenter> {
  }
  
  private String locationId = "";
  
  private final BPlaceManager placeManager; 
  private final Lazy<RoomServiceRestService> lazyRoomServiceRestService; 
  private final Lazy<AppInfo> lazyAppinfo;
  
  
  @Inject
  public RoomServiceCardPresenter(@Provided BEventBus eventBus, BBaseView view, @Provided MyProxy proxy,
      @Provided BPlaceManager placeManager, 
      @Provided Lazy<RoomServiceRestService> lazyRoomServiceRestService, 
      @Provided Lazy<AppInfo> lazyAppinfo) {
    super(eventBus, (MyView)view, proxy, RoomServicePresenter.SLOT_CARD); 
    
    this.placeManager = placeManager;  
    this.lazyRoomServiceRestService = lazyRoomServiceRestService;
    this.lazyAppinfo = lazyAppinfo;
    
    getView().setUiHandlers(this);     
  }
  
  
  @Override
  protected void onBind() {
    super.onBind();
    logger.info("RoomServiceCardPresenter - onBind()"); 
    
    addRegisteredHandler(LocationChangedEvent.getType(), this);
  }
  
  @Override
  public void prepareFromRequest(BPlaceRequest request) {
    super.prepareFromRequest(request);
    
    logger.info("RoomServiceCardPresenter - prepareFromRequest()");
    
    String newLocationId = request.getParameter(UrlTokens.LOCATION_ID, ""); 
    
    if ( (!newLocationId.equals(locationId)) && (!newLocationId.equals("")) ) {
      logger.info("RoomServiceCardPresenter - prepareFromRequest() new location"); 
      locationId = newLocationId;
    }
  }
    
  @Override
  protected void onReveal() {
    super.onReveal();
    logger.info("RoomServiceCardPresenter - onReveal()");
  }
  
  @Override
  protected void onHide() {
    super.onHide();
    logger.info("RoomServiceCardPresenter - onHide()");     
  }
  
  
  private void callServerRoomServiceAction(Map<RoomServiceItemDto, Integer> itemsMap, String lastName, 
      int roomNumber, Date departureDate) {
//    logger.info("<<< RoomServiceCardPresenter - callServerRoomServiceAction(): locationId: "+this.locationId+
//        " itemsMap.size(): "+itemsMap.size());
    
    RoomServiceOrderDto roomServiceOrderDto = new RoomServiceOrderDto();
    for(Map.Entry<RoomServiceItemDto, Integer> entry : itemsMap.entrySet()) {
      roomServiceOrderDto.addItem(entry.getKey().getId(), entry.getValue());
    }
    
    
    RoomServiceCardRequestList requestList = new RoomServiceCardRequestList(locationId, roomServiceOrderDto, 
        lastName, roomNumber, departureDate, lazyRoomServiceRestService.get(), 
        new ResultCallback() {
          
          @Override
          public void onResult(GetResult<BooleanDto> result) {
            if (result != null) {
              if (result.getResult().getValue()) {        
                ShoppingCard.getSharedInstance().clearCard();
                
                BPlaceRequest request = new BPlaceRequest.Builder()
                  .nameToken(NameTokens.getLocationMain()) 
                  .with(UrlTokens.LOCATION_ID, locationId)
                  .build();
                placeManager.revealPlace(request); 
                
              }
              else {
                // TODO show error that order could not be done
              }
            }
          }
        });
    
    // call server on a background thread
    new RoomServiceCardLoaderTask().execute(requestList);
    
    
    // TODO: delete OLD
//    lazyRoomServiceRestService.get().sendShoppingCard(locationId, roomServiceOrderDto, 
//        lastName, roomNumber, departureDate,
//        new BAsyncCallback<GetResult<BooleanDto>>() {
//      
//      @Override
//      public void onFailure(Exception e) {
//        logger.log(Level.SEVERE, 
//            "RoomServiceCardPresenter - callServerRoomServiceAction(): Cannot contact server.",
//            e);
//      }
//      
//      @Override
//      public void onSuccess(GetResult<BooleanDto> result) {
//        logger.info(">>> RoomServicePresenter - callServerRoomServiceActivity(): result: "+result.getResult().getValue());
//        if (result.getResult().getValue()) {        
//          ShoppingCard.getSharedInstance().clearCard();
//          
//          BPlaceRequest request = new BPlaceRequest.Builder()
//            .nameToken(NameTokens.getLocationMain()) 
//            .with(UrlTokens.LOCATION_ID, locationId)
//            .build();
//          placeManager.revealPlace(request); 
//          
//        }
//        else {
//          // TODO show error that order could not be done
//        }
//      }            
//    });    
  }
   
 
  // ---------------------------------------------
  // UiHandlers
  // ---------------------------------------------

  
  @Override
  public void backTapped() {
    placeManager.navigateBack();
  }
 
  @Override
  public int getTotelItemsOnCard() {
    return ShoppingCard.getSharedInstance().getTotalItemsCount();
  }
  
  @Override
  public double getTotalPriceOfAllItems() {
    return ShoppingCard.getSharedInstance().getTotalPriceOfAllItems();
  }
  
  @Override
  public RoomServiceItemDto getItem(int index) { 
    return ShoppingCard.getSharedInstance().getItem(index);
  }
  
  @Override
  public int getTotalItemsCountByType(RoomServiceItemDto roomServiceItemDto) { 
    return ShoppingCard.getSharedInstance().getTotalItemsCountByType(roomServiceItemDto);
  }
  
  @Override
  public int getNumberOfItemTypesOnCard() { 
    return ShoppingCard.getSharedInstance().getNumberOfItemTypesOnCard();
  }
  
  @Override
  public void removeAllItemsOfTypeAtIndexFromCard(int index) {
    ShoppingCard.getSharedInstance().removeAllItemsOfTypeAtIndexFromCard(index);
  }
  
  @Override
  public void addItemToCard(RoomServiceItemDto roomServiceItemDto) {
    ShoppingCard.getSharedInstance().addItemToCard(roomServiceItemDto);
  }
  
  @Override
  public void removeItemFromCard(int index) {
    ShoppingCard.getSharedInstance().removeItemFromCard(index);
  }
  
  @Override
  public double getTotalPriceByType(RoomServiceItemDto roomServiceItemDto) {
    return ShoppingCard.getSharedInstance().getTotalPriceByType(roomServiceItemDto);
  }
  
  @Override
  public void checkOrder() {
    String lastName = lazyAppinfo.get().getUserDefaultString(AppInfoUserDefaultKey.lastName);
    int roomNumber = (int)lazyAppinfo.get().getUserDefaultDouble(AppInfoUserDefaultKey.roomNumber);
    long departureDateNumber = (long)lazyAppinfo.get().getUserDefaultDouble(AppInfoUserDefaultKey.departureDateString);
    
    // check if the departureDate is still valid
    Date currentDepartureDate = new Date();
    if (departureDateNumber > 0) { 
      currentDepartureDate = new Date(departureDateNumber); 
    }
    Date today = new Date();
    if (currentDepartureDate.before(today)) {
      departureDateNumber = today.getTime();
      roomNumber = 0;
      lazyAppinfo.get().setUserDefaultString(AppInfoUserDefaultKey.departureDateString, "");
    }
    
    logger.info("RoomServiceCardPresenter - checkOrder(): currentDepartureDate: "+currentDepartureDate+" departureDateNumber: "+departureDateNumber);
    
    // request user data
    getView().getUserData(lastName, roomNumber, departureDateNumber);
    
  }
  
  
  @Override
  public void submitOrder(String lastName, int roomNumber, long departureDateNumber) {
       
    logger.info("RoomServiceCardPresenter - submitOrder(): departureDateNumber: "+departureDateNumber+ " date: "+new Date(departureDateNumber));
    if (!Strings.isNullOrEmpty(lastName)) {
      lazyAppinfo.get().setUserDefaultString(AppInfoUserDefaultKey.lastName, lastName);
    }
    if (roomNumber > 0) {
      lazyAppinfo.get().setUserDefaultDouble(AppInfoUserDefaultKey.roomNumber, roomNumber);
    }
    if (departureDateNumber > 0) {
      lazyAppinfo.get().setUserDefaultDouble(AppInfoUserDefaultKey.departureDateString, departureDateNumber);
    }
    
    Map<RoomServiceItemDto, Integer> itemsMap = ShoppingCard.getSharedInstance().getItemMap();    
    callServerRoomServiceAction(itemsMap, lastName, roomNumber, new Date(departureDateNumber));  
  }
  
  // ---------------------------------------------
  // Events
  // ---------------------------------------------

  
  @Override
  public void onLocationChanged(LocationChangedEvent event) {
    logger.info("RoomServiceCardPresenter - onLocationChanged()");
    // clear ShoppingCard on location change
    ShoppingCard.getSharedInstance().clearCard();
  }
 
  
}
