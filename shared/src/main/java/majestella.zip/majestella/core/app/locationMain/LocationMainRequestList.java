package majestella.core.app.locationMain;

import majestella.core.rest.LocationRestService;
import majestella.core.rest.dto.GetResult;
import majestella.core.rest.dto.LocationDto;

public class LocationMainRequestList {

  public interface ResultCallback {
    void onResult(GetResult<LocationDto> result);
  }
  
  public String locationId;
  public int locationType;
  public LocationRestService locationRestService;
  public ResultCallback resultCallback;
  
  
  public LocationMainRequestList(String locationId, int locationType, LocationRestService locationRestService,
      ResultCallback resultCallback) {
    this.locationId = locationId;
    this.locationType = locationType;
    this.locationRestService = locationRestService;
    this.resultCallback = resultCallback;
  }
  
  
}
