package majestella.core.app.locationSetting;

import java.util.List;

import javax.inject.Inject;

import majestella.core.app.locationSetting.LocationSettingRequestList.ResultCallback;
import majestella.core.place.NameTokens;
import majestella.core.place.UrlTokens;
import majestella.core.prototype.annotation.NameToken;
import majestella.core.prototype.eventBus.BEventBus;
import majestella.core.prototype.mvp.BAbstractPresenter;
import majestella.core.prototype.mvp.BBaseView;
import majestella.core.prototype.mvp.BHasUiHandlers;
import majestella.core.prototype.mvp.proxy.ProxyPlace;
import majestella.core.prototype.navigation.BPlaceManager;
import majestella.core.prototype.navigation.BPlaceRequest;
import majestella.core.prototype.navigation.annimation.BModalAnimation;
import majestella.core.prototype.navigation.annimation.RevealAnimatableDisplayRootContentEvent;
import majestella.core.rest.LocationListRestService;
import majestella.core.rest.dto.LocationListDto;
import majestella.core.rest.dto.LocationListItemDto;

import com.google.auto.factory.AutoFactory;
import com.google.auto.factory.Provided;

import dagger.Lazy;

@AutoFactory(className = "LocationSettingPresenterFactory")
public class LocationSettingPresenter extends
    BAbstractPresenter<LocationSettingPresenter.MyView, LocationSettingPresenter.MyProxy> implements
    LocationSettingViewUiHandlers {

  public interface MyView extends BBaseView, BHasUiHandlers<LocationSettingViewUiHandlers> {
    
    /**
     * Set a list of all available locations.
     * @return
     */   
    void setLocations(List<LocationListItemDto> locationDtos); 
    
  }

  
  @NameToken(NameTokens.locationSetting)
  public interface MyProxy extends ProxyPlace<LocationSettingPresenter> {
  }
  
  private boolean showModal = false;
  private LocationListDto locationListDto = null; 

  private final BPlaceManager placeManager;
  private final Lazy<LocationListRestService> lazyLocationRestService;

  @Inject
  public LocationSettingPresenter(@Provided BEventBus eventBus, BBaseView view,
      @Provided MyProxy proxy, @Provided BPlaceManager placeManager, 
      @Provided Lazy<LocationListRestService> lazyLocationRestService) {
    super(eventBus, (MyView) view, proxy, RevealType.Root);

    this.placeManager = placeManager;
    this.lazyLocationRestService = lazyLocationRestService;
    
    getView().setUiHandlers(this);
  }

  
  @Override
  protected void onBind() {
    super.onBind();
    logger.info("LocationSettingPresenter - onBind()");
  }
  
  
  @Override
  public void prepareFromRequest(BPlaceRequest request) {
    super.prepareFromRequest(request);

    // check if presenter should be revealed modally 
    showModal = Boolean.valueOf(request.getParameter(UrlTokens.PRESENT_MODAL, "false"));
    
    logger.info("LocationSettingPresenter - prepareFromRequest()");    
  }
  
  
  @Override
  protected void revealInParent() {
    logger.info("LocationSettingPresenter - revealInParent(): showModal: "+showModal);
    if (showModal) {
      RevealAnimatableDisplayRootContentEvent.fire(this, this, new BModalAnimation(false));
    }
    else {
      super.revealInParent();
    }
  }
  
  
  @Override
  protected void onReveal() {
    super.onReveal();
    logger.info("LocationSettingPresenter - onReveal()");
  }
  
  @Override
  protected void onHide() {
    super.onHide();
    logger.info("LocationSettingPresenter - onHide()");
  }
    
  private void callServerLocationAction(double latitude, double longitude, int type, String objectId) {

    LocationSettingRequestList requestList = new LocationSettingRequestList(latitude, longitude, type, objectId, 
        lazyLocationRestService.get(), 
        new ResultCallback() {
          
          @Override
          public void onResult(LocationListDto locationListDto) {
            logger.info("LocationSettingPresenter - callServerLocationAction(): update UI");
            
            //        if (locationListDto.getDirectSelection()) {
            //          // TODO: direct selection
            //        }
            //        else {
            ////          getView().setLocations(locationListDto.getDtos()); 
            //        }
            
            if (locationListDto != null) {
              getView().setLocations(locationListDto.getDtos());
            }
          }
        });
    
    // call server on a background thread
    new LocationSettingLoaderTask().execute(requestList);
  }
  
  
  // ---------------------------------------------
  // UiHandlers
  // ---------------------------------------------

  @Override
  public void backTapped() {
    placeManager.navigateBack();
  }

  
  @Override
  public void requestLocations(final double latitude, final double longitude) {
    logger.info("LocationSettingPresenter -  requestLocations()");
    callServerLocationAction(latitude, longitude, -1, "");     
  }
  
  
  @Override
  public void requestLocation(int type, String objectId) {
    logger.info("LocationSettingPresenter -  requestLocation()");
    callServerLocationAction(-1, -1, type, objectId);
  }
  
  
  @Override
  public void selectLocation(LocationListItemDto locationDto) {
    BPlaceRequest request = new BPlaceRequest.Builder()
      .nameToken(NameTokens.getLocationMain())
      .with(UrlTokens.LOCATION_ID, locationDto.getId()) 
      .with(UrlTokens.LOCATION_TYPE, ""+locationDto.getType())
      .build();
    placeManager.revealPlace(request); 
  }

  

  // ---------------------------------------------
  // Events
  // ---------------------------------------------

}
