package majestella.core.app.serviceDetails;

import majestella.core.rest.ServiceDetailsRestService;
import majestella.core.rest.dto.BooleanDto;
import majestella.core.rest.dto.GetResult;

public class ServiceDetailsRequestList {

  public interface ResultCallback {
    void onResult(GetResult<BooleanDto> result);
  }
  
  public String serviceCardId;
  public ServiceDetailsRestService serviceDetailsRestService;
  public ResultCallback resultCallback;
  
  public ServiceDetailsRequestList(String serviceCardId, ServiceDetailsRestService serviceDetailsRestService,
      ResultCallback resultCallback) {
    this.serviceCardId = serviceCardId;
    this.serviceDetailsRestService = serviceDetailsRestService;
    this.resultCallback = resultCallback;
  }
  
}
