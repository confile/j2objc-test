package majestella.core.app.mainNavigation;

import majestella.core.prototype.mvp.BUiHandlers;

public interface MainNavigationViewUiHandlers extends BUiHandlers {

	void goToPage(int number);
	
}
