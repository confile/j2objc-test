package majestella.core.app.locationMain;

 
import javax.inject.Inject;

import majestella.core.app.locationMain.LocationMainRequestList.ResultCallback;
import majestella.core.app.locationMain.events.LocationChangedEvent;
import majestella.core.app.mainNavigation.MainNavigationPresenter;
import majestella.core.place.NameTokens;
import majestella.core.place.UrlTokens;
import majestella.core.plugins.appInfo.AppInfo;
import majestella.core.plugins.appInfo.AppInfoUserDefaultKey;
import majestella.core.plugins.weather.Weather;
import majestella.core.plugins.weather.WeatherCallback;
import majestella.core.prototype.annotation.ContentSlot;
import majestella.core.prototype.annotation.NameToken;
import majestella.core.prototype.eventBus.AbstractBEvent.Type;
import majestella.core.prototype.eventBus.BEventBus;
import majestella.core.prototype.mvp.BAbstractPresenter;
import majestella.core.prototype.mvp.BBaseView;
import majestella.core.prototype.mvp.BHasUiHandlers;
import majestella.core.prototype.mvp.proxy.BRevealContentHandler;
import majestella.core.prototype.mvp.proxy.ProxyPlace;
import majestella.core.prototype.navigation.BPlaceManager;
import majestella.core.prototype.navigation.BPlaceRequest;
import majestella.core.rest.LocationRestService;
import majestella.core.rest.dto.GetResult;
import majestella.core.rest.dto.LocationDto;

import com.google.auto.factory.AutoFactory;
import com.google.auto.factory.Provided;

import dagger.Lazy;
 
@AutoFactory(className="LocationMainPresenterFactory")
public class LocationMainPresenter extends BAbstractPresenter<LocationMainPresenter.MyView, LocationMainPresenter.MyProxy> 
	implements LocationMainViewUiHandlers {

  public interface MyView extends BBaseView, BHasUiHandlers<LocationMainViewUiHandlers> {
    
    /**
     * Set the hotel data.
     * @param locationDto
     */
    void setLocationDto(LocationDto locationDto);
    
    void setCurrentTemperature(String text);
  }
  
  @NameToken(NameTokens.locationMain)
  public interface MyProxy extends ProxyPlace<LocationMainPresenter> {
  }
  
  @ContentSlot
  public static final Type<BRevealContentHandler<?>> SLOT_MAIN = new Type<BRevealContentHandler<?>>();
  
  private int locationType = -1;
  private String locationId = "";
  private LocationDto locationDto;
  private boolean isViewInitialized = false;
  
  private final BPlaceManager placeManager; 
  private final Lazy<LocationRestService> lazyHotelRestService;
  private final Lazy<Weather> lazyWeather;
  private final Lazy<AppInfo> lazyAppinfo;
  
  
  @Inject
  public LocationMainPresenter(@Provided BEventBus eventBus, BBaseView view, @Provided MyProxy proxy,
      @Provided BPlaceManager placeManager,  
      @Provided Lazy<LocationRestService> lazyHotelRestService, 
      @Provided Lazy<Weather> lazyWeather, @Provided Lazy<AppInfo> lazyAppinfo) {
    super(eventBus, (MyView)view, proxy, MainNavigationPresenter.SLOT_MAIN); 
    
    this.placeManager = placeManager; 
    this.lazyHotelRestService = lazyHotelRestService;
    this.lazyWeather = lazyWeather;
    this.lazyAppinfo = lazyAppinfo;
    
    getView().setUiHandlers(this);     
  }
  
   
  @Override
  protected void onBind() {
    super.onBind();
    logger.info("LocationMainPresenter - onBind()"); 
  }
  
  
  @Override
  public void prepareFromRequest(BPlaceRequest request) {
    super.prepareFromRequest(request);
    
    clearSlot(SLOT_MAIN);
  
    logger.info("LocationMainPresenter - prepareFromRequest()"); 
    int newLocationType = Integer.parseInt(request.getParameter(UrlTokens.LOCATION_TYPE, "-1"));
    String newLocationId = request.getParameter(UrlTokens.LOCATION_ID, "");
    
    if ( (!newLocationId.equals(locationId)) && (!newLocationId.equals("")) ) {
      logger.info("LocationMainPresenter - prepareFromRequest() new location"); 
      locationType = newLocationType;
      locationId = newLocationId;
      callServerLocationInfoActivity();
      
      // save current location to UserDefaults
      lazyAppinfo.get().setUserDefaultString(AppInfoUserDefaultKey.lastLocationId, newLocationId);
      lazyAppinfo.get().setUserDefaultDouble(AppInfoUserDefaultKey.lastLocationType, newLocationType);
    }
  }
  
    
  @Override
  protected void onReveal() {
    super.onReveal();
    logger.info("LocationMainPresenter - onReveal()");
  }
  
  @Override
  protected void onHide() {
    super.onHide();
    logger.info("LocationMainPresenter - onHide()"); 
  }
  
  
  private void callServerLocationInfoActivity() {
    
    LocationMainRequestList requestList = new LocationMainRequestList(locationId, locationType, 
        lazyHotelRestService.get(), 
        new ResultCallback() {
          
          @Override
          public void onResult(GetResult<LocationDto> result) {
            if (result != null) {
              locationDto = result.getResult();
              LocationChangedEvent.fire(LocationMainPresenter.this, locationDto);
              if (isViewInitialized) {
                getView().setLocationDto(locationDto);
              }
            }
          }
        });
    
    // call server on a background thread
    new LocationMainLoaderTask().execute(requestList);
    
    
    // TODO: delete OLD
//    logger.info("<<< LocationMainPresenter - callServerLocationInfoActivity(): locationId: "+this.locationId);
//  
//    lazyHotelRestService.get().get(locationId, locationType, new BAsyncCallback<GetResult<LocationDto>>() {
//      
//      @Override
//      public void onFailure(Exception e) {
//        logger.log(Level.SEVERE, 
//            "LocationMainPresenter - callServerLocationInfoActivity(): Cannot contact server.",
//            e);
//      }
//      
//      @Override
//      public void onSuccess(GetResult<LocationDto> result) {
//        logger.info(">>> LocationMainPresenter - callServerLocationInfoActivity()");
//        
//        locationDto = result.getResult();
//        LocationChangedEvent.fire(LocationMainPresenter.this, locationDto);
//        if (isViewInitialized) {
//          getView().setLocationDto(locationDto);
//        }
//      }
//      
//    });    
  }
  

  // ---------------------------------------------
  // UiHandlers
  // ---------------------------------------------

  @Override
  public void requestSetTemperature() { 
     
    if ( (locationDto.getLatitude() > 0) && (locationDto.getLongitude() > 0) ) {
      logger.info("LocationMainPresenter - requestSetTemperature()");
      lazyWeather.get().getTemperature(locationDto.getLatitude(), locationDto.getLongitude(), new WeatherCallback() {
        
        @Override
        public void onSucces(String temperature) {
          getView().setCurrentTemperature(temperature);
        }
        
        @Override
        public void onFailure() {
          logger.severe("LocationMainPresenter - getTemperature(): onFailure()");
        }
      });
    }
  }


  @Override
  public void viewDidLoad() {
    logger.info("LocationMainPresenter - viewDidLoad()");
    isViewInitialized = true;
    if (locationDto != null) {
      getView().setLocationDto(locationDto);
    }
  }
  
  
  @Override
  public void serviceSelectionTapped() {
    logger.info("LocationMainPresenter - serviceSelectionTapped() -------------------------------------------------");
    BPlaceRequest request = new BPlaceRequest.Builder()
      .nameToken(NameTokens.getServiceSelection()) 
      .build();
    placeManager.revealPlace(request); 
  }
  
  @Override
  public void hotelInfoTapped() {
    BPlaceRequest request = new BPlaceRequest.Builder()
      .nameToken(NameTokens.getLocationInfo()) 
      .build();
    placeManager.revealPlace(request); 
  }
  
  @Override
  public void roomServiceTapped() {
    BPlaceRequest request = new BPlaceRequest.Builder()
      .nameToken(NameTokens.getRoomService()) 
      .with(UrlTokens.LOCATION_ID, locationId)
      .build();
    placeManager.revealPlace(request); 
  }
  
  
  @Override
  public void restaurantTapped() {
    BPlaceRequest request = new BPlaceRequest.Builder()
      .nameToken(NameTokens.getHotelRestaurant()) 
      .with(UrlTokens.LOCATION_ID, locationId)
      .build();
    placeManager.revealPlace(request); 
  }
  
  @Override
  public void hotelSpaTapped() {
    BPlaceRequest request = new BPlaceRequest.Builder()
      .nameToken(NameTokens.getHotelSpa()) 
      .with(UrlTokens.LOCATION_ID, locationId)
      .build();
    placeManager.revealPlace(request); 
  }
  
  @Override
  public void settingTapped() {
    BPlaceRequest request = new BPlaceRequest.Builder()
      .nameToken(NameTokens.getSetting())  
      .with(UrlTokens.LOCATION_NAME, locationDto.getName())
      .build();
    placeManager.revealPlace(request); 
  }
  
  
  // ---------------------------------------------
  // Events
  // ---------------------------------------------

  
 
  
}
