package majestella.core.app.hotelSpa;

 
import javax.inject.Inject;

import majestella.core.app.hotelSpa.HotelSpaRequestList.ResultCallback;
import majestella.core.app.locationMain.LocationMainPresenter;
import majestella.core.place.NameTokens;
import majestella.core.place.UrlTokens;
import majestella.core.prototype.annotation.NameToken;
import majestella.core.prototype.eventBus.BEventBus;
import majestella.core.prototype.mvp.BAbstractPresenter;
import majestella.core.prototype.mvp.BBaseView;
import majestella.core.prototype.mvp.BHasUiHandlers;
import majestella.core.prototype.mvp.proxy.ProxyPlace;
import majestella.core.prototype.navigation.BPlaceManager;
import majestella.core.prototype.navigation.BPlaceRequest;
import majestella.core.rest.HotelSpaRestService;
import majestella.core.rest.dto.GetResult;
import majestella.core.rest.dto.HotelSpaDto;

import com.google.auto.factory.AutoFactory;
import com.google.auto.factory.Provided;

import dagger.Lazy;
 
@AutoFactory(className="HotelSpaPresenterFactory")
public class HotelSpaPresenter extends BAbstractPresenter<HotelSpaPresenter.MyView, HotelSpaPresenter.MyProxy> 
	implements HotelSpaViewUiHandlers {

  public interface MyView extends BBaseView, BHasUiHandlers<HotelSpaViewUiHandlers> {
    
    void setData(HotelSpaDto hotelSpaDto);
    
  }
  
  @NameToken(NameTokens.hotelSpa)
  public interface MyProxy extends ProxyPlace<HotelSpaPresenter> {
  }
  

  private String hotelId = "";
  private HotelSpaDto hotelSpaDto = null;
  private boolean isViewInitialized = false;
  
  private final BPlaceManager placeManager; 
  private final Lazy<HotelSpaRestService> lazyHotelSpaRestService;
  
  @Inject
  public HotelSpaPresenter(@Provided BEventBus eventBus, BBaseView view, @Provided MyProxy proxy,
      @Provided BPlaceManager placeManager,  
      @Provided Lazy<HotelSpaRestService> lazyHotelSpaRestService) {
    super(eventBus, (MyView)view, proxy, LocationMainPresenter.SLOT_MAIN); 
    
    this.placeManager = placeManager; 
    this.lazyHotelSpaRestService = lazyHotelSpaRestService;
    
    getView().setUiHandlers(this);     
  }
  
   
  @Override
  protected void onBind() {
    super.onBind();
    logger.info("HotelSpaPresenter - onBind()"); 
  }
  
  
  @Override
  public void prepareFromRequest(BPlaceRequest request) {
    super.prepareFromRequest(request);
    
   
    logger.info("HotelSpaPresenter - prepareFromRequest()"); 
    String newHotelId = request.getParameter(UrlTokens.LOCATION_ID, "");
    
    if ( (!newHotelId.equals(hotelId)) && (!newHotelId.equals("")) ) {
      logger.info("HotelSpaPresenter - prepareFromRequest() new hotel"); 
      hotelId = newHotelId;
      hotelSpaDto = null; 
      callServerHotelSpaActivity();
    }
  }
    
  @Override
  protected void onReveal() {
    super.onReveal();
    logger.info("HotelSpaPresenter - onReveal()");
  }
  
  @Override
  protected void onHide() {
    super.onHide();
    logger.info("HotelSpaPresenter - onHide()");
    
  }
  
  private void callServerHotelSpaActivity() {
    
    HotelSpaRequestList requestList = new HotelSpaRequestList(hotelId, lazyHotelSpaRestService.get(), 
        new ResultCallback() {
          
          @Override
          public void onResult(GetResult<HotelSpaDto> result) {
            if (result != null) {
              hotelSpaDto = result.getResult();
              if (isViewInitialized) {
                getView().setData(hotelSpaDto);
              }
            }
          }
        });
    
    // call server on a background thread
    new HotelSpaLoaderTask().execute(requestList);
    
    // TODO: delete OLD
    
//    logger.info("<<< HotelSpaPresenter - callServerHotelSpaActivity(): hotelId: "+this.hotelId);
//   
//    lazyHotelSpaRestService.get().get(hotelId, new BAsyncCallback<GetResult<HotelSpaDto>>() {
//      
//      @Override
//      public void onFailure(Exception e) {
//        logger.log(Level.SEVERE, 
//            "HotelSpaPresenter - callServerHotelSpaActivity(): Cannot contact server.",
//            e);
//      }
//      
//      @Override
//      public void onSuccess(GetResult<HotelSpaDto> result) {
//        logger.info(">>> HotelSpaPresenter - callServerHotelSpaActivity()");
//        
//        hotelSpaDto = result.getResult();
//        if (isViewInitialized) {
//          getView().setData(hotelSpaDto);
//        }
//      }
//    });
  }
   

  // ---------------------------------------------
  // UiHandlers
  // ---------------------------------------------

  
  @Override
  public void viewDidLoad() {
    logger.info("HotelSpaPresenter - viewDidLoad()");
    isViewInitialized = true;
    if (hotelSpaDto != null) {
      getView().setData(hotelSpaDto);
    }
  }
   
  
  @Override
  public void backTapped() {
    logger.info("HotelSpaPresenter - backTapped()");
    placeManager.navigateBack();
  }
  
  
  // ---------------------------------------------
  // Events
  // ---------------------------------------------

  
 
  
}
