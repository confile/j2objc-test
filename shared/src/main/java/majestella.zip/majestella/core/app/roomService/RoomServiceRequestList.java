package majestella.core.app.roomService;

import majestella.core.rest.RoomServiceRestService;
import majestella.core.rest.dto.GetResult;
import majestella.core.rest.dto.RoomServiceDomainDto;

public class RoomServiceRequestList {

  public interface ResultCallback {
    void onResult(GetResult<RoomServiceDomainDto> result);
  }
  
  public String hotelId;
  public RoomServiceRestService roomServiceRestService;
  public ResultCallback resultCallback;
  
  public RoomServiceRequestList(String hotelId, RoomServiceRestService roomServiceRestService, 
      ResultCallback resultCallback) {
    this.hotelId = hotelId;
    this.roomServiceRestService = roomServiceRestService;
    this.resultCallback = resultCallback;
  }
  
}
