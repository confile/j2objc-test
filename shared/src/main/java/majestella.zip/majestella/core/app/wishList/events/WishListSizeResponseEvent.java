package majestella.core.app.wishList.events;

 
import majestella.core.prototype.eventBus.AbstractBEvent;
import majestella.core.prototype.eventBus.BEventHandler;
import majestella.core.prototype.eventBus.BHasHandlers;


/**
 * This event is fired when the WishList size is returned.
 * @author Dr. Michael Gorski
 *
 */
public class WishListSizeResponseEvent extends AbstractBEvent<WishListSizeResponseEvent.WishListSizeResponseHandler> {

  
  public static Type<WishListSizeResponseHandler> TYPE = new Type<WishListSizeResponseHandler>();
  
  public interface WishListSizeResponseHandler extends BEventHandler {
    void onWishListSizeResponse(WishListSizeResponseEvent event);
  }
  
  private int size;
  
  public WishListSizeResponseEvent(int size) {
    this.size = size;
  }

  public int getSize() {
    return size;
  }
  
  @Override
  public AbstractBEvent.Type<WishListSizeResponseHandler> getAssociatedType() {
    return TYPE;
  }
  
  public static Type<WishListSizeResponseHandler> getType() {
    return TYPE;
  }

  @Override
  protected void dispatch(WishListSizeResponseHandler handler) {
    handler.onWishListSizeResponse(this);
  }
  
  public static void fire(BHasHandlers source, int size) {
    source.fireEvent(new WishListSizeResponseEvent(size));
  }
  
 
  
}
