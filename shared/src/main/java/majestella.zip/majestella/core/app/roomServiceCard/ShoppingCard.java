package majestella.core.app.roomServiceCard;

import java.util.LinkedHashMap;
import java.util.Map;

import majestella.core.rest.dto.RoomServiceItemDto;

public class ShoppingCard {

  private static ShoppingCard instance;
    
  private Map<RoomServiceItemDto, Integer> itemsMap = new LinkedHashMap<>(); 
  
  
  
  private ShoppingCard() {
  }
  
  public static ShoppingCard getSharedInstance() {
    if (instance == null) {
      instance = new ShoppingCard();
    }
    return instance;
  }
  
  public synchronized Map<RoomServiceItemDto, Integer> getItemMap() {
    return itemsMap;
  }
  
  public synchronized void clearCard() {
    itemsMap.clear();
  }
  
  public synchronized double getTotalPriceOfAllItems() {
    double totalPrice = 0;
    for (Map.Entry<RoomServiceItemDto, Integer> entry : itemsMap.entrySet()) {
      totalPrice += entry.getKey().getPrice() * entry.getValue();
    }    
    return totalPrice;
  }
  
  
  public synchronized double getTotalPriceByType(RoomServiceItemDto roomServiceItemDto) {
    double totalPrice = 0;
    for (Map.Entry<RoomServiceItemDto, Integer> entry : itemsMap.entrySet()) {
      if (entry.getKey().equals(roomServiceItemDto)) {
        totalPrice = entry.getKey().getPrice() * entry.getValue();
        break;
      }
    }    
    return totalPrice;
  }
  
  
  public synchronized void addItemToCard(RoomServiceItemDto roomServiceItemDto) {
    for (Map.Entry<RoomServiceItemDto, Integer> entry : itemsMap.entrySet()) {
      if (entry.getKey().equals(roomServiceItemDto)) {
        int oldValue = entry.getValue();
        entry.setValue(oldValue + 1);
        return;
      }      
    }
    
    // new item on card    
    itemsMap.put(roomServiceItemDto, 1);
  }
 
  
  public synchronized void removeAllItemsOfTypeAtIndexFromCard(int index) {
    int i = 0;
    RoomServiceItemDto itemToRemove = null;
    for(RoomServiceItemDto itemDto : itemsMap.keySet()) {
      if (i == index) {
        itemToRemove = itemDto;
        break;
      }
      i++;
    } 
    
    if (itemToRemove != null) {
      itemsMap.remove(itemToRemove);
    }
  }
  

  /**
   * Remove one item from the shopping card.
   * @param index
   */
  public synchronized void removeItemFromCard(int index) {
    int i = 0;
    for(Map.Entry<RoomServiceItemDto, Integer> entry : itemsMap.entrySet()) {
      if (i == index) {
        int oldValue = entry.getValue();
        int newValue = oldValue - 1;
        entry.setValue(newValue);
        if (newValue == 0) {
          removeAllItemsOfTypeAtIndexFromCard(i);
        }        
        return;
      }
      i++;
    } 
  }
  
  
 
  public synchronized boolean isItemOnCard(RoomServiceItemDto roomServiceItemDto) {
    for(RoomServiceItemDto itemDto : itemsMap.keySet()) {
      if (itemDto.equals(roomServiceItemDto)) {
        return true;
      }      
    }    
    return false;
  }
  
  
  public synchronized int getTotalItemsCount() {
    int count = 0;
    for (Map.Entry<RoomServiceItemDto, Integer> entry : itemsMap.entrySet()) {
      count += entry.getValue();
    }    
    return count;
  }
  
  
  public synchronized int getTotalItemsCountByType(RoomServiceItemDto roomServiceItemDto) {
    int count = 0;
    for (Map.Entry<RoomServiceItemDto, Integer> entry : itemsMap.entrySet()) {
      if (entry.getKey().equals(roomServiceItemDto)) {
        count = entry.getValue();
        break;
      }
    }    
    return count;
  }
  
  
  public synchronized RoomServiceItemDto getItem(int index) {
    int i = 0;
    for(RoomServiceItemDto itemDto : itemsMap.keySet()) {
      if (i == index) {
        return itemDto; 
      }
      i++;
    }    
    return null;
  }
  
  
  /**
   * Returns the number of different RoomServiceItemDto types
   * on the shopping card.
   * @return
   */
  public synchronized int getNumberOfItemTypesOnCard() {
    return itemsMap.keySet().size();
  }
  
  
  
  
  
}
