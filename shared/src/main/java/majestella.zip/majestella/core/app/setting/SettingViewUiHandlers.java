package majestella.core.app.setting;

import majestella.core.prototype.mvp.BUiHandlers;

public interface SettingViewUiHandlers extends BUiHandlers {
  
  
  /**
   * View has been initialized.
   */
  void viewDidLoad();
  
  void backTapped();
 
  String getVersionString();
  
  String getCurrentLocationName();
  
  void locationTapped();
  
  void recommendAppTapped();
  
  void reportProblemTapped();
  
  void rateAppTapped();
  
  void likeOnFacebookTapped();
  
}
