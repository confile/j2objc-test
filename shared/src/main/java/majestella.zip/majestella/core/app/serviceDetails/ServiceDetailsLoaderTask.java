package majestella.core.app.serviceDetails;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import majestella.core.bootstrap.ParameterConfig;
import majestella.core.prototype.mvp.proxy.BAsyncCallback;
import majestella.core.rest.dto.BooleanDto;
import majestella.core.rest.dto.GetResult;
import android.os.AsyncTask;

/**
 * This class is used to comunicate with the server on a 
 * background thread.
 * @author Dr. Michael Gorski
 *
 */
public class ServiceDetailsLoaderTask extends AsyncTask<ServiceDetailsRequestList, Void, GetResult<BooleanDto>> {

  private final CountDownLatch latch = new CountDownLatch(1);
  private GetResult<BooleanDto> callbackResult = null;
  private ServiceDetailsRequestList requestList = null;
  
  @Override
  protected GetResult<BooleanDto> doInBackground(ServiceDetailsRequestList... params) {
    requestList = params[0];
    
    final Logger logger = Logger.getLogger(ParameterConfig.LOGGER_MAJESTELLA_NAME);
    logger.info("<<< ServiceDetailsLoaderTask - callServerServiceDetailsAction()");
    
    try {    
            
      requestList.serviceDetailsRestService.post(requestList.serviceCardId, 
          new BAsyncCallback<GetResult<BooleanDto>>() {
        
        @Override
        public void onFailure(Exception e) {
          logger.log(Level.SEVERE, 
              "ServiceDetailsLoaderTask - callServerServiceDetailsAction(): Cannot contact server.",
              e);
          callbackResult = null;
          latch.countDown();
        }
        
        @Override
        public void onSuccess(GetResult<BooleanDto> result) {
          logger.info(">>> ServiceDetailsLoaderTask - callServerServiceDetailsAction(): result: "+result);
          
          callbackResult = result;
          latch.countDown();
        }
      });
    
      if (latch.await(ParameterConfig.SERVER_REQUEST_TIMEOUT, TimeUnit.SECONDS)) {
        return callbackResult;
      }
      else {
        return null; // timeout
      }
    }
    catch(InterruptedException ex) {
      logger.severe("ServiceDetailsLoaderTask request interrupted error: "+ex);
      return null;
    } 
  }
  
  
  @Override
  protected void onPostExecute(GetResult<BooleanDto> result) {
    if (requestList.resultCallback != null) {
      requestList.resultCallback.onResult(result);
    } 
  }

}
