package majestella.core.app.serviceDetails;

import majestella.core.prototype.mvp.BUiHandlers;
import majestella.core.rest.dto.ServiceCardDto;

public interface ServiceDetailsViewUiHandlers extends BUiHandlers {

 
  ServiceCardDto getData();
  
  /**
   * The user tapped the back button.
   */
  void backTapped();
  
  /**
   * The user tapped the booking button.
   */
  void bookingTapped();
  
}
