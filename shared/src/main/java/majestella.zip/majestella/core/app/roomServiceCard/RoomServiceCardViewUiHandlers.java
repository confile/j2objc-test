package majestella.core.app.roomServiceCard;

import majestella.core.prototype.mvp.BUiHandlers;
import majestella.core.rest.dto.RoomServiceItemDto;

public interface RoomServiceCardViewUiHandlers extends BUiHandlers {

  void backTapped();
  
  /**
   * Return the total number of all 
   * item on the shopping card.
   * @return
   */
  int getTotelItemsOnCard();
  
  double getTotalPriceOfAllItems();
  
 
  RoomServiceItemDto getItem(int index);
  
  int getTotalItemsCountByType(RoomServiceItemDto roomServiceItemDto);
  
  /**
   * Returns the number of different RoomServiceItemDto types
   * on the shopping card.
   * @return
   */
  int getNumberOfItemTypesOnCard();
  
  
  void removeAllItemsOfTypeAtIndexFromCard(int index);
  
  void addItemToCard(RoomServiceItemDto roomServiceItemDto);
  
  /**
   * Remove one item from the shopping card.
   * @param index
   */
  void removeItemFromCard(int index);
  
  double getTotalPriceByType(RoomServiceItemDto roomServiceItemDto);
 
  /**
   * Check order for completeness and user information.
   */
  void checkOrder();
  
  void submitOrder(String lastName, int roomNumber, long departureDateNumber);
  
}
