package majestella.core.app.setting;

 
import javax.inject.Inject;

import majestella.core.app.locationMain.LocationMainPresenter;
import majestella.core.bootstrap.ParameterConfig;
import majestella.core.i18n.BMessage;
import majestella.core.i18n.MessageKey;
import majestella.core.place.NameTokens;
import majestella.core.place.UrlTokens;
import majestella.core.plugins.email.EmailComposer;
import majestella.core.plugins.email.EmailComposerOptions;
import majestella.core.plugins.inappbrowser.Inappbrowser;
import majestella.core.plugins.systemConfig.SystemConfig;
import majestella.core.prototype.annotation.NameToken;
import majestella.core.prototype.eventBus.BEventBus;
import majestella.core.prototype.mvp.BAbstractPresenter;
import majestella.core.prototype.mvp.BBaseView;
import majestella.core.prototype.mvp.BHasUiHandlers;
import majestella.core.prototype.mvp.proxy.ProxyPlace;
import majestella.core.prototype.navigation.BPlaceManager;
import majestella.core.prototype.navigation.BPlaceRequest;
import majestella.core.rest.dto.DeviceDto;

import com.google.auto.factory.AutoFactory;
import com.google.auto.factory.Provided;

import dagger.Lazy;
 
@AutoFactory(className="SettingPresenterFactory")
public class SettingPresenter extends BAbstractPresenter<SettingPresenter.MyView, SettingPresenter.MyProxy> 
	implements SettingViewUiHandlers {

  public interface MyView extends BBaseView, BHasUiHandlers<SettingViewUiHandlers> {
        
  }
  
  @NameToken(NameTokens.setting)
  public interface MyProxy extends ProxyPlace<SettingPresenter> {
  }
  

  private String locationName = "";
  private boolean isViewInitialized = false;
  
  private final BPlaceManager placeManager; 
  private final Lazy<Inappbrowser> lazyInappbrowser;
  private final Lazy<SystemConfig> lazySystemConfig;
  private final DeviceDto deviceDto;
  private final Lazy<EmailComposer> lazyEmailComposer;
  private final BMessage message;
  
  
  @Inject
  public SettingPresenter(@Provided BEventBus eventBus, BBaseView view, @Provided MyProxy proxy,
      @Provided BPlaceManager placeManager, @Provided Lazy<Inappbrowser> lazyInappbrowser, 
      @Provided DeviceDto deviceDto, @Provided Lazy<SystemConfig> lazySystemConfig, 
      @Provided Lazy<EmailComposer> lazyEmailComposer, @Provided BMessage message) {
    super(eventBus, (MyView)view, proxy, LocationMainPresenter.SLOT_MAIN); 
    
    this.placeManager = placeManager; 
    this.lazyInappbrowser = lazyInappbrowser;
    this.deviceDto = deviceDto;
    this.lazySystemConfig = lazySystemConfig;
    this.lazyEmailComposer = lazyEmailComposer;
    this.message = message;
    
    getView().setUiHandlers(this);     
  }
  
   
  @Override
  protected void onBind() {
    super.onBind();
    logger.info("SettingPresenter - onBind()"); 
  }
  
  @Override
  public void prepareFromRequest(BPlaceRequest request) {
    super.prepareFromRequest(request);
    
    String newLocationName = request.getParameter(UrlTokens.LOCATION_NAME, "");
    if (!newLocationName.equals(locationName)) {
      locationName = newLocationName;
    }
  }
  
    
  @Override
  protected void onReveal() {
    super.onReveal();
    logger.info("SettingPresenter - onReveal()");
  }
  
  @Override
  protected void onHide() {
    super.onHide();
    logger.info("SettingPresenter - onHide()");    
  }
  
   

  // ---------------------------------------------
  // UiHandlers
  // ---------------------------------------------

  
  @Override
  public void viewDidLoad() {
    logger.info("SettingPresenter - viewDidLoad()");
    isViewInitialized = true;
  }
   
  
  @Override
  public void backTapped() {
    logger.info("SettingPresenter - backTapped()");
    placeManager.navigateBack();
  }
  
  @Override
  public String getVersionString() { 
    return deviceDto.getAppVersion();
  }
  
  @Override
  public String getCurrentLocationName() {
    return locationName;
  }
  
  @Override
  public void locationTapped() {
    logger.info("SettingPresenter - locationTapped()");

    BPlaceRequest request = new BPlaceRequest.Builder()
      .nameToken(NameTokens.getLocationSetting()) 
      .with(UrlTokens.PRESENT_MODAL, "false")
      .build();
    placeManager.revealPlace(request); 

  }
  
  @Override
  public void recommendAppTapped() {
    // TODO implementieren
    
  }
  
  @Override
  public void reportProblemTapped() {
    EmailComposerOptions data = new EmailComposerOptions();
    data.setTo(ParameterConfig.PROBLEM_REPORT_EMAIL);
    data.setSubject(message.lookup(MessageKey.reportABug));
    lazyEmailComposer.get().open(data);
  }
  
  @Override
  public void rateAppTapped() {
    if (lazySystemConfig.get().isIOs()) {
      lazyInappbrowser.get().openWindow(ParameterConfig.APP_STORE_LINK);
    }
    else {
      // Android
      lazyInappbrowser.get().openWindow(ParameterConfig.GOOGLE_PLAY_STORE_LINK);
    }
  }
  
  @Override
  public void likeOnFacebookTapped() {
    lazyInappbrowser.get().openWindow(ParameterConfig.FACEBOOK_FANEPAGE_LINK);
  }
  
  
  
  // ---------------------------------------------
  // Events
  // ---------------------------------------------

  
 
 
  
}
