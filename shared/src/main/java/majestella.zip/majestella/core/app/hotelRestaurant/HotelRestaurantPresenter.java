package majestella.core.app.hotelRestaurant;

 
import java.util.List;

import javax.inject.Inject;

import majestella.core.app.hotelRestaurant.HotelRestaurantRequestList.ResultCallback;
import majestella.core.app.locationMain.LocationMainPresenter;
import majestella.core.place.NameTokens;
import majestella.core.place.UrlTokens;
import majestella.core.plugins.weather.Weather;
import majestella.core.prototype.annotation.NameToken;
import majestella.core.prototype.eventBus.BEventBus;
import majestella.core.prototype.mvp.BAbstractPresenter;
import majestella.core.prototype.mvp.BBaseView;
import majestella.core.prototype.mvp.BHasUiHandlers;
import majestella.core.prototype.mvp.proxy.ProxyPlace;
import majestella.core.prototype.navigation.BPlaceManager;
import majestella.core.prototype.navigation.BPlaceRequest;
import majestella.core.rest.HotelRestaurantRestService;
import majestella.core.rest.dto.GetResults;
import majestella.core.rest.dto.HotelRestaurantDto;

import com.google.auto.factory.AutoFactory;
import com.google.auto.factory.Provided;

import dagger.Lazy;
 
@AutoFactory(className="HotelRestaurantPresenterFactory")
public class HotelRestaurantPresenter extends BAbstractPresenter<HotelRestaurantPresenter.MyView, HotelRestaurantPresenter.MyProxy> 
	implements HotelRestaurantViewUiHandlers {

  public interface MyView extends BBaseView, BHasUiHandlers<HotelRestaurantViewUiHandlers> {
    
    void setData(List<HotelRestaurantDto> hotelRestaurantDtos);
    
  }
  
  
  @NameToken(NameTokens.hotelRestaurant)
  public interface MyProxy extends ProxyPlace<HotelRestaurantPresenter> {
  }
  
  private String hotelId = "";
  private List<HotelRestaurantDto> hotelRestaurantDtos = null;
  private boolean isViewInitialized = false;
  
  
  private final BPlaceManager placeManager; 
  private final Lazy<HotelRestaurantRestService> lazyHotelRestaurantRestService;
  private final Lazy<Weather> lazyWeather;
  
  @Inject
  public HotelRestaurantPresenter(@Provided BEventBus eventBus, BBaseView view, @Provided MyProxy proxy,
      @Provided BPlaceManager placeManager, 
      @Provided Lazy<HotelRestaurantRestService> lazyHotelRestaurantRestService, 
      @Provided Lazy<Weather> lazyWeather) {
    super(eventBus, (MyView)view, proxy, LocationMainPresenter.SLOT_MAIN); 
    
    this.placeManager = placeManager; 
    this.lazyHotelRestaurantRestService = lazyHotelRestaurantRestService;
    this.lazyWeather = lazyWeather;
    
    getView().setUiHandlers(this);     
  }
  
   
  @Override
  protected void onBind() {
    super.onBind();
    logger.info("HotelRestaurantPresenter - onBind()"); 
  }
  
  
  @Override
  public void prepareFromRequest(BPlaceRequest request) {
    super.prepareFromRequest(request);
     
    logger.info("HotelRestaurantPresenter - prepareFromRequest()"); 
    String newHotelId = request.getParameter(UrlTokens.LOCATION_ID, "");
    
    if ( (!newHotelId.equals(hotelId)) && (!newHotelId.equals("")) ) {
      logger.info("HotelRestaurantPresenter - prepareFromRequest() new hotel"); 
      hotelId = newHotelId;
      hotelRestaurantDtos = null;
      callServerHotelRestaurantActivity();
    }
  }
  
    
  @Override
  protected void onReveal() {
    super.onReveal();
    logger.info("HotelRestaurantPresenter - onReveal()");
  }
  
  @Override
  protected void onHide() {
    super.onHide();
    logger.info("HotelRestaurantPresenter - onHide()");
     
  }
  
  
  private void callServerHotelRestaurantActivity() {
    
    HotelRestaurantRequestList requestList = new HotelRestaurantRequestList(hotelId, lazyHotelRestaurantRestService.get(), 
        new ResultCallback() {
          
          @Override
          public void onResult(GetResults<HotelRestaurantDto> result) {
            if (result != null) {
              hotelRestaurantDtos = result.getResults();
              if (isViewInitialized) {
                getView().setData(hotelRestaurantDtos);
              }   
            }
          }
        });
    
    // call server on a background thread
    new HotelRestaurantLoaderTask().execute(requestList);
    
    
    //TODO: delete OLD
//    logger.info("<<< HotelRestaurantPresenter - callServerHotelRestaurantActivity(): hotelId: "+this.hotelId);
       
//    lazyHotelRestaurantRestService.get().get(hotelId, new BAsyncCallback<GetResults<HotelRestaurantDto>>() {
//      
//      @Override
//      public void onFailure(Exception e) {
//        logger.log(Level.SEVERE, 
//          "HotelRestaurantPresenter - callServerHotelRestaurantActivity(): Cannot contact server.",
//          e);
//      }
//      
//      @Override
//      public void onSuccess(GetResults<HotelRestaurantDto> result) {
//        logger.info(">>> HotelMainPresenter - callServerHotelRestaurantActivity(): count: "+result.getResults().size());
//        hotelRestaurantDtos = result.getResults();
//        if (isViewInitialized) {
//          getView().setData(hotelRestaurantDtos);
//        }        
//      }
//    });
    
  }
  

  // ---------------------------------------------
  // UiHandlers
  // ---------------------------------------------

 

  @Override
  public void viewDidLoad() {
    logger.info("HotelRestaurantPresenter - viewDidLoad()");
    isViewInitialized = true;
    if (hotelRestaurantDtos != null) {
      getView().setData(hotelRestaurantDtos);
    }
  }
  
  
  @Override
  public void backTapped() {
    placeManager.navigateBack();
  }
  
  
  // ---------------------------------------------
  // Events
  // ---------------------------------------------

  
 
  
}
