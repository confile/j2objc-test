package majestella.core.app.wishList;

 
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import majestella.core.app.mainNavigation.MainNavigationPresenter;
import majestella.core.app.serviceSelection.events.ServiceDetailsUpdateEvent;
import majestella.core.app.wishList.events.WishListAppendEvent;
import majestella.core.app.wishList.events.WishListItemRemoveEvent;
import majestella.core.app.wishList.events.WishListAppendEvent.WishListAppendHandler;
import majestella.core.place.NameTokens;
import majestella.core.place.UrlTokens;
import majestella.core.plugins.database.ListCallback;
import majestella.core.plugins.database.VoidCallback;
import majestella.core.plugins.database.serviceCard.ServiceCardDataService;
import majestella.core.prototype.annotation.ContentSlot;
import majestella.core.prototype.annotation.NameToken;
import majestella.core.prototype.annotation.ProxyEvent;
import majestella.core.prototype.eventBus.AbstractBEvent.Type;
import majestella.core.prototype.eventBus.BEventBus;
import majestella.core.prototype.mvp.BAbstractPresenter;
import majestella.core.prototype.mvp.BBaseView;
import majestella.core.prototype.mvp.BHasUiHandlers;
import majestella.core.prototype.mvp.proxy.BRevealContentHandler;
import majestella.core.prototype.mvp.proxy.ProxyPlace;
import majestella.core.prototype.navigation.BPlaceManager;
import majestella.core.prototype.navigation.BPlaceRequest;
import majestella.core.rest.dto.ServiceCardDto;

import com.google.auto.factory.AutoFactory;
import com.google.auto.factory.Provided;

import dagger.Lazy;
 
@AutoFactory(className="WishListPresenterPresenterFactory")
public class WishListPresenter extends BAbstractPresenter<WishListPresenter.MyView, WishListPresenter.MyProxy> 
	implements WishListViewUiHandlers, WishListAppendHandler {

  public interface MyView extends BBaseView, BHasUiHandlers<WishListViewUiHandlers> {
  }
  
  @NameToken(NameTokens.wishList)
  public interface MyProxy extends ProxyPlace<WishListPresenter> {
  }
  
  @ContentSlot
  public static final Type<BRevealContentHandler<?>> SLOT_MAIN = new Type<BRevealContentHandler<?>>();
    

  private final BPlaceManager placeManager; 
  private final Lazy<ServiceCardDataService> lazyServiceCardDataService;
  
  @Inject
  public WishListPresenter(@Provided BEventBus eventBus, BBaseView view, @Provided MyProxy proxy,
      @Provided BPlaceManager placeManager, @Provided Lazy<ServiceCardDataService> lazyServiceCardDataService) {
    super(eventBus, (MyView)view, proxy, MainNavigationPresenter.SLOT_MAIN); 
    
    this.placeManager = placeManager;  
    this.lazyServiceCardDataService = lazyServiceCardDataService;
    
    getView().setUiHandlers(this);     
  }
  
  
  @Override
  protected void onBind() {
    super.onBind();
    logger.info("WishListPresenter - onBind()"); 
    
    initWishList();
  }
  
  @Override
  public void prepareFromRequest(BPlaceRequest request) {
    super.prepareFromRequest(request);
    logger.info("WishListPresenter - prepareFromRequest()"); 
    clearSlot(SLOT_MAIN);
  }
    
  @Override
  protected void onReveal() {
    super.onReveal();
    logger.info("WishListPresenter - onReveal()");
  }
  
  @Override
  protected void onHide() {
    super.onHide();
    logger.info("WishListPresenter - onHide()");
     
  }
  
  
  private void initWishList() {
    logger.info("WishListPresenter - initWishList()");
    
    lazyServiceCardDataService.get().findAll(0, 50, new ListCallback<ServiceCardDto>() {
      
      @Override
      public void onFailure(String error) {
        logger.info("### WishListPresenter - initWishList(): findAll(): error: "+error);
      }
      
      @Override
      public void onSuccess(List<ServiceCardDto> result) {
        logger.info("||| WishListPresenter - initWishList(): findAll(): result: "+result.size());
        
        for (ServiceCardDto dto : result) {
          WishList.getSharedInstance().addItem(dto);
        }        
      }
    });
      
  }
  
  
  // ---------------------------------------------
  // UiHandlers
  // ---------------------------------------------


  @Override
  public int getWishListSize() {
    return WishList.getSharedInstance().getSize();
  }

  
  @Override
  public ServiceCardDto getWishListItem(int index) {
    return WishList.getSharedInstance().getItem(index);
  }
  
  @Override
  public void removeWishListItem(int index) {
    ServiceCardDto deletedServiceCardDto = WishList.getSharedInstance().removeItem(index);
    
    List<String> deleteIds = new ArrayList<>();
    deleteIds.add(deletedServiceCardDto.getId());
    lazyServiceCardDataService.get().deleteAllById(deleteIds, new VoidCallback() {
      
      @Override
      public void onFailure(String error) {
        logger.info("### WishListPresenter - removeWishListItem(): deleteAllById(): error: "+error);
      }
      
      @Override
      public void onSuccess() {
        logger.info("||| WishListPresenter - removeWishListItem(): deleteAllById(): success");
      }
    });
    
    WishListItemRemoveEvent.fire(this, deletedServiceCardDto);
  }
  
  @Override
  public void wishListItemTapped(int index) {
    logger.info("WishListPresenter - wishListItemTapped(): index: "+index);
    
    ServiceCardDto serviceCardDto = WishList.getSharedInstance().getItem(index);
    if (serviceCardDto != null) {
      ServiceDetailsUpdateEvent.fire(this, serviceCardDto);
      
      BPlaceRequest request = new BPlaceRequest.Builder()
        .nameToken(NameTokens.getServiceDetails())
        .with(UrlTokens.SERVICE_CARD_ID, serviceCardDto.getId())
        .with(UrlTokens.SHOW_IN_WISHLIST, "true")
        .build();
      placeManager.revealPlace(request); 
    }
  }
  
  // ---------------------------------------------
  // Events
  // ---------------------------------------------

 
 
  @ProxyEvent
  @Override
  public void onWishListAppended(WishListAppendEvent event) {
    boolean result = WishList.getSharedInstance().addItem(event.getServiceCardDto());
    logger.info("WishListPresenter - onWishListAppended(): result: "+result);
    if (result) {
      List<ServiceCardDto> serviceCardDtos = new ArrayList<>();
      serviceCardDtos.add(event.getServiceCardDto());
      lazyServiceCardDataService.get().insertOrReplace(serviceCardDtos, new VoidCallback() {
        
        @Override
        public void onFailure(String error) {
          logger.info("### WishListPresenter - onWishListAppended(): insertOrReplace(): error: "+error);
        }
        
        @Override
        public void onSuccess() {
          logger.info("||| WishListPresenter - onWishListAppended(): insertOrReplace(): onSuccess");          
        }
      });
      
    }    
  }
  
  
}
