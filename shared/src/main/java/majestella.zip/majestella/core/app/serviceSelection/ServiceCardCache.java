package majestella.core.app.serviceSelection;

import java.util.LinkedList;
import java.util.Queue;

import majestella.core.rest.dto.ServiceCardDto;

/**
 * Cache for ServiceCards which have been removed from the 
 * Queue and are currently displayed.
 * @author Dr. Michael Gorski
 *
 */
public class ServiceCardCache {

  private static ServiceCardCache instance;
  
  private Queue<ServiceCardDto> serviceCardDtoQueue = new LinkedList<>(); 

  private ServiceCardCache() {
  }
  
  public static ServiceCardCache getSharedInstance() {
    if (instance == null) {
      instance = new ServiceCardCache();
    }
    return instance;
  }
  
  public void append(ServiceCardDto serviceCardDto) {
    serviceCardDtoQueue.add(serviceCardDto);
    if (serviceCardDtoQueue.size() > 2) {
      serviceCardDtoQueue.poll();
    }
  }
  
  public ServiceCardDto getNext() {
    return serviceCardDtoQueue.poll();
  }
  
  public void clear() {
    serviceCardDtoQueue.clear();
  }
  
}
