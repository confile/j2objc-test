package majestella.core.app.serviceSelection.server;

import majestella.core.rest.ServiceCardRestService;
import majestella.core.rest.dto.BooleanDto;
import majestella.core.rest.dto.GetResult;

public class ServiceSelectionPostRequestList {


  public interface ResultCallback {
    void onResult(GetResult<BooleanDto> result);
  }
  
  public String serviceCardId;
  public boolean liked;  
  public boolean removedFromWishList;
  public ServiceCardRestService serviceCardRestService;
  public ResultCallback resultCallback;
  
  public ServiceSelectionPostRequestList(String serviceCardId, boolean liked, boolean removedFromWishList,
      ServiceCardRestService serviceCardRestService, ResultCallback resultCallback) {
    this.serviceCardId = serviceCardId;
    this.liked = liked;
    this.removedFromWishList = removedFromWishList;
    this.serviceCardRestService = serviceCardRestService;
    this.resultCallback = resultCallback;
  }
  
}
