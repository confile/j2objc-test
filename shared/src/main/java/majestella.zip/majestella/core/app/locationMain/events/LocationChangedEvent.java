package majestella.core.app.locationMain.events;

 
import majestella.core.prototype.eventBus.AbstractBEvent;
import majestella.core.prototype.eventBus.BEventHandler;
import majestella.core.prototype.eventBus.BHasHandlers;
import majestella.core.rest.dto.LocationDto;


/**
 * This event is fired when the location has changed.
 * @author Dr. Michael Gorski
 *
 */
public class LocationChangedEvent extends AbstractBEvent<LocationChangedEvent.LocationChangedHandler> {

  
  public static Type<LocationChangedHandler> TYPE = new Type<LocationChangedHandler>();
  
  public interface LocationChangedHandler extends BEventHandler {
    void onLocationChanged(LocationChangedEvent event);
  }
  
  private LocationDto locationDto;
  
  public LocationChangedEvent(LocationDto locationDto) {
    this.locationDto = locationDto;
  }

  public LocationDto getLocationDto() {
    return locationDto;
  }
  
  @Override
  public AbstractBEvent.Type<LocationChangedHandler> getAssociatedType() {
    return TYPE;
  }
  
  public static Type<LocationChangedHandler> getType() {
    return TYPE;
  }

  @Override
  protected void dispatch(LocationChangedHandler handler) {
    handler.onLocationChanged(this);
  }
  
  public static void fire(BHasHandlers source, LocationDto locationDto) {
    source.fireEvent(new LocationChangedEvent(locationDto));
  }
  
 
  
}
