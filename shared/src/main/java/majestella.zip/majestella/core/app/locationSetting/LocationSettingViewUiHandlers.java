package majestella.core.app.locationSetting;

import majestella.core.prototype.mvp.BUiHandlers;
import majestella.core.rest.dto.LocationListItemDto;

public interface LocationSettingViewUiHandlers extends BUiHandlers {

  void backTapped();
 
  void requestLocations(double latitude, double longitude);
  
  void requestLocation(int type, String objectId);
  
  void selectLocation(LocationListItemDto locationDto);
   
}
