package majestella.core.app.signup.events;

 
import majestella.core.prototype.eventBus.AbstractBEvent;
import majestella.core.prototype.eventBus.BEventHandler;
import majestella.core.prototype.eventBus.BHasHandlers;
import majestella.core.rest.dto.LoginRequestDto;

public class LoginRequestEvent extends AbstractBEvent<LoginRequestEvent.LoginRequestHandler> {

  public enum RedirectType {
    REDIRECT, NONE;
  }  
  
  public static Type<LoginRequestHandler> TYPE = new Type<LoginRequestHandler>();
  
  public interface LoginRequestHandler extends BEventHandler {
    void onLoginRequest(LoginRequestEvent event);
  }

  private LoginRequestDto loginRequestDto;
  private boolean displayNotification;
  
  // if true the user should be redirected after successful login
  private RedirectType redirectType; 
  
  
  public LoginRequestEvent(LoginRequestDto loginRequestDto, RedirectType redirectType, boolean displayNotification) {
    this.loginRequestDto = loginRequestDto;
    this.redirectType = redirectType;
    this.displayNotification = displayNotification;
  }
  
  public LoginRequestDto getLoginRequestDto() {
    return loginRequestDto;
  }
  
  public RedirectType shouldRedirectAfterLogin() {
    return redirectType;
  }
  
  public boolean getDisplayNotification() {
    return displayNotification;
  }
  
  @Override
  public AbstractBEvent.Type<LoginRequestHandler> getAssociatedType() {
    return TYPE;
  }
  
  public static Type<LoginRequestHandler> getType() {
    return TYPE;
  }

  @Override
  protected void dispatch(LoginRequestHandler handler) {
    handler.onLoginRequest(this);
  }
 
  
  public static void fire(BHasHandlers source, LoginRequestDto loginRequestDto, RedirectType redirectType, boolean displayNotification) {
    source.fireEvent(new LoginRequestEvent(loginRequestDto, redirectType, displayNotification));
  }
  
  public static void fire(BHasHandlers source, LoginRequestDto loginRequestDto, RedirectType redirectType) {
    fire(source, loginRequestDto, redirectType, true);
  }
  
}
