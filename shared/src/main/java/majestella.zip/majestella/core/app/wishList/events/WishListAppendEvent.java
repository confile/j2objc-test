package majestella.core.app.wishList.events;

 
import majestella.core.prototype.eventBus.AbstractBEvent;
import majestella.core.prototype.eventBus.BEventHandler;
import majestella.core.prototype.eventBus.BHasHandlers;
import majestella.core.rest.dto.ServiceCardDto;


/**
 * This event is fired when the ServiceSelectionPresenter will append a ServiceCard to
 * the wishlist.
 * @author Dr. Michael Gorski
 *
 */
public class WishListAppendEvent extends AbstractBEvent<WishListAppendEvent.WishListAppendHandler> {

  
  public static Type<WishListAppendHandler> TYPE = new Type<WishListAppendHandler>();
  
  public interface WishListAppendHandler extends BEventHandler {
    void onWishListAppended(WishListAppendEvent event);
  }
  
  private ServiceCardDto serviceCardDto;
  
  public WishListAppendEvent(ServiceCardDto serviceCardDto) {
    this.serviceCardDto = serviceCardDto;
  }

  public ServiceCardDto getServiceCardDto() {
    return serviceCardDto;
  }
  
  @Override
  public AbstractBEvent.Type<WishListAppendHandler> getAssociatedType() {
    return TYPE;
  }
  
  public static Type<WishListAppendHandler> getType() {
    return TYPE;
  }

  @Override
  protected void dispatch(WishListAppendHandler handler) {
    handler.onWishListAppended(this);
  }
  
  public static void fire(BHasHandlers source, ServiceCardDto serviceCardDto) {
    source.fireEvent(new WishListAppendEvent(serviceCardDto));
  }
  
 
  
}
