package majestella.core.app.wishList.events;

 
import majestella.core.prototype.eventBus.AbstractBEvent;
import majestella.core.prototype.eventBus.BEventHandler;
import majestella.core.prototype.eventBus.BHasHandlers;
import majestella.core.rest.dto.ServiceCardDto;


/**
 * This event is fired when a ServiceCard is
 * removed from the WishList.
 * @author Dr. Michael Gorski
 *
 */
public class WishListItemRemoveEvent extends AbstractBEvent<WishListItemRemoveEvent.WishListItemRemoveHandler> {

  
  public static Type<WishListItemRemoveHandler> TYPE = new Type<WishListItemRemoveHandler>();
  
  public interface WishListItemRemoveHandler extends BEventHandler {
    void onWishListItemRemoved(WishListItemRemoveEvent event);
  }
  
  private ServiceCardDto serviceCardDto;
  
  public WishListItemRemoveEvent(ServiceCardDto serviceCardDto) {
    this.serviceCardDto = serviceCardDto;
  }

  public ServiceCardDto getServiceCardDto() {
    return serviceCardDto;
  }
  
  @Override
  public AbstractBEvent.Type<WishListItemRemoveHandler> getAssociatedType() {
    return TYPE;
  }
  
  public static Type<WishListItemRemoveHandler> getType() {
    return TYPE;
  }

  @Override
  protected void dispatch(WishListItemRemoveHandler handler) {
    handler.onWishListItemRemoved(this);
  }
  
  public static void fire(BHasHandlers source, ServiceCardDto serviceCardDto) {
    source.fireEvent(new WishListItemRemoveEvent(serviceCardDto));
  }
  
 
  
}
