package majestella.core.app.locationInfo;

 
import javax.inject.Inject;

import majestella.core.app.locationMain.LocationMainPresenter;
import majestella.core.app.locationMain.events.LocationChangedEvent;
import majestella.core.app.locationMain.events.LocationChangedEvent.LocationChangedHandler;
import majestella.core.place.NameTokens;
import majestella.core.prototype.annotation.NameToken;
import majestella.core.prototype.annotation.ProxyEvent;
import majestella.core.prototype.eventBus.BEventBus;
import majestella.core.prototype.mvp.BAbstractPresenter;
import majestella.core.prototype.mvp.BBaseView;
import majestella.core.prototype.mvp.BHasUiHandlers;
import majestella.core.prototype.mvp.proxy.ProxyPlace;
import majestella.core.prototype.navigation.BPlaceManager;
import majestella.core.rest.dto.LocationDto;

import com.google.auto.factory.AutoFactory;
import com.google.auto.factory.Provided;
 
@AutoFactory(className="LocationInfoPresenterFactory")
public class LocationInfoPresenter extends BAbstractPresenter<LocationInfoPresenter.MyView, LocationInfoPresenter.MyProxy> 
	implements LocationInfoViewUiHandlers, LocationChangedHandler {

  public interface MyView extends BBaseView, BHasUiHandlers<LocationInfoViewUiHandlers> {
    
    void setLocationDto(LocationDto locationDto);
    
  }
  
  @NameToken(NameTokens.locationInfo)
  public interface MyProxy extends ProxyPlace<LocationInfoPresenter> {
  }
  

  private LocationDto locationDto = null; 
  private boolean isViewInitialized = false;
  
  private final BPlaceManager placeManager; 
 
  
  @Inject
  public LocationInfoPresenter(@Provided BEventBus eventBus, BBaseView view, @Provided MyProxy proxy,
      @Provided BPlaceManager placeManager) {
    super(eventBus, (MyView)view, proxy, LocationMainPresenter.SLOT_MAIN); 
    
    this.placeManager = placeManager; 
 
    getView().setUiHandlers(this);     
  }
  
   
  @Override
  protected void onBind() {
    super.onBind();
    logger.info("LocationInfoPresenter - onBind()"); 
  }
  
    
  @Override
  protected void onReveal() {
    super.onReveal();
    logger.info("LocationInfoPresenter - onReveal()");
  }
  
  @Override
  protected void onHide() {
    super.onHide();
    logger.info("LocationInfoPresenter - onHide()");
    
  }
  
   

  // ---------------------------------------------
  // UiHandlers
  // ---------------------------------------------

  
  @Override
  public void viewDidLoad() {
    logger.info("LocationInfoPresenter - viewDidLoad()");
    isViewInitialized = true;
    if (locationDto != null) {
      getView().setLocationDto(locationDto);
    }
  }
   
  
  @Override
  public void backTapped() {
    logger.info("LocationInfoPresenter - backTapped()");
    placeManager.navigateBack();
  }
  
  
  // ---------------------------------------------
  // Events
  // ---------------------------------------------

  
  @ProxyEvent
  @Override
  public void onLocationChanged(LocationChangedEvent event) {
    logger.info("LocationInfoPresenter - onLocationChanged()");
    if (!event.getLocationDto().equals(locationDto)) {
      locationDto = event.getLocationDto();
      if (isViewInitialized) {
        getView().setLocationDto(locationDto);
      }
    }
  }
 
  
}
