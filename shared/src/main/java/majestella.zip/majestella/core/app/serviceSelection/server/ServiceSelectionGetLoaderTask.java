package majestella.core.app.serviceSelection.server;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import majestella.core.bootstrap.ParameterConfig;
import majestella.core.prototype.mvp.proxy.BAsyncCallback;
import majestella.core.rest.dto.GetResults;
import majestella.core.rest.dto.ServiceCardDto;
import android.os.AsyncTask;


/**
 * This class is used to comunicate with the server on a 
 * background thread.
 * @author Dr. Michael Gorski
 *
 */
public class ServiceSelectionGetLoaderTask extends AsyncTask<ServiceSelectionGetRequestList, Void, GetResults<ServiceCardDto>> {

  private final CountDownLatch latch = new CountDownLatch(1);
  private GetResults<ServiceCardDto> callbackResult = null;
  private ServiceSelectionGetRequestList requestList = null;
  
  
  @Override
  protected GetResults<ServiceCardDto> doInBackground(ServiceSelectionGetRequestList... params) {
    
    requestList = params[0];
    
    final Logger logger = Logger.getLogger(ParameterConfig.LOGGER_MAJESTELLA_NAME);
    logger.info("<<< ServiceSelectionGetLoaderTask - callServerServiceCardAction(): company: "+requestList.locationId);
    
    try { 
      requestList.serviceCardRestService.get(requestList.locationType, requestList.locationId, requestList.offset, requestList.aroundMe,
          new BAsyncCallback<GetResults<ServiceCardDto>>() {
        
            @Override
            public void onFailure(Exception e) {
              logger.log(Level.SEVERE, 
              "ServiceSelectionGetLoaderTask - callServerServiceCardAction(): Cannot contact server.",
              e);
              callbackResult = null;
              latch.countDown();
            }
        
            @Override
            public void onSuccess(GetResults<ServiceCardDto> result) {
              logger.info(">>> ServiceSelectionGetLoaderTask - callServerServiceCardAction(): count: "+result.getResults().size());
              
              callbackResult = result;
              latch.countDown();          
            }          
          });  
      
      
      if (latch.await(ParameterConfig.SERVER_REQUEST_TIMEOUT, TimeUnit.SECONDS)) {
        return callbackResult;
      }
      else {
        return null; // timeout
      }
    }
    catch(InterruptedException ex) {
      logger.severe("ServiceSelectionGetLoaderTask request interrupted error: "+ex);
      return null;
    }     
  }
  
  @Override
  protected void onPostExecute(GetResults<ServiceCardDto> result) {
    if (requestList.resultCallback != null) {
      requestList.resultCallback.onResult(result);
    }
  }

}
