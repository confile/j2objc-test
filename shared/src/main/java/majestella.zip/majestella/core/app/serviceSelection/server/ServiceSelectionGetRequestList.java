package majestella.core.app.serviceSelection.server;

import majestella.core.rest.ServiceCardRestService;
import majestella.core.rest.dto.GetResults;
import majestella.core.rest.dto.ServiceCardDto;

public class ServiceSelectionGetRequestList {

  public interface ResultCallback {
    void onResult(GetResults<ServiceCardDto> result);
  }
  
  public int locationType;
  public String locationId;
  public int offset;
  public boolean aroundMe;  
  public ServiceCardRestService serviceCardRestService;
  public ResultCallback resultCallback;
  
  
  public ServiceSelectionGetRequestList(int locationType, String locationId, int offset, boolean aroundMe, 
      ServiceCardRestService serviceCardRestService, ResultCallback resultCallback) {
    
    this.locationType = locationType;
    this.locationId = locationId;
    this.offset = offset;
    this.aroundMe = aroundMe;
    this.serviceCardRestService = serviceCardRestService;
    this.resultCallback = resultCallback;
  }
  
}
