package majestella.core.app.locationMain;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import majestella.core.bootstrap.ParameterConfig;
import majestella.core.prototype.mvp.proxy.BAsyncCallback;
import majestella.core.rest.dto.GetResult;
import majestella.core.rest.dto.LocationDto;
import android.os.AsyncTask;

public class LocationMainLoaderTask extends AsyncTask<LocationMainRequestList, Void, GetResult<LocationDto>> {

  private final CountDownLatch latch = new CountDownLatch(1);
  private LocationMainRequestList requestList = null;
  private GetResult<LocationDto> callbackResult = null;
  
  
  @Override
  protected GetResult<LocationDto> doInBackground(LocationMainRequestList... params) {
   
    requestList = params[0];
    
    final Logger logger = Logger.getLogger(ParameterConfig.LOGGER_MAJESTELLA_NAME);
    logger.info("<<< LocationMainLoaderTask - callServerLocationInfoActivity(): locationId: "+requestList.locationId);
    
    try {   
            
      requestList.locationRestService.get(requestList.locationId, requestList.locationType, 
          new BAsyncCallback<GetResult<LocationDto>>() {
        
        @Override
        public void onFailure(Exception e) {
          logger.log(Level.SEVERE, 
              "LocationMainLoaderTask - callServerLocationInfoActivity(): Cannot contact server.",
              e);
          callbackResult = null;
          latch.countDown();
        }
        
        @Override
        public void onSuccess(GetResult<LocationDto> result) {
          logger.info(">>> LocationMainLoaderTask - callServerLocationInfoActivity()");
          
          callbackResult = result;
          latch.countDown();
        }        
      });    
    
      if (latch.await(ParameterConfig.SERVER_REQUEST_TIMEOUT, TimeUnit.SECONDS)) {
        return callbackResult;
      }
      else {
        return null; // timeout
      }
    }
    catch(InterruptedException ex) {
      logger.severe("LocationMainLoaderTask request interrupted error: "+ex);
      return null;
    } 
  }
  
  
  @Override
  protected void onPostExecute(GetResult<LocationDto> result) {
    if (requestList.resultCallback != null) {
      requestList.resultCallback.onResult(result);
    }  
  }

}
