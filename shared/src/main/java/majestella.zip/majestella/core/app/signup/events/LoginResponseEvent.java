package majestella.core.app.signup.events;

 
import majestella.core.prototype.eventBus.AbstractBEvent;
import majestella.core.prototype.eventBus.BEventHandler;

public class LoginResponseEvent extends AbstractBEvent<LoginResponseEvent.LoginResponseHandler> {

  public static Type<LoginResponseHandler> TYPE = new Type<LoginResponseHandler>();
  
  public interface LoginResponseHandler extends BEventHandler {
    void onLoginResponse(LoginResponseEvent event);
  }

  @Override
  public AbstractBEvent.Type<LoginResponseHandler> getAssociatedType() {
    return TYPE;
  }
  
  public static Type<LoginResponseHandler> getType() {
    return TYPE;
  }

  @Override
  protected void dispatch(LoginResponseHandler handler) {
    handler.onLoginResponse(this);
  }
 
  
  
}
