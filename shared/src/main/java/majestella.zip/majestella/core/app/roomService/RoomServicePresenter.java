package majestella.core.app.roomService;

 
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import majestella.core.app.locationMain.LocationMainPresenter;
import majestella.core.app.roomServiceCard.ShoppingCard;
import majestella.core.place.NameTokens;
import majestella.core.place.UrlTokens;
import majestella.core.prototype.annotation.ContentSlot;
import majestella.core.prototype.annotation.NameToken;
import majestella.core.prototype.eventBus.AbstractBEvent.Type;
import majestella.core.prototype.eventBus.BEventBus;
import majestella.core.prototype.mvp.BAbstractPresenter;
import majestella.core.prototype.mvp.BBaseView;
import majestella.core.prototype.mvp.BHasUiHandlers;
import majestella.core.prototype.mvp.proxy.BRevealContentHandler;
import majestella.core.prototype.mvp.proxy.ProxyPlace;
import majestella.core.prototype.navigation.BPlaceManager;
import majestella.core.prototype.navigation.BPlaceRequest;
import majestella.core.rest.RoomServiceRestService;
import majestella.core.rest.dto.GetResult;
import majestella.core.rest.dto.RoomServiceCategoryDto;
import majestella.core.rest.dto.RoomServiceDomainDto;
import majestella.core.rest.dto.RoomServiceItemDto;

import com.google.auto.factory.AutoFactory;
import com.google.auto.factory.Provided;
import com.google.common.base.Strings;

import dagger.Lazy;
 
@AutoFactory(className="RoomServicePresenterFactory")
public class RoomServicePresenter extends BAbstractPresenter<RoomServicePresenter.MyView, RoomServicePresenter.MyProxy> 
	implements RoomServiceViewUiHandlers {

  public interface MyView extends BBaseView, BHasUiHandlers<RoomServiceViewUiHandlers> {
    void setData(String titleImageUrl, List<RoomServiceCategoryDto> categoryDtos);
  }
  
  @NameToken(NameTokens.roomService)
  public interface MyProxy extends ProxyPlace<RoomServicePresenter> {
  }
  
  @ContentSlot
  public static final Type<BRevealContentHandler<?>> SLOT_CARD = new Type<BRevealContentHandler<?>>();
  
 
  private String hotelId = "";
  private String titleImageUrl = "";
  private List<RoomServiceCategoryDto> roomServiceCategoryDtos = new ArrayList<>();
  private boolean isViewInitialized = false;
  
  
  private final BPlaceManager placeManager;
  private final Lazy<RoomServiceRestService> lazyRoomServiceRestService;   
  
  @Inject
  public RoomServicePresenter(@Provided BEventBus eventBus, BBaseView view, @Provided MyProxy proxy,
      @Provided BPlaceManager placeManager, 
      @Provided Lazy<RoomServiceRestService> lazyRoomServiceRestService) {
    super(eventBus, (MyView)view, proxy, LocationMainPresenter.SLOT_MAIN); 
    
    this.placeManager = placeManager;  
    this.lazyRoomServiceRestService = lazyRoomServiceRestService;
    
    getView().setUiHandlers(this);     
  }
  
  
  @Override
  public void prepareFromRequest(BPlaceRequest request) {
    super.prepareFromRequest(request);
    
    logger.info("RoomServicePresenter - prepareFromRequest()");
    clearSlot(SLOT_CARD);
    
    String newHotelId = request.getParameter(UrlTokens.LOCATION_ID, ""); 
    
    if ( (!newHotelId.equals(hotelId)) && (!newHotelId.equals("")) ) {
      logger.info("RoomServicePresenter - prepareFromRequest() new location: "+newHotelId); 
      hotelId = newHotelId;
      roomServiceCategoryDtos.clear();
      titleImageUrl = "";
      callServerRoomServiceActivity();
    }
  }
  
  
  @Override
  protected void onBind() {
    super.onBind();
    logger.info("RoomServicePresenter - onBind()"); 
  }
  
    
  @Override
  protected void onReveal() {
    super.onReveal();
    logger.info("RoomServicePresenter - onReveal()");
  }
  
  @Override
  protected void onHide() {
    super.onHide();
    logger.info("RoomServicePresenter - onHide()");
     
  }
   
  
  private void callServerRoomServiceActivity() {
    
    RoomServiceRequestList requestList = new RoomServiceRequestList(hotelId, lazyRoomServiceRestService.get(), 
        new RoomServiceRequestList.ResultCallback() {
          
          @Override
          public void onResult(GetResult<RoomServiceDomainDto> result) {
            if (result != null) {
              roomServiceCategoryDtos = result.getResult().getRoomServiceCategoryDtos();
              titleImageUrl = result.getResult().getTitleImageUrl();
              if (isViewInitialized) {
                getView().setData(titleImageUrl, roomServiceCategoryDtos);
              }
            }
          }
        });
    
    // call server on a background thread
    new RoomServiceLoaderTask().execute(requestList);
    
    // TODO delete OLD
    
//    logger.info("<<< RoomServicePresenter - callServerRoomServiceActivity(): hotelId: "+this.hotelId);
//       
//    lazyRoomServiceRestService.get().get(this.hotelId, new BAsyncCallback<GetResult<RoomServiceDomainDto>>() {
//      
//      @Override
//      public void onFailure(Exception e) {
//        logger.log(Level.SEVERE, 
//            "RoomServicePresenter - callServerRoomServiceActivity(): Cannot contact server.",
//            e);
//      }
//      
//      @Override
//      public void onSuccess(GetResult<RoomServiceDomainDto> result) {
//        logger.info(">>> RoomServicePresenter - callServerRoomServiceActivity(): count: "+
//              result.getResult().getRoomServiceCategoryDtos().size());
//        
//        roomServiceCategoryDtos = result.getResult().getRoomServiceCategoryDtos();
//        titleImageUrl = result.getResult().getTitleImageUrl();
//        logger.info(" RoomServicePresenter - callServerRoomServiceActivity() isViewInitialized: "+isViewInitialized);
//        if (isViewInitialized) {          
//          getView().setData(titleImageUrl, roomServiceCategoryDtos);
//        }
//      }
//    });
  }
  
 
  // ---------------------------------------------
  // UiHandlers
  // ---------------------------------------------

  @Override
  public void viewDidLoad() {
    logger.info("RoomServicePresenter - viewDidLoad()");
    isViewInitialized = true;
    
    logger.info("RoomServicePresenter - viewDidLoad() titleImageUrl: "+titleImageUrl+
        " roomServiceCategoryDtos: "+roomServiceCategoryDtos);
    
    if ( (!Strings.isNullOrEmpty(titleImageUrl)) && (roomServiceCategoryDtos.size() > 0) ) { 
      getView().setData(titleImageUrl, roomServiceCategoryDtos);
    }
  }

  
  @Override
  public void backTapped() {
    placeManager.navigateBack();
  }
  
  
  @Override
  public void shoppingCardTapped() {
    BPlaceRequest request = new BPlaceRequest.Builder()
      .nameToken(NameTokens.getRoomServiceCard()) 
      .with(UrlTokens.LOCATION_ID, hotelId)
      .build();
    placeManager.revealPlace(request); 
  }
  
 
  @Override
  public boolean isItemOnCard(RoomServiceItemDto roomServiceItemDto) {
    return ShoppingCard.getSharedInstance().isItemOnCard(roomServiceItemDto);
  }

  
  @Override
  public int getTotelItemsOnCard() {
    return ShoppingCard.getSharedInstance().getTotalItemsCount();
  }
  
  
  @Override
  public int getTotalItemsByTypeOnCard(RoomServiceItemDto roomServiceItemDto) {
    return ShoppingCard.getSharedInstance().getTotalItemsCountByType(roomServiceItemDto);
  }
  
  
  @Override
  public void addItemToCard(RoomServiceItemDto roomServiceItemDto) {
    ShoppingCard.getSharedInstance().addItemToCard(roomServiceItemDto);
  }
    
  
  // ---------------------------------------------
  // Events
  // ---------------------------------------------

 
  
}
