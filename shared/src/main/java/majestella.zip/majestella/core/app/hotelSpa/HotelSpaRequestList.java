package majestella.core.app.hotelSpa;

import majestella.core.rest.HotelSpaRestService;
import majestella.core.rest.dto.GetResult;
import majestella.core.rest.dto.HotelSpaDto;

public class HotelSpaRequestList {

  public interface ResultCallback {
    void onResult(GetResult<HotelSpaDto> result);
  }
  
  public String hotelId;
  public HotelSpaRestService hotelSpaRestService;
  public ResultCallback resultCallback;
  
  public HotelSpaRequestList(String hotelId, HotelSpaRestService hotelSpaRestService,
      ResultCallback resultCallback) {
    this.hotelId = hotelId;
    this.hotelSpaRestService = hotelSpaRestService;
    this.resultCallback = resultCallback;
  }
  
  
  
}
