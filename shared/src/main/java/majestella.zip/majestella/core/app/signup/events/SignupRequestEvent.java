package majestella.core.app.signup.events;

 
import majestella.core.prototype.eventBus.AbstractBEvent;
import majestella.core.prototype.eventBus.BEventHandler;
import majestella.core.prototype.eventBus.BHasHandlers;
import majestella.core.rest.dto.UserDetailsDto;

public class SignupRequestEvent extends AbstractBEvent<SignupRequestEvent.SignupRequestHandler> {

  public static Type<SignupRequestHandler> TYPE = new Type<SignupRequestHandler>();
  
  public interface SignupRequestHandler extends BEventHandler {
    void onSignupRequest(SignupRequestEvent event);
  }

  private UserDetailsDto userDetailsDto;
  
  public SignupRequestEvent(UserDetailsDto userDetailsDto) {
    this.userDetailsDto = userDetailsDto;
  }

  public UserDetailsDto getUserDetailsDto() {
    return userDetailsDto;
  }
  
  @Override
  public AbstractBEvent.Type<SignupRequestHandler> getAssociatedType() {
    return TYPE;
  }
  
  public static Type<SignupRequestHandler> getType() {
    return TYPE;
  }

  @Override
  protected void dispatch(SignupRequestHandler handler) {
    handler.onSignupRequest(this);
  }
 
  public static void fire(BHasHandlers source, UserDetailsDto userDetailsDto) {
    source.fireEvent(new SignupRequestEvent(userDetailsDto));
  }
  
}
