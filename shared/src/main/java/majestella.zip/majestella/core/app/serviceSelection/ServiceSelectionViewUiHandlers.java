package majestella.core.app.serviceSelection;

import com.google.j2objc.annotations.ObjectiveCName;

import majestella.core.prototype.mvp.BUiHandlers;
import majestella.core.rest.dto.ServiceCardDto;

public interface ServiceSelectionViewUiHandlers extends BUiHandlers {

  public interface ServiceSelectionCallback {
    
    @ObjectiveCName(value="onCallback:liked:")
    void onCallback(boolean performAction, boolean liked);
    
  }
  
  
  /**
   * View has been initialized.
   */
  void viewDidLoad();
  
  /**
   * View did appear on the screen.
   */
  void viewDidAppear();
  
  /**
   * Check if there is another ServiceCardDto available.
   * @return
   */
  boolean hasNextServiceCardDto();
  
  
  /**
   * Retrieves the next ServiceCardDto and removes it
   * from the queue.
   * @return
   */
  ServiceCardDto popServiceCardDto();
  
  /**
   * This is called when a card has been tapped.
   * @param serviceCardDto
   */
  void cardTapped(ServiceCardDto serviceCardDto);
  
  /**
   * A like or nope action is performed on a card.
   * @param serviceCardDto
   * @param liked
   */
  void cardAction(ServiceCardDto serviceCardDto, boolean liked);

  
  /**
   * This method is called when a segment has been selected.
   * @param index
   */
  void segmentSelected(int index);
  
  
  /**
   * Start selecting ServiceCards from the beginning.
   */
  void restartServiceCards();
  
  /**
   * Check if an action can be performed by a user.
   * @param like
   * @param button
   * @return
   */
  @ObjectiveCName(value="shouldBeChosen:button:")
  boolean shouldBeChosen(boolean like, boolean button);
  
  
  /**
   * Show a tour dialog to the user.
   * @param like
   * @param button
   * @param callback
   */
  @ObjectiveCName(value="showTourIntro:button:callback:")
  void showTourIntro(boolean like, boolean button, ServiceSelectionCallback callback);
  
  
  /**
   * Return the number of items on the wish list.
   * @return
   */
  int getWishListSize();
  
}
