package majestella.core.app.wishList;

import java.util.ArrayList;
import java.util.List;

import majestella.core.rest.dto.ServiceCardDto;

public class WishList {

  private static WishList instance;
  
  private List<ServiceCardDto> wishListItems = new ArrayList<>();
  
  private WishList() {
  }
  
  public static WishList getSharedInstance() {
    if (instance == null) {
      instance = new WishList();
    }
    return instance;
  }
  
  public synchronized int getSize() {
    return wishListItems.size();
  }
  
  public synchronized boolean addItem(ServiceCardDto item) {
    if (wishListItems.contains(item)) {
      return false;
    }
    wishListItems.add(0, item);
    return true;
  }
  
  public synchronized ServiceCardDto removeItem(int index) {
    return wishListItems.remove(index);
  }
  
  public synchronized ServiceCardDto getItem(int index) {
    if (index < wishListItems.size()) {
      return wishListItems.get(index);
    }
    return null;
  }
  
}
