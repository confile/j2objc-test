package majestella.core.app.hotelRestaurant;

import majestella.core.rest.HotelRestaurantRestService;
import majestella.core.rest.dto.GetResults;
import majestella.core.rest.dto.HotelRestaurantDto;

public class HotelRestaurantRequestList {

  public interface ResultCallback {
    void onResult(GetResults<HotelRestaurantDto> result);
  }
  
  public String hotelId;
  public HotelRestaurantRestService hotelRestaurantRestService;
  public ResultCallback resultCallback;
  
  
  public HotelRestaurantRequestList(String hotelId, HotelRestaurantRestService hotelRestaurantRestService,
      ResultCallback resultCallback) {
    this.hotelId = hotelId;
    this.hotelRestaurantRestService = hotelRestaurantRestService;
    this.resultCallback = resultCallback;
  }
  
  
  
}
