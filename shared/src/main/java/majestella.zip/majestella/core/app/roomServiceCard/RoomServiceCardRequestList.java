package majestella.core.app.roomServiceCard;

import java.util.Date;

import majestella.core.rest.RoomServiceRestService;
import majestella.core.rest.dto.BooleanDto;
import majestella.core.rest.dto.GetResult;
import majestella.core.rest.dto.RoomServiceOrderDto;

public class RoomServiceCardRequestList {

  public interface ResultCallback {
    void onResult(GetResult<BooleanDto> result);
  }
  
  public String locationId;
  public RoomServiceOrderDto roomServiceOrderDto;
  public String lastName;
  public int roomNumber;
  public Date departureDate;
  public RoomServiceRestService roomServiceRestService;
  public ResultCallback resultCallback;
  
  public RoomServiceCardRequestList(String locationId, RoomServiceOrderDto roomServiceOrderDto, 
      String lastName, int roomNumber, Date departureDate,
      RoomServiceRestService roomServiceRestService, 
      ResultCallback resultCallback) {
    this.locationId = locationId;
    this.roomServiceOrderDto = roomServiceOrderDto;
    this.lastName = lastName;
    this.roomNumber = roomNumber;
    this.departureDate = departureDate;
    this.roomServiceRestService = roomServiceRestService;
    this.resultCallback = resultCallback;
  }
  
}
