package majestella.core.app.signup.events;

 
import majestella.core.prototype.eventBus.AbstractBEvent;
import majestella.core.prototype.eventBus.BEventHandler;
import majestella.core.prototype.eventBus.BHasHandlers;

public class LogoutRequestEvent extends AbstractBEvent<LogoutRequestEvent.LogoutRequestHandler> {
  
  public static Type<LogoutRequestHandler> TYPE = new Type<LogoutRequestHandler>();
  
  public interface LogoutRequestHandler extends BEventHandler {
    void onLogoutRequest(LogoutRequestEvent event);
  }
  
  @Override
  public AbstractBEvent.Type<LogoutRequestHandler> getAssociatedType() {
    return TYPE;
  }
  
  public static Type<LogoutRequestHandler> getType() {
    return TYPE;
  }

  @Override
  protected void dispatch(LogoutRequestHandler handler) {
    handler.onLogoutRequest(this);
  }
 
  public static void fire(BHasHandlers source) {
    source.fireEvent(new LogoutRequestEvent());
  }
  
}
