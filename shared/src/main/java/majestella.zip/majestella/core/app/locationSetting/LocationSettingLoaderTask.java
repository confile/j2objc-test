package majestella.core.app.locationSetting;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import majestella.core.bootstrap.ParameterConfig;
import majestella.core.prototype.mvp.proxy.BAsyncCallback;
import majestella.core.rest.dto.GetResult;
import majestella.core.rest.dto.LocationListDto;
import android.os.AsyncTask;

/**
 * This class is used to comunicate with the server on a 
 * background thread.
 * @author Dr. Michael Gorski
 *
 */
public class LocationSettingLoaderTask extends AsyncTask<LocationSettingRequestList, Void, LocationListDto> {

  private final CountDownLatch latch = new CountDownLatch(1);
  private LocationListDto callbackResult = null;
  private LocationSettingRequestList requestList = null;
  
  
  @Override
  protected LocationListDto doInBackground(LocationSettingRequestList... params) {
    
    requestList = params[0];
    
    final Logger logger = Logger.getLogger(ParameterConfig.LOGGER_MAJESTELLA_NAME);
    logger.info("<<< LocationSettingLoaderTask - callServerLocationAction()");
    
    try {    
      requestList.locationListRestService.get(requestList.latitude, requestList.longitude, requestList.type, 
          requestList.objectId, new BAsyncCallback<GetResult<LocationListDto>>() {
  
        @Override
        public void onFailure(Exception e) {
          logger.log(Level.SEVERE, 
              "LocationSettingLoaderTask - callServerLocationAction(): Cannot contact server.",
              e);
          callbackResult = null;
          latch.countDown();
        }
  
        @Override
        public void onSuccess(GetResult<LocationListDto> result) {
          LocationListDto locationListDto = result.getResult();
          logger.info(">>> LocationSettingLoaderTask - callServerLocationAction(): locations: "+locationListDto.getDtos().size());

          callbackResult = locationListDto;
          latch.countDown();
        }        
      });  
      
      if (latch.await(ParameterConfig.SERVER_REQUEST_TIMEOUT, TimeUnit.SECONDS)) {
        return callbackResult;
      }
      else {
        return null; // timeout
      }
    }
    catch(InterruptedException ex) {
      logger.severe("LocationSettingLoaderTask request interrupted error: "+ex);
      return null;
    } 
  }
  
  
  @Override
  protected void onPostExecute(LocationListDto locationListDto) {
    if (requestList.resultCallback != null) {
      requestList.resultCallback.onResult(locationListDto);
    }    
  }
  
}
