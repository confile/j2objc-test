package majestella.core.app.serviceSelection.events;

 
import majestella.core.prototype.eventBus.AbstractBEvent;
import majestella.core.prototype.eventBus.BEventHandler;
import majestella.core.prototype.eventBus.BHasHandlers;
import majestella.core.rest.dto.ServiceCardDto;


/**
 * This event is fired when the ServiceDetailsPresenter should update its data.
 * @author Dr. Michael Gorski
 *
 */
public class ServiceDetailsUpdateEvent extends AbstractBEvent<ServiceDetailsUpdateEvent.ServiceDetailsUpdateHandler> {

  
  public static Type<ServiceDetailsUpdateHandler> TYPE = new Type<ServiceDetailsUpdateHandler>();
  
  public interface ServiceDetailsUpdateHandler extends BEventHandler {
    void onServiceDetailsUpdated(ServiceDetailsUpdateEvent event);
  }
  
  private ServiceCardDto serviceCardDto;
  
  public ServiceDetailsUpdateEvent(ServiceCardDto serviceCardDto) {
    this.serviceCardDto = serviceCardDto;
  }

  public ServiceCardDto getServiceCardDto() {
    return serviceCardDto;
  }
  
  @Override
  public AbstractBEvent.Type<ServiceDetailsUpdateHandler> getAssociatedType() {
    return TYPE;
  }
  
  public static Type<ServiceDetailsUpdateHandler> getType() {
    return TYPE;
  }

  @Override
  protected void dispatch(ServiceDetailsUpdateHandler handler) {
    handler.onServiceDetailsUpdated(this);
  }
  
  public static void fire(BHasHandlers source, ServiceCardDto serviceCardDto) {
    source.fireEvent(new ServiceDetailsUpdateEvent(serviceCardDto));
  }
  
 
  
}
