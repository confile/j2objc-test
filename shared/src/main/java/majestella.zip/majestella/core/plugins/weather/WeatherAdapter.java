package majestella.core.plugins.weather;

import majestella.core.plugins.AbstractPluginAdapter;

public interface WeatherAdapter extends AbstractPluginAdapter, Weather {

}
