package majestella.core.plugins.toast;

import majestella.core.plugins.AbstractPluginAdapter;

public interface ToastPluginAdapter extends AbstractPluginAdapter, ToastPlugin {

}
