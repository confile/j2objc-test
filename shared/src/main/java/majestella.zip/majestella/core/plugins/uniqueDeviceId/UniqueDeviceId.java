package majestella.core.plugins.uniqueDeviceId;


/**
 * See: https://github.com/Paldom/UniqueDeviceID
 * @author Dr. Michael Gorski
 *
 */
public interface UniqueDeviceId {

  public String getUUID();
  
}
