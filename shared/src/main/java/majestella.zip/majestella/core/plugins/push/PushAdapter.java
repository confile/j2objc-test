package majestella.core.plugins.push;

import majestella.core.plugins.AbstractPluginAdapter;

public interface PushAdapter extends AbstractPluginAdapter, Push {

}
