package majestella.core.plugins.actionSheet;

/**
 * See: https://github.com/EddyVerbruggen/cordova-plugin-actionsheet
 * @author Dr. Michael Gorski
 *
 */
public interface ActionSheet {

  public void show(ActionSheetOptions options, ActionSheetCallback callback);
  
}
