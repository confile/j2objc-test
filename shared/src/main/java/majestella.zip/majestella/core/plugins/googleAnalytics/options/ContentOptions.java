package majestella.core.plugins.googleAnalytics.options;

public class ContentOptions extends AnalyticsOptions {
    ContentOptions(final OptionsCallback<?> optionsCallback) {
        super(optionsCallback);
    }

    /**
     * Optional.
     * </p>
     * <p>Specifies the hostname from which content was hosted.</p>
     * Default Value: None<br>
     * Example Value: <code>foo.com</code>
     **/
    public ContentOptions documentHostName(final String documentHostName) {
        putText("hostname", documentHostName);
        return this;
    }

    /**
     * Optional.
     * </p>
     * <p>Specifies the full URL (excluding anchor) of the page. This field is initialized by the create command.</p>
     * Default Value: None<br>
     * Example Value: <code>http://foo.com/home?a=b</code>
     **/
    public ContentOptions documentLocationUrl(final String documentLocationUrl) {
        putText("location", documentLocationUrl);
        return this;
    }

    /**
     * Optional.
     * </p>
     * <p>The path portion of the page URL. Should begin with &#39;/&#39;. Used to specify virtual page paths.</p>
     * Default Value: None<br>
     * Example Value: <code>/foo</code>
     **/
    public ContentOptions documentPath(final String documentPath) {
        putText("page", documentPath.startsWith("/") ? documentPath : "/" + documentPath);
        return this;
    }

    /**
     * Optional.
     * </p>
     * <p>The title of the page / document. Defaults to document.title.</p>
     * Default Value: None<br>
     * Example Value: <code>Settings</code>
     **/
    public ContentOptions documentTitle(final String documentTitle) {
        putText("title", documentTitle);
        return this;
    }

    /**
     * Optional.
     * </p>
     * <p>The ID of a clicked DOM element, used to disambiguate multiple links to the same URL
     * in In-Page Analytics reports when Enhanced Link Attribution is enabled for the property.</p>
     * Default Value: None<br>
     * Example Value: <code>nav_bar</code>
     **/
    public ContentOptions linkId(final String linkId) {
        putText("linkid", linkId);
        return this;
    }

    /**
     * Optional.
     * </p>
     * <p>If not specified, this will default to the unique URL of the page by either using the &amp;dl
     * parameter as-is or assembling it from &amp;dh and &amp;dp. App tracking makes use of this for the
     * &#39;Screen Name&#39; of the screenview hit.</p>
     * Default Value: None<br>
     * Example Value: <code>High Scores</code>
     **/
    public ContentOptions screenName(final String screenName) {
        putText("screenName", screenName);
        return this;
    }
}
