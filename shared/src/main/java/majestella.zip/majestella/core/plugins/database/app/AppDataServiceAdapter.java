package majestella.core.plugins.database.app;

import majestella.core.plugins.AbstractPluginAdapter;

public interface AppDataServiceAdapter extends AbstractPluginAdapter, AppDataService {

}
