package majestella.core.plugins.googleAnalytics.shared;

public enum AnalyticsPlugin {
  /**
   * Add information about user's location and interests.
   * You also need to turn on Enable Demographics and Interest Reports on
   * the google analytics website to use this feature.
   */
  DISPLAY("displayfeatures"),
  
  /**
   * You must also turn on enhanced link attribution on the google analytics website
   * to use this feature.
   * <p>You can tag your pages to implement an enhanced link-tracking functionality that lets you:</p>
   *
   * <ul>
   * <li>See separate information for multiple links on a page that all have the same destination. 
   * For example, if there are two links on the same page that both lead to the <em>Contact Us</em> 
   * page, then you see separate click information for each link.</li>
   * <br>
   * <li>See when one page element has multiple destinations. For example, a <em>Search button</em> on your page is likely to lead to multiple destinations.</li>
   * <br>
   * <li>Track buttons, menus, and actions driven by javascript.</li>
   * </ul>
   */
  ENHANCED_LINK_ATTRIBUTION("linkid", "linkid.js");

  private final String fieldName;
  private final String jsName;
  
  AnalyticsPlugin(final String fieldName) {
      this(fieldName, null);
  }

  AnalyticsPlugin(final String fieldName, final String jsName) {
      this.fieldName = fieldName;
      this.jsName = jsName;
  }

  public String getFieldName() {
      return fieldName;
  }
  
  public String getJsName() {
      return jsName;
  }
}