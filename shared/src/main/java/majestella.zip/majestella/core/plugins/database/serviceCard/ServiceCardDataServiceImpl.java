package majestella.core.plugins.database.serviceCard;

import java.util.List;

import majestella.core.plugins.AbstractPlugin;
import majestella.core.plugins.BPluginType;
import majestella.core.plugins.PluginAdapterHolder;
import majestella.core.plugins.database.ListCallback;
import majestella.core.plugins.database.ScalarCallback;
import majestella.core.plugins.database.VoidCallback;
import majestella.core.rest.dto.ServiceCardDto;

public class ServiceCardDataServiceImpl extends AbstractPlugin<ServiceCardDataServiceAdapter> implements ServiceCardDataService {

  public ServiceCardDataServiceImpl(PluginAdapterHolder pluginAdapterHolder) {
    super(pluginAdapterHolder, BPluginType.SERVICE_CARD_DATABASE);
  }

  @Override
  public void initTable(VoidCallback callback) {
    getAdapter().initTable(callback);
  }

  @Override
  public void dropTable(VoidCallback callback) {
    getAdapter().dropTable(callback);
  }

  @Override
  public void insertOrReplace(List<ServiceCardDto> serviceCardDtos, VoidCallback callback) {
    getAdapter().insertOrReplace(serviceCardDtos, callback);
  }

  @Override
  public void findAll(int offset, int limit, ListCallback<ServiceCardDto> callback) {
    getAdapter().findAll(offset, limit, callback);
  }

  @Override
  public void deleteAllById(List<String> deleteIds, VoidCallback callback) {
    getAdapter().deleteAllById(deleteIds, callback);
  }

  
  @Override
  public void countAll(ScalarCallback<Integer> result) {
    getAdapter().countAll(result);
  }
 
}
