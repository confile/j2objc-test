package majestella.core.plugins.email;

import majestella.core.plugins.AbstractPlugin;
import majestella.core.plugins.BPluginType;
import majestella.core.plugins.PluginAdapterHolder;

public class EmailComposerImpl extends AbstractPlugin<EmailComposerAdapter> implements EmailComposer {

  public EmailComposerImpl(PluginAdapterHolder pluginAdapterHolder) {
    super(pluginAdapterHolder, BPluginType.EMAIL);
  }
  
  @Override
  public void open(EmailComposerOptions data) {
    getAdapter().open(data);
  }
  
  
}
