package majestella.core.plugins.googleAnalytics.options;

public class SocialOptions extends AnalyticsOptions {
    SocialOptions(final OptionsCallback<?> optionsCallback,
            final String socialNetwork,
            final String socialAction,
            final String socialActionTarget) {
        super(optionsCallback);

        putText("socialNetwork", socialNetwork);
        putText("socialAction", socialAction);
        putText("socialTarget", socialActionTarget);
    }
}
