package majestella.core.plugins.systemConfig;

public interface SystemConfig {

  boolean isIOs();
  
  /**
   * Returns true if the device is online.
   * @return
   */
  boolean isOnline();
  
}
