package majestella.core.plugins.inappbrowser;


/**
 * Source: https://github.com/apache/cordova-plugin-inappbrowser
 * @author Dr. Michael Gorski
 *
 */
public interface Inappbrowser {

  /**
   * Opens a URL in a new InAppBrowser instance, the current browser instance, or the system browser.
   * @param url The URL to load (String). Call encodeURI() on this if the URL contains Unicode characters.
   */
  void openWindow(String url);
  
  
  
}
