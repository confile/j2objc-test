package majestella.core.plugins.deviceEvents;

import majestella.core.plugins.AbstractPluginAdapter;

public interface DeviceEventsAdapter extends AbstractPluginAdapter, DeviceEvents {

}
