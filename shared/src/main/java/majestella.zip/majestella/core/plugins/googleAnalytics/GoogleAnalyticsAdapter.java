package majestella.core.plugins.googleAnalytics;

import majestella.core.plugins.AbstractPluginAdapter;
import majestella.core.plugins.googleAnalytics.shared.HitCallback;
import majestella.core.prototype.json.JsonArray;
import majestella.core.prototype.json.JsonObject;
 

public interface GoogleAnalyticsAdapter extends AbstractPluginAdapter {


  void initialize(String userAccount);
  
  /**
   * To track a Screen (PageView)
   * @param pageName
   */
  void trackPageView(String pageName);
  
  /**
   * To track an event.
   * @param category
   * @param action
   * @param label
   * @param value
   */
  void trackEvent(String category, String action, String label, int value);
  
  
  // -------------------
  // Universal Analytics
  // -------------------
  
  void nativeCall(JsonArray params);

  void addHitCallback(JsonObject jsObject, HitCallback callback);
  
  
  
}
