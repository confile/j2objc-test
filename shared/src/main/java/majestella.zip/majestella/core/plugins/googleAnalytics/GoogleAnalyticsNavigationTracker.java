package majestella.core.plugins.googleAnalytics;

import java.util.logging.Logger;

import majestella.core.bootstrap.ParameterConfig;
import majestella.core.prototype.eventBus.BEventBus;
import majestella.core.prototype.navigation.BNavigationEvent;
import majestella.core.prototype.navigation.BNavigationEvent.BNavigationHandler;
import majestella.core.prototype.navigation.BPlaceManager;

/**
 * This class let's you register every navigation event to a Google Analytics
 * account. To use it, you must bind GoogleAnalyticsNavigationTracker as eager singleton.
 * @author Dr. Michael Gorski
 *
 */
public class GoogleAnalyticsNavigationTracker implements BNavigationHandler {

  private boolean isInitialized = false;
  
  private final Logger logger; 
  private final BPlaceManager placeManager;
  private final GoogleAnalytics googleAnalytics;
  private final String gaAccount;
  
  public GoogleAnalyticsNavigationTracker(BEventBus eventBus, BPlaceManager placeManager, GoogleAnalytics googleAnalytics) {
    logger = Logger.getLogger(ParameterConfig.LOGGER_MAJESTELLA_NAME);
    this.placeManager = placeManager;
    this.googleAnalytics = googleAnalytics;
    this.gaAccount = ParameterConfig.GOOGLE_ANALYTICS_ACCOUNT;
    
    eventBus.addHandler(BNavigationEvent.getType(), this);
  }
  
  
  
  // ---------------------------------------------
  // Events
  // ---------------------------------------------

  @Override
  public void onNavigation(BNavigationEvent navigationEvent) {
    String historyToken = placeManager.buildHistoryToken(navigationEvent.getRequest());
    logger.info("GoogleAnalyticsNavigationTracker - onNavigation(): historyToken: "+historyToken);
    
    if (!isInitialized) {
      isInitialized = true;
      googleAnalytics.initialize();
    }
    
//    googleAnalytics.sendPageView().documentPath(historyToken).go();  // for universal analytics
    googleAnalytics.trackPageview(historyToken);
  }
  
  
  
  
}
