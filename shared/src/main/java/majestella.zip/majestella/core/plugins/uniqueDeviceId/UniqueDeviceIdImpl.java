package majestella.core.plugins.uniqueDeviceId;

import majestella.core.plugins.AbstractPlugin;
import majestella.core.plugins.BPluginType;
import majestella.core.plugins.PluginAdapterHolder;

public class UniqueDeviceIdImpl extends AbstractPlugin<UniqueDeviceIdAdapter>
		implements UniqueDeviceId {

	public UniqueDeviceIdImpl(PluginAdapterHolder pluginAdapterHolder) {
		super(pluginAdapterHolder, BPluginType.UNIQUE_DEVICE_ID);
	}

	@Override
	public String getUUID() { 
		return getAdapter().getUUID();
	}

}
