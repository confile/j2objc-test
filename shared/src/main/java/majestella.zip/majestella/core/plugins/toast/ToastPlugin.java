package majestella.core.plugins.toast;



public interface ToastPlugin {

  void createToast(Toast toast);
  
}
