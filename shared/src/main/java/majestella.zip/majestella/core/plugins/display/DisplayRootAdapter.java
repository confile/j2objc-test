package majestella.core.plugins.display;

import majestella.core.plugins.AbstractPluginAdapter;

public interface DisplayRootAdapter extends AbstractPluginAdapter, DisplayRoot {

}
