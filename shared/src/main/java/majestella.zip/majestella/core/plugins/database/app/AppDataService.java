package majestella.core.plugins.database.app;

import majestella.core.plugins.database.ListCallback;
import majestella.core.plugins.database.VoidCallback;

public interface AppDataService {

  void insertOrReplace(String version, VoidCallback callback);
  
  void initTable(VoidCallback callback);
  
  void get(ListCallback<String> callback);
  
  void dropTable(VoidCallback callback);
  
  
}
