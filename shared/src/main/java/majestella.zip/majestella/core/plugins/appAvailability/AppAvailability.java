package majestella.core.plugins.appAvailability;

public interface AppAvailability {

  public void check(String appUrlSchema, AppAvailabilityCallback callback);
    
}
