package majestella.core.plugins.googleAnalytics.client;

import majestella.core.plugins.googleAnalytics.GoogleAnalyticsAdapter;
import majestella.core.plugins.googleAnalytics.options.OptionsCallback;
import majestella.core.plugins.googleAnalytics.shared.HitCallback;
import majestella.core.prototype.json.JsonObject;



public abstract class JSONOptionsCallback extends OptionsCallback<JsonObject> {

  private JsonObject jsonObject;
  private GoogleAnalyticsAdapter adapter;
  
  public JSONOptionsCallback(GoogleAnalyticsAdapter adapter) {
      this.jsonObject = new JsonObject();
  }

  @Override
  public void addHitCallback(final HitCallback callback) {
      addHitCallback(jsonObject, new GuaranteedHitCallback(callback));
  }

  private void addHitCallback(JsonObject jsObject, HitCallback callback) {
      adapter.addHitCallback(jsObject, callback);
  }
  
  @Override
  public JsonObject getOptions() {
      return jsonObject;
  }

  @Override
  public void putBoolean(final String fieldName, final boolean value) {
    jsonObject.put(fieldName, value);
  }

  @Override
  public void putNumber(final String fieldName, final double value) {
      jsonObject.put(fieldName, value);
  }

  @Override
  public void putText(final String fieldName, final String value) {
      jsonObject.put(fieldName, value);
  }
  
}
