package majestella.core.plugins.inappbrowser;

import majestella.core.plugins.AbstractPluginAdapter;

public interface InappbrowserAdapter extends AbstractPluginAdapter, Inappbrowser {

}
