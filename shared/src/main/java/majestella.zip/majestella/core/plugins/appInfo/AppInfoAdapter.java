package majestella.core.plugins.appInfo;

import majestella.core.plugins.AbstractPluginAdapter;

public interface AppInfoAdapter extends AbstractPluginAdapter, AppInfo {

}
