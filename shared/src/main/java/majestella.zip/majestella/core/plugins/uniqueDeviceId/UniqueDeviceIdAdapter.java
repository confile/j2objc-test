package majestella.core.plugins.uniqueDeviceId;

import majestella.core.plugins.AbstractPluginAdapter;

public interface UniqueDeviceIdAdapter extends AbstractPluginAdapter, UniqueDeviceId {

}
