package majestella.core.plugins.cookie;

import majestella.core.plugins.AbstractPlugin;
import majestella.core.plugins.BPluginType;
import majestella.core.plugins.PluginAdapterHolder;
import majestella.core.rest.dto.LoginResultDto;

public class CookieImpl extends AbstractPlugin<CookieAdapter> implements Cookie {
 
  public CookieImpl(PluginAdapterHolder pluginAdapterHolder) {
    super(pluginAdapterHolder, BPluginType.COOKIE);
  }
  
  @Override
  public void clear() {
    getAdapter().clear();
  }

  @Override
  public void setLoggedInCookie(LoginResultDto result) {
    getAdapter().setLoggedInCookie(result);
  }

  @Override
  public String getLoggedInCookie() {
    return getAdapter().getLoggedInCookie();
  }
  
}
