package majestella.core.plugins.spinner;

import majestella.core.plugins.AbstractPlugin;
import majestella.core.plugins.BPluginType;
import majestella.core.plugins.PluginAdapterHolder;

public class SpinnerImpl extends AbstractPlugin<SpinnerAdapter> implements Spinner {

  public SpinnerImpl(PluginAdapterHolder pluginAdapterHolder) {
    super(pluginAdapterHolder, BPluginType.SPINNER);
  }

  @Override
  public void show(String message) {
    getAdapter().show(message);
  }

  @Override
  public void show() {
    getAdapter().show();
  }

  @Override
  public void hide() {
    getAdapter().hide();
  }

  
  @Override
  public void resetProgess() {
    getAdapter().resetProgess();
  }


  @Override
  public void setProgressVisible(boolean visible) {
    getAdapter().setProgressVisible(visible);
  }
  
  @Override
  public void setProgressValue(int value, String text) {
    getAdapter().setProgressValue(value, text);
  }

  
}
