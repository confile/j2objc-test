package majestella.core.plugins.deviceEvents;

import majestella.core.plugins.AbstractPlugin;
import majestella.core.plugins.BPluginType;
import majestella.core.plugins.PluginAdapterHolder;

public class DeviceEventsImpl extends AbstractPlugin<DeviceEventsAdapter> implements DeviceEvents {
 
  public DeviceEventsImpl(PluginAdapterHolder pluginAdapterHolder) {
    super(pluginAdapterHolder, BPluginType.DEVICE_EVENTS);
  }

  @Override
  public void setOfflineHandler(DeviceEventCallback callback) {
    getAdapter().setOfflineHandler(callback);
  }

  @Override
  public void setOnlineHandler(DeviceEventCallback callback) {
    getAdapter().setOnlineHandler(callback);
  }

  @Override
  public void setPauseHandler(DeviceEventCallback callback) {
    getAdapter().setPauseHandler(callback);
  }

  @Override
  public void setResumeHandler(DeviceEventCallback callback) {
    getAdapter().setResumeHandler(callback);
  }
  

}
