package majestella.core.plugins.deviceEvents;


public interface DeviceEvents {

  void setOfflineHandler(DeviceEventCallback callback);
  
  void setOnlineHandler(DeviceEventCallback callback);
  
  void setPauseHandler(DeviceEventCallback callback);
  
  void setResumeHandler(DeviceEventCallback callback);
  
}
