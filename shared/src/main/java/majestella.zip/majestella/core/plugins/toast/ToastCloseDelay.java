package majestella.core.plugins.toast;

public enum ToastCloseDelay {
  NEVER(0),
  SHORT(2000),
  DEFAULT(5000),
  LONG(8000);
  

  private int delay;

  private ToastCloseDelay(int delay) {
      this.delay = delay;
  }

  public int getDelay() {
      return delay;
  }
}
