package majestella.core.plugins;

public abstract class AbstractPlugin<T> {

  private final PluginAdapterHolder pluginAdapterHolder;
  private T adapter;
  private BPluginType type;
  
  public AbstractPlugin(PluginAdapterHolder pluginAdapterHolder, BPluginType type) {
    this.pluginAdapterHolder = pluginAdapterHolder;
    this.type = type;
  }
  
  @SuppressWarnings("unchecked")
  protected T getAdapter() {
    if (adapter == null) {
      adapter = (T) pluginAdapterHolder.get(type);
    }
    return adapter;
  }
  
}
