package majestella.core.plugins.email;

public interface EmailComposer {

  void open(EmailComposerOptions data);
  
}
