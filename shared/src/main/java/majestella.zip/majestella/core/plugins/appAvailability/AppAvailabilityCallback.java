package majestella.core.plugins.appAvailability;

public interface AppAvailabilityCallback {

  void onSuccess(boolean isAvailable);  
    
}
