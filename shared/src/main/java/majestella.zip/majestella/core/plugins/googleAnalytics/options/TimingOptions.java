package majestella.core.plugins.googleAnalytics.options;

public class TimingOptions extends AnalyticsOptions {
    TimingOptions(final OptionsCallback<?> optionsCallback,
            final String UserTimingCategory,
            final String userTimingVariableName,
            final int userTimingTime) {
        super(optionsCallback);

        putText("timingCategory", UserTimingCategory);
        putText("timingVar", userTimingVariableName);
        putNumber("timingValue", userTimingTime);
    }

    /**
     * Optional.
     * </p>
     * <p>Specifies the user timing label.</p>
     * Default Value: None<br>
     * Example Value: <code>label</code>
     **/
    public TimingOptions userTimingLabel(final String userTimingLabel) {
        putText("timingLabel", userTimingLabel);
        return this;
    }
}
