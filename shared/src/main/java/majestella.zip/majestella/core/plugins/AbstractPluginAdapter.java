package majestella.core.plugins;

/**
 * All pluginAdapter must implement this interface.
 * @author Dr. Michael Gorski
 *
 */
public interface AbstractPluginAdapter {

}
