package majestella.core.plugins.actionSheet;

import majestella.core.plugins.AbstractPlugin;
import majestella.core.plugins.BPluginType;
import majestella.core.plugins.PluginAdapterHolder;

public class ActionSheetImpl extends AbstractPlugin<ActionSheetAdapter> implements ActionSheet {

  public ActionSheetImpl(PluginAdapterHolder pluginAdapterHolder) {
    super(pluginAdapterHolder, BPluginType.ACTION_SHEET);
  }

  @Override
  public void show(ActionSheetOptions options, ActionSheetCallback callback) {
    getAdapter().show(options, callback);
  }


  
  
}
