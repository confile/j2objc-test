package majestella.core.plugins.database.serviceCard;

import majestella.core.plugins.AbstractPluginAdapter;

public interface ServiceCardDataServiceAdapter extends AbstractPluginAdapter, ServiceCardDataService {

}
