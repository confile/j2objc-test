package majestella.core.plugins.database;


public interface DatabaseErrorCallback {

  void onFailure(String error);
  
}
