package majestella.core.plugins.deviceEvents;

public interface DeviceEventCallback {

  void onEvent();
  
}
