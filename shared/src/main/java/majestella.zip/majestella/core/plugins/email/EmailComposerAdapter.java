package majestella.core.plugins.email;

import majestella.core.plugins.AbstractPluginAdapter;

public interface EmailComposerAdapter extends AbstractPluginAdapter, EmailComposer {

}
