package majestella.core.plugins.database;

import java.util.List;

public interface ListCallback<T> extends DatabaseErrorCallback {

  void onSuccess(List<T> result);
  
}
