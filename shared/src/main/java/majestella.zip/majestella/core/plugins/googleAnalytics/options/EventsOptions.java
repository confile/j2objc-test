package majestella.core.plugins.googleAnalytics.options;

public class EventsOptions extends AnalyticsOptions {
    EventsOptions(final OptionsCallback<?> optionsCallback, final String eventCategory, final String eventAction) {
        super(optionsCallback);

        putText("eventCategory", eventCategory);
        putText("eventAction", eventAction);
    }

    /**
     * Optional.
     * </p>
     * <p>Specifies the event label.</p>
     * Default Value: None<br>
     * Example Value: <code>Label</code>
     **/
    public EventsOptions eventLabel(final String eventLabel) {
        putText("eventLabel", eventLabel);
        return this;
    }

    /**
     * Optional.
     * </p>
     * <p>Specifies the event value. Values must be non-negative.</p>
     * Default Value: None<br>
     * Example Value: <code>55</code>
     **/
    public EventsOptions eventValue(final int eventValue) {
        putNumber("eventValue", eventValue);
        return this;
    }
}
