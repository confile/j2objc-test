package majestella.core.plugins.appAvailability;

import majestella.core.plugins.AbstractPlugin;
import majestella.core.plugins.BPluginType;
import majestella.core.plugins.PluginAdapterHolder;

public class AppAvailabilityImpl extends AbstractPlugin<AppAvailabilityAdapter> implements AppAvailability {
  
  public AppAvailabilityImpl(PluginAdapterHolder pluginAdapterHolder) {
    super(pluginAdapterHolder, BPluginType.APP_AVAILABILITY);
  }

  @Override
  public void check(String appUrlSchema, AppAvailabilityCallback callback) {
    getAdapter().check(appUrlSchema, callback);
  }
  
  
  
}
