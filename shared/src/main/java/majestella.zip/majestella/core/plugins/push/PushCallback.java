package majestella.core.plugins.push;

public interface PushCallback {

  /**
   * If the devices registed successfully to the push server.
   * @param token the device push token
   */
  void onSuccess(String token);
  
  void onFailure(String error);
  
  /**
   * THis is called when a notification has been received and the app is running.
   * @param status a status message from the server for logging.
   */
  void onNotification(String status);
  
}
