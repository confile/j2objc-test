package majestella.core.plugins.notification;

import majestella.core.plugins.AbstractPluginAdapter;

public interface NotificationAdapter extends AbstractPluginAdapter, Notification {

}
