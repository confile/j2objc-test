package majestella.core.plugins.cookie;

import majestella.core.plugins.AbstractPluginAdapter;

public interface CookieAdapter extends AbstractPluginAdapter, Cookie {

}
