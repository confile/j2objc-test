package majestella.core.plugins.appAvailability;

public final class AppAvailabilityAppURLSchema {

  private AppAvailabilityAppURLSchema() {
  }
  
  public enum ShareApp {
    WHATS_APP("whatsApp"), FACEBOOK("facebook"), TWITTER("twitter"), INSTAGRAM("instagram"), 
    PINTEREST("Pinterest"), EMAIL("email"), OTHER("other");
    
    private final String name;
        
    ShareApp(String name) {
      this.name = name;
    }
    
    public String getLookupName() {
      return name;
    }   
  }

  
  private static final String TWITTER_IOS = "twitter://";
  private static final String TWITTER_ANDROID = "com.twitter.android";
  private static final String FACEBOOK_IOS = "fb://";
  private static final String FACEBOOK_ANDROID = "com.facebook.katana";
  private static final String WHATSAPP_IOS = "whatsapp://";
  private static final String WHATSAPP_ANDROID = "com.whatsapp";
  private static final String INSTAGRAM_IOS = "instagram://";
  private static final String INSTAGRAM_ANDROID = "com.instagram.android";
  private static final String PINTERST_IOS = "pinterest://";
  private static final String PINTERST_ANDROID = "com.pinterest";
  
  public static final String getIOSAppUrlSchema(ShareApp name) {
    switch (name) {
      case TWITTER: 
        return TWITTER_IOS;
      case FACEBOOK: 
        return FACEBOOK_IOS;
      case WHATS_APP: 
        return WHATSAPP_IOS;
      case INSTAGRAM:
        return INSTAGRAM_IOS;
      case PINTEREST:
        return PINTERST_IOS;
    }
    return "";
  }
  
  public static final String getAndroidAppUrlSchema(ShareApp name) {
    switch (name) {
      case TWITTER: 
        return TWITTER_ANDROID;
      case FACEBOOK: 
        return FACEBOOK_ANDROID;
      case WHATS_APP: 
        return WHATSAPP_ANDROID;
      case INSTAGRAM:
        return INSTAGRAM_ANDROID;
      case PINTEREST:
        return PINTERST_ANDROID;
    }
    return "";
  } 
    
  
  
}
