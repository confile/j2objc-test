package majestella.core.plugins.cookie;

import majestella.core.rest.dto.LoginResultDto;

public interface Cookie {

  void setLoggedInCookie(LoginResultDto result);

  String getLoggedInCookie();
  
  public void clear();
  
}
