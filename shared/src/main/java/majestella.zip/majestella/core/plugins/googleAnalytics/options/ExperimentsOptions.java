package majestella.core.plugins.googleAnalytics.options;

public class ExperimentsOptions extends AnalyticsOptions {
    ExperimentsOptions(final OptionsCallback<?> optionsCallback) {
        super(optionsCallback);
    }

    /**
     * Optional.
     * </p>
     * <p>This parameter specifies that this user has been exposed to an experiment with the given ID.
     * It should be sent in conjunction with the Experiment Variant parameter.</p>
     * Default Value: None<br>
     * Example Value: <code>Qp0gahJ3RAO3DJ18b0XoUQ</code>
     **/
    public ExperimentsOptions experimentId(final String experimentId) {
        putText("expId", experimentId);
        return this;
    }

    /**
     * Optional.
     * </p>
     * <p>This parameter specifies that this user has been exposed to a particular variation of an experiment.
     * It should be sent in conjunction with the Experiment ID parameter.</p>
     * Default Value: None<br>
     * Example Value: <code>1</code>
     **/
    public ExperimentsOptions experimentVariant(final String experimentVariant) {
        putText("expVar", experimentVariant);
        return this;
    }
}
