package majestella.core.plugins.inappbrowser;

import majestella.core.plugins.AbstractPlugin;
import majestella.core.plugins.BPluginType;
import majestella.core.plugins.PluginAdapterHolder;

public class InappbrowserImpl extends AbstractPlugin<InappbrowserAdapter> implements Inappbrowser {

  
  public InappbrowserImpl(PluginAdapterHolder pluginAdapterHolder) {
    super(pluginAdapterHolder, BPluginType.INAPPBROWSER);
  }
 
  
  @Override
  public void openWindow(String url) {
    getAdapter().openWindow(url);
  }
  
}
