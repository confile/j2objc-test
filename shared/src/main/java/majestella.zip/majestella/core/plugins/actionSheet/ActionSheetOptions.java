package majestella.core.plugins.actionSheet;

import com.google.common.base.Strings;

public final class ActionSheetOptions {

  private String title;
  private String[] buttonLabels;
  private String addCancelButtonWithLabel;
  private String addDestructiveButtonWithLabel;
  private boolean androidEnableCancelButton;
  private boolean winphoneEnableCancelButton;

  public ActionSheetOptions() {
  }

  public boolean hasTitle() {
    if (Strings.isNullOrEmpty(title)) {
      return false;
    }
    return true;
  }

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public void unsetTitle() {
    this.title = null;
  }

  public void addButtonLabels(String[] labels) {
    this.buttonLabels = labels;
  }
  
  public String[] getButtonLabels() {
    return buttonLabels;
  }

  public void addCancelButtonWithText(String text) {
    this.addCancelButtonWithLabel = text;
  }
  
  public String getCancelButtonWithText() {
    return addCancelButtonWithLabel;
  }
  
  public void addDestructiveButtonWithLabel(String text) {
    this.addDestructiveButtonWithLabel = text;
  }
  
  public String getDestructiveButtonWithLabel() {
    return addDestructiveButtonWithLabel;
  }

  public void androidEnableCancelButton(boolean value) {
    this.androidEnableCancelButton = value;
  }
  
  public boolean getAndroidEnableCancelButton() {
    return androidEnableCancelButton;
  }

  public void winphoneEnableCancelButton(boolean value) {
    this.winphoneEnableCancelButton = value;
  }

}
