package majestella.core.plugins.display;

import majestella.core.prototype.mvp.BBaseView;
import majestella.core.prototype.navigation.annimation.AnimationCompleteCallback;
import majestella.core.prototype.navigation.annimation.BAnimation;


/**
 * Handles the display. 
 * @author Dr. Michael Gorski
 *
 */
public interface DisplayRoot {

  
  void onNavigate(BBaseView oldView, BBaseView newView, BAnimation animation, AnimationCompleteCallback callback);
  
}
