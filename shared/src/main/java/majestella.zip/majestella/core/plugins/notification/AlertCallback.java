package majestella.core.plugins.notification;

public interface AlertCallback {

  public void onOkButtonClicked();
  
}
