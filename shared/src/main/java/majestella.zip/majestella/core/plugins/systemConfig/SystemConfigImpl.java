package majestella.core.plugins.systemConfig;

import javax.inject.Inject;

import majestella.core.plugins.AbstractPlugin;
import majestella.core.plugins.BPluginType;
import majestella.core.plugins.PluginAdapterHolder;

public class SystemConfigImpl extends AbstractPlugin<SystemConfigAdapter> implements SystemConfig {

  @Inject
  public SystemConfigImpl(PluginAdapterHolder pluginAdapterHolder) {
    super(pluginAdapterHolder, BPluginType.SYSTEM_CONFIG);
  }

  @Override
  public boolean isIOs() {
    return getAdapter().isIOs();
  }

  @Override
  public boolean isOnline() {
    return getAdapter().isOnline();
  }
  
}
