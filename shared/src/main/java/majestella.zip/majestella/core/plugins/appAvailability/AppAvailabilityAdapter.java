package majestella.core.plugins.appAvailability;

import majestella.core.plugins.AbstractPluginAdapter;

public interface AppAvailabilityAdapter extends AbstractPluginAdapter, AppAvailability {

}
