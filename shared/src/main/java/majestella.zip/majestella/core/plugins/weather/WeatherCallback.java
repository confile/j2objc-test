package majestella.core.plugins.weather;

public interface WeatherCallback {

	void onSucces(String temperature);
	
	void onFailure();
}
