package majestella.core.plugins.weather;

import majestella.core.plugins.AbstractPlugin;
import majestella.core.plugins.BPluginType;
import majestella.core.plugins.PluginAdapterHolder;

public class WeatherImpl extends AbstractPlugin<WeatherAdapter> implements Weather {
 
  public WeatherImpl(PluginAdapterHolder pluginAdapterHolder) {
    super(pluginAdapterHolder, BPluginType.WEATHER);
  }
  
  
  @Override
  public void getTemperature(double latitude, double longitude, WeatherCallback callback) {
    getAdapter().getTemperature(latitude, longitude, callback);
  }
  
}
