package majestella.core.plugins.notification;

public interface ConfirmCallback {
 
  /**
   * Callback to invoke with index of button pressed (1, 2, or 3) or when the dialog is dismissed without a button press (0)
   * The callback takes the argument buttonIndex (Number), which is the index of the pressed button. 
   * Note that the index uses one-based indexing, so the value is 1, 2, 3, etc.
   * @param button
   */
  public void onConfirm(int button);
}
