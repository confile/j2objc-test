package majestella.core.plugins.database.serviceCard;

import java.util.List;

import majestella.core.plugins.database.ListCallback;
import majestella.core.plugins.database.ScalarCallback;
import majestella.core.plugins.database.VoidCallback;
import majestella.core.rest.dto.ServiceCardDto;

public interface ServiceCardDataService {

  void initTable(VoidCallback callback);
  
  void dropTable(VoidCallback callback);
  
  void insertOrReplace(List<ServiceCardDto> serviceCardDtos, VoidCallback callback);
    
  void findAll(int offset, int limit, ListCallback<ServiceCardDto> callback);
  
  void deleteAllById(List<String> deleteIds, VoidCallback callback);
   
  void countAll(ScalarCallback<Integer> result);
  
}
