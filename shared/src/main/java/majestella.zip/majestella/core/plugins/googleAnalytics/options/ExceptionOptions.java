package majestella.core.plugins.googleAnalytics.options;

public class ExceptionOptions extends AnalyticsOptions {
    ExceptionOptions(final OptionsCallback<?> optionsCallback) {
        super(optionsCallback);
    }

    /**
     * Optional.
     * </p>
     * <p>Specifies the description of an exception.</p>
     * Default Value: None<br>
     * Example Value: <code>DatabaseError</code>
     **/
    public ExceptionOptions exceptionDescription(final String exceptionDescription) {
        putText("exDescription", exceptionDescription);
        return this;
    }

    /**
     * Optional.
     * </p>
     * <p>Specifies whether the exception was fatal.</p>
     * Default Value: true<br>
     * Example Value: <code>true</code>
     **/
    public ExceptionOptions isExceptionFatal(final boolean isExceptionFatal) {
        putBoolean("exFatal", isExceptionFatal);
        return this;
    }
}
