package majestella.core.plugins;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;

public class PluginAdapterHolder {
  
  private Map<BPluginType, AbstractPluginAdapter> pluginAdapters = new HashMap<BPluginType, AbstractPluginAdapter>();
  
  @Inject
  public PluginAdapterHolder() {
  }
  
  public void addPlugin(BPluginType type, AbstractPluginAdapter adapter) {
    pluginAdapters.put(type, adapter);
  }
  
  public AbstractPluginAdapter get(BPluginType type) {
    AbstractPluginAdapter adapter = pluginAdapters.get(type);
    if (adapter == null) {   
      throw new IllegalStateException("PluginAdapterHolder type: "+type+" is unknown");
    }
    return adapter;
  }
  
}
