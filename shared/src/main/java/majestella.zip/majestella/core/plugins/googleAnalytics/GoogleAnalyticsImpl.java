package majestella.core.plugins.googleAnalytics;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import majestella.core.bootstrap.ParameterConfig;
import majestella.core.plugins.AbstractPlugin;
import majestella.core.plugins.BPluginType;
import majestella.core.plugins.PluginAdapterHolder;
import majestella.core.plugins.googleAnalytics.client.JSONOptionsCallback;
import majestella.core.plugins.googleAnalytics.options.AnalyticsOptions;
import majestella.core.plugins.googleAnalytics.options.ContentOptions;
import majestella.core.plugins.googleAnalytics.options.CreateOptions;
import majestella.core.plugins.googleAnalytics.options.EventsOptions;
import majestella.core.plugins.googleAnalytics.options.ExceptionOptions;
import majestella.core.plugins.googleAnalytics.options.GeneralOptions;
import majestella.core.plugins.googleAnalytics.options.SocialOptions;
import majestella.core.plugins.googleAnalytics.options.TimingOptions;
import majestella.core.plugins.googleAnalytics.shared.AnalyticsPlugin;
import majestella.core.plugins.googleAnalytics.shared.HitType;
import majestella.core.prototype.json.JsonArray;
import majestella.core.prototype.json.JsonObject;

 

/**
 * Source: https://github.com/ArcBees/universal-analytics
 * @author Dr. Michael Gorski
 *
 */
public class GoogleAnalyticsImpl extends AbstractPlugin<GoogleAnalyticsAdapter> implements GoogleAnalytics {

  private final Map<String, Double> timingEvents = new HashMap<>();
  private final String userAccount;
  
  public GoogleAnalyticsImpl(PluginAdapterHolder pluginAdapterHolder) {
    super(pluginAdapterHolder, BPluginType.GOOGLE_ANALYTICS);
    userAccount = ParameterConfig.GOOGLE_ANALYTICS_ACCOUNT;
    
//    boolean autoCreate = true; // TODO evt. löschen
//    boolean trackUncaughtExceptions = false;
//    boolean trackInitialPageView = true;
  
//    init();
//
//    if (autoCreate) {
//        create().go();
//        if (trackInitialPageView) {
//          sendPageView().go();
//        }
//    }
  }
  
  @Override
  public void initialize() {
    init();
    create().go();
  }

  
  @Override
  public void trackPageview(String pageName) {
    getAdapter().trackPageView(pageName);
  }
  
  
  @Override
  public void trackEvent(String category, String action, String label, int value) {
    Logger logger = Logger.getLogger("test");
    logger.info("GoogleAnalyticsImpl - trackEvent(): "+ParameterConfig.GOOGLE_ANALYTICS_ACCOUNT+" category: "+category+" action: "+action+" label: "+label);
    getAdapter().trackEvent(category, action, label, value);
  }
  
  @Override
  public void trackEvent(String category, String action) {
    trackEvent(category, action, null, 0);
  }
  
  // -------------------
  // Universal Analytics
  // -------------------
  

  @Override
  public CreateOptions create() {
    return create(userAccount);
  }

  @Override
  public TimingOptions endTimingEvent(final String timingCategory, final String timingVariableName) {
    return endTimingEvent(null, timingCategory, timingVariableName);
  }

  protected String getTimingKey(final String timingCategory, final String timingVariableName) {
    return timingCategory + ":" + timingVariableName;
  }

  @Override
  public AnalyticsOptions send(final HitType hitType) {
    return send(null, hitType);
  }

  @Override
  public EventsOptions sendEvent(final String category, final String action) {
    return sendEvent(null, category, action);
  }

  @Override
  public EventsOptions sendEvent(final String trackerName, final String category, final String action) {
    return send(trackerName, HitType.EVENT).eventsOptions(category, action);
  }

  @Override
  public ExceptionOptions sendException() {
    return sendException(null);
  }

  @Override
  public ExceptionOptions sendException(final String trackerName) {
    return send(trackerName, HitType.EXCEPTION).exceptionOptions();
  }

  @Override
  public ContentOptions sendPageView() {
    return sendPageView(null);
  }

  @Override
  public ContentOptions sendPageView(final String trackerName) {
    return send(trackerName, HitType.PAGE_VIEW).contentOptions();
  }

  @Override
  public SocialOptions sendSocial(final String socialNetwork, final String socialAction, final String socialTarget) {
    return sendSocial(null, socialNetwork, socialAction, socialTarget);
  }

  @Override
  public SocialOptions sendSocial(final String trackerName, final String socialNetwork, final String socialAction,
      final String socialTarget) {
    return send(trackerName, HitType.SOCIAL).socialOptions(socialNetwork, socialAction, socialTarget);
  }

  @Override
  public TimingOptions sendTiming(final String timingCategory, final String timingVar, final int timingValue) {
    return sendTiming(null, timingCategory, timingVar, timingValue);
  }

  @Override
  public TimingOptions sendTiming(final String trackerName, final String timingCategory, final String timingVar,
      final int timingValue) {
    return send(trackerName, HitType.TIMING).timingOptions(timingCategory, timingVar, timingValue);
  }
  
  ////
  
  private void call(final Object... params) {
    final JsonArray aryParams = new JsonArray();
    for (final Object p : params) {
      aryParams.put(aryParams.length(), p);
    }
    nativeCall(aryParams);
  }
  
  
  private void nativeCall(final JsonArray params) {
    getAdapter().nativeCall(params);
  }
  
  
  @Override
  public CreateOptions create(final String userAccount) {
    return new AnalyticsOptions(new JSONOptionsCallback(getAdapter()) {

      @Override
      public void onCallback(final JsonObject options) {
        call("create", userAccount, options);
        setGlobalSettings().forceSsl(true).go();
      }
    }).createOptions();
  }
  
  
  @Override
  public void enablePlugin(AnalyticsPlugin plugin) {
    if (plugin.getJsName() != null) {
      call("require", plugin.getFieldName(), plugin.getJsName());
    } else {
      call("require", plugin.getFieldName());
    }
  }
  
 

  @Override
  public TimingOptions endTimingEvent(final String trackerName, final String timingCategory,
          final String timingVariableName) {
      final String key = getTimingKey(timingCategory, timingVariableName);
      if (timingEvents.containsKey(key)) {
          return sendTiming(trackerName, timingCategory, timingVariableName,
                  (int) (System.currentTimeMillis() - timingEvents.remove(key)));
      }
      return new AnalyticsOptions(new JSONOptionsCallback(getAdapter()) {

          @Override
          public void onCallback(final JsonObject options) {
              //Do nothing a timing event was ended before it was started.  This is here just to stop a crash.
          }
      }).timingOptions(timingCategory, timingVariableName, 0);
  }
  
  
  private void init() {
    getAdapter().initialize(userAccount);
  }
  

  @Override
  public AnalyticsOptions send(final String trackerName, final HitType hitType) {
      return new AnalyticsOptions(new JSONOptionsCallback(getAdapter()) {

          @Override
          public void onCallback(final JsonObject options) {
            call(trackerName == null ? "send" : trackerName + ".send",
                hitType.getFieldName(), options);           
          }
      });
  }
  
  @Override
  public GeneralOptions setGlobalSettings() {
      return new AnalyticsOptions(new JSONOptionsCallback(getAdapter()) {

          @Override
          public void onCallback(final JsonObject options) {
            call("set", options); 
          }

      }).generalOptions();
  }

  @Override
  public void startTimingEvent(final String timingCategory, final String timingVariableName) {
    timingEvents.put(getTimingKey(timingCategory, timingVariableName), (double)System.currentTimeMillis());
  }
  

}
