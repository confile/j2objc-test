package majestella.core.plugins.appInfo;


public interface AppInfo {

//	public enum AppInfoKeyType {
//		STRING, INT, DOUBLE;
//	}
	
	String getAppVersion();

	String getBuildNumber();

	String getPlatform();

	String getModel();

	String getOSVersion();

	String getLocale();

	void setUserDefaultString(String key, String value);
	
	String getUserDefaultString(String key);
	
	void setUserDefaultDouble(String key, double value);
	
	double getUserDefaultDouble(String key);
	
	void setUserDefaultBoolean(String key, boolean value);
	
	boolean getUserDefaultBoolean(String key);
	
	boolean hasUserDefault(String key);

	int getClientWidth();
	
	int getClientHeight();
	
	double getPixelRatio();
}
