package majestella.core.plugins.notification;

import javax.inject.Inject;

import majestella.core.plugins.AbstractPlugin;
import majestella.core.plugins.BPluginType;
import majestella.core.plugins.PluginAdapterHolder;

public class NotificationImpl extends AbstractPlugin<NotificationAdapter> implements Notification {

  @Inject
  public NotificationImpl(PluginAdapterHolder pluginAdapterHolder) {
    super(pluginAdapterHolder, BPluginType.NOTIFICATION);
  }
  
  
  @Override
  public void alert(String message, AlertCallback callback, String title, String buttonName) {
    getAdapter().alert(message, callback, title, buttonName);
  }
  
  
  @Override
  public void confirm(String message, ConfirmCallback callback, String title, String[] buttonLabels) {
    getAdapter().confirm(message, callback, title, buttonLabels);
  }

}
