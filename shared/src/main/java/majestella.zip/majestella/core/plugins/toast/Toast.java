package majestella.core.plugins.toast;


/**
 * This class contains data for a toast message that is shown to the user on success or failure.
 * @author Dr.Michael Gorski
 *
 */
public class Toast {
    private final String message;
    private final ToastStyle style;
    private final ToastCloseDelay closeDelay;

    /**
     * Create a toast message.
     * @param message the message text that should be displayed
     * @param style the style that should be used
     */
    public Toast(String message, ToastStyle style) {
        this(message, style, ToastCloseDelay.DEFAULT);
    }

    
    /**
     * Create a toast message.
     * @param message the message text that should be displayed
     * @param style the style that should be used
     * @param closeDelay if the message should be closed after a while or stay open
     */
    public Toast(String message,
                   ToastStyle style,
                   ToastCloseDelay closeDelay) {
        this.message = message;
        this.style = style;
        this.closeDelay = closeDelay;
    }

    public ToastStyle getStyle() {
        return style;
    }
    
    public String getMessage() {
        return message;
    }

    public ToastCloseDelay getCloseDelay() {
        return closeDelay;
    }
  
}
