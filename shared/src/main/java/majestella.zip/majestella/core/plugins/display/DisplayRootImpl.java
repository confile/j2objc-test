package majestella.core.plugins.display;

import majestella.core.plugins.AbstractPlugin;
import majestella.core.plugins.BPluginType;
import majestella.core.plugins.PluginAdapterHolder;
import majestella.core.prototype.mvp.BBaseView;
import majestella.core.prototype.navigation.annimation.AnimationCompleteCallback;
import majestella.core.prototype.navigation.annimation.BAnimation;

public class DisplayRootImpl extends AbstractPlugin<DisplayRootAdapter> implements DisplayRoot {

  public DisplayRootImpl(PluginAdapterHolder pluginAdapterHolder) {
    super(pluginAdapterHolder, BPluginType.DISPLAY_ROOT);
  }

  @Override
  public void onNavigate(BBaseView oldView, BBaseView newView, BAnimation animation, AnimationCompleteCallback callback) {
    getAdapter().onNavigate(oldView, newView, animation, callback);
  }


  
}
