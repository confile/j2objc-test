package majestella.core.plugins.actionSheet;

public interface ActionSheetCallback {

  /**
   * like other Cordova plugins (prompt, confirm) the buttonIndex is 1-based (first button is index 1)
   * @param index
   */
  void onButtonTap(int index);  
  
}
