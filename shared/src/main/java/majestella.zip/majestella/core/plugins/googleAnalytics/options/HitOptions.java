package majestella.core.plugins.googleAnalytics.options;

public class HitOptions extends AnalyticsOptions {
    HitOptions(final OptionsCallback<?> optionsCallback) {
        super(optionsCallback);
    }

    /**
     * <strong>Required for all hit types.</strong>
     * </p>
     * <p>The type of hit. Must be one of &#39;pageview&#39;,
     * &#39;screenview&#39;, &#39;event&#39;, &#39;transaction&#39;,
     * &#39;item&#39;, &#39;social&#39;, &#39;exception&#39;,
     * &#39;timing&#39;.</p>
     * Default Value: None<br>
     * Example Value: <code>pageview</code>
     **/
    public HitOptions hitType(final String hitType) {
        putText("hitType", hitType);
        return this;
    }

    /**
     * Optional.
     * </p>
     * <p>Specifies that a hit be considered non-interactive.</p>
     * Default Value: None<br>
     * Example Value: <code>true</code>
     **/
    public HitOptions nonInteractionHit(final boolean nonInteractionHit) {
        putBoolean("nonInteraction", nonInteractionHit);
        return this;
    }
}
