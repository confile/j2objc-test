package majestella.core.plugins.googleAnalytics.options;

public class ApptrackingOptions extends AnalyticsOptions {
    ApptrackingOptions(final OptionsCallback<?> optionsCallback) {
        super(optionsCallback);
    }

    /**
     * Optional.
     * </p>
     * <p>Application identifier.</p>
     * Default Value: None<br>
     * Example Value: <code>com.company.app</code>
     **/
    public ApptrackingOptions applicationId(final String applicationId) {
        putText("appId", applicationId);
        return this;
    }

    /**
     * Optional.
     * </p>
     * <p>Application installer identifier.</p>
     * Default Value: None<br>
     * Example Value: <code>com.platform.vending</code>
     **/
    public ApptrackingOptions applicationInstallerId(final String applicationInstallerId) {
        putText("appInstallerId", applicationInstallerId);
        return this;
    }

    /**
     * Optional.
     * </p>
     * <p>Specifies the application name.</p>
     * Default Value: None<br>
     * Example Value: <code>My App</code>
     **/
    public ApptrackingOptions applicationName(final String applicationName) {
        putText("appName", applicationName);
        return this;
    }

    /**
     * Optional.
     * </p>
     * <p>Specifies the application version.</p>
     * Default Value: None<br>
     * Example Value: <code>1.2</code>
     **/
    public ApptrackingOptions applicationVersion(final String applicationVersion) {
        putText("appVersion", applicationVersion);
        return this;
    }
}
