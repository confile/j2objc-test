package majestella.core.plugins.push;

import majestella.core.plugins.AbstractPlugin;
import majestella.core.plugins.BPluginType;
import majestella.core.plugins.PluginAdapterHolder;

public class PushImpl extends AbstractPlugin<PushAdapter> implements Push {

  
  public PushImpl(PluginAdapterHolder pluginAdapterHolder) {
    super(pluginAdapterHolder, BPluginType.PUSH);
  }

  @Override
  public void register(String senderId, PushCallback callback) {
    getAdapter().register(senderId, callback);
  }
  
 
  
  
}
