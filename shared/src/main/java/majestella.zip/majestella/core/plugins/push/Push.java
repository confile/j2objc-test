package majestella.core.plugins.push;

public interface Push {

  /**
   * Call this to register for push notifications. Content of [options] 
   * depends on whether we are working with APNS (iOS) or GCM (Android)
   * @param senderId This is the Google project ID you need to obtain by registering your application for GCM
   * http://developer.android.com/google/gcm/gs.html
   * @param callback
   */
  public void register(String senderId, PushCallback callback);

  
}
