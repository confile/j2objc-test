package majestella.core.plugins.notification;



/**
 * https://github.com/apache/cordova-plugin-dialogs
 * @author Dr. Michael Gorski
 *
 */
public interface Notification {

  public void alert(String message, AlertCallback callback, String title, String buttonName);
  
  void confirm(String message, ConfirmCallback callback, String title, String[] buttonLabels);

}
