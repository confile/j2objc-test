package majestella.core.plugins.spinner;

/**
 * See: https://github.com/pbernasconi/cordova-progressIndicator
 * @author Dr. Michael Gorski
 *
 */
public interface Spinner {

  void show(String message);

  void show();
  
  void hide();
  
  // progress indicator
  
  void resetProgess();
  
  void setProgressVisible(boolean visible);
  
  void setProgressValue(int value, String text);
   
}
