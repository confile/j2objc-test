package majestella.core.plugins.actionSheet;

import majestella.core.plugins.AbstractPluginAdapter;

public interface ActionSheetAdapter extends AbstractPluginAdapter, ActionSheet {

}
