package majestella.core.plugins.appInfo;

public class AppInfoUserDefaultKey {

  public static final String tourLikeButtonShown = "tourLikeButtonShown";
  public static final String tourNopeButtonShown = "tourNopeButtonShown";
  public static final String tourLikeSwipeShown = "tourLikeSwipeShown";
  public static final String tourNopeSwipeShown = "tourNopeSwipeShown";
  public static final String lastName = "lastName";
  public static final String roomNumber = "roomNumber";
  public static final String departureDateString = "departureDateString";
  public static final String lastLocationId = "lastLocationId";
  public static final String lastLocationType = "lastLocationType";
  
  
}
