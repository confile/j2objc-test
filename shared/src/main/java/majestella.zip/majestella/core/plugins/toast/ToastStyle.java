package majestella.core.plugins.toast;

public enum ToastStyle {
  SUCCESS,
  ERROR;
}
