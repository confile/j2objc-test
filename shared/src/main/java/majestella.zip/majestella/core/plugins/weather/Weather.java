package majestella.core.plugins.weather;


public interface Weather {

  void getTemperature(double latitude, double longitude, WeatherCallback callback);
  
}
