package majestella.core.plugins.googleAnalytics.shared;

public enum HitType {
  PAGE_VIEW("pageview"),
  SCREEN_VIEW("screenview"),
  EVENT("event"),
  TRANSACTION("transaction"),
  ITEM("item"),
  SOCIAL("social"),
  EXCEPTION("exception"),
  TIMING("timing");

  private final String fieldName;

  HitType(final String fieldName) {
      this.fieldName = fieldName;
  }

  public String getFieldName() {
      return fieldName;
  }
}