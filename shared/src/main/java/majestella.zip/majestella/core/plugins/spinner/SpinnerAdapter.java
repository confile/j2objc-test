package majestella.core.plugins.spinner;

import majestella.core.plugins.AbstractPluginAdapter;

public interface SpinnerAdapter extends AbstractPluginAdapter, Spinner {

}
