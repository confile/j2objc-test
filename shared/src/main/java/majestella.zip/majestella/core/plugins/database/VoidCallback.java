package majestella.core.plugins.database;

public interface VoidCallback extends DatabaseErrorCallback {

  void onSuccess();
  
}
