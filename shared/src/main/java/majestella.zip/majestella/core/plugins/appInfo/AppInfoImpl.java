package majestella.core.plugins.appInfo;

import majestella.core.plugins.AbstractPlugin;
import majestella.core.plugins.BPluginType;
import majestella.core.plugins.PluginAdapterHolder;

public class AppInfoImpl extends AbstractPlugin<AppInfoAdapter> implements
		AppInfo {

	public AppInfoImpl(PluginAdapterHolder pluginAdapterHolder) {
		super(pluginAdapterHolder, BPluginType.APP_INFO);
	}

	@Override
	public String getAppVersion() {
		return getAdapter().getAppVersion();
	}

	@Override
	public String getBuildNumber() {
		return getAdapter().getBuildNumber();
	}

	@Override
	public String getPlatform() {
		return getAdapter().getPlatform();
	}

	@Override
	public String getModel() {
		return getAdapter().getModel();
	}

	@Override
	public String getOSVersion() {
		return getAdapter().getOSVersion();
	}

	@Override
	public String getLocale() {
		return getAdapter().getLocale();
	}


	@Override
	public void setUserDefaultString(String key, String value) {
	  getAdapter().setUserDefaultString(key, value);
	}
	
	@Override
	public String getUserDefaultString(String key) {
		return getAdapter().getUserDefaultString(key);
	}
	
	@Override
	public void setUserDefaultDouble(String key, double value) {
	  getAdapter().setUserDefaultDouble(key, value);
	}

	@Override
	public double getUserDefaultDouble(String key) {
		return getAdapter().getUserDefaultDouble(key);
	}
	
	@Override
	public void setUserDefaultBoolean(String key, boolean value) {
	  getAdapter().setUserDefaultBoolean(key, value);
	}

	@Override
	public boolean getUserDefaultBoolean(String key) {
		return getAdapter().getUserDefaultBoolean(key);
	}

	@Override
	public boolean hasUserDefault(String key) {
		return getAdapter().hasUserDefault(key);
	}

	@Override
	public int getClientWidth() {
		return getAdapter().getClientWidth();
	}

	@Override
	public int getClientHeight() {
		return getAdapter().getClientHeight();
	}
	
	@Override
	public double getPixelRatio() {
		return getAdapter().getPixelRatio();
	}

}
