package majestella.core.plugins.toast;

import majestella.core.plugins.AbstractPlugin;
import majestella.core.plugins.BPluginType;
import majestella.core.plugins.PluginAdapterHolder;

public class ToastPluginImpl extends AbstractPlugin<ToastPluginAdapter> implements ToastPlugin {

  public ToastPluginImpl(PluginAdapterHolder pluginAdapterHolder) {
    super(pluginAdapterHolder, BPluginType.TOAST); 
  }

  
  @Override
  public void createToast(Toast toast) {
    getAdapter().createToast(toast);
  }
  

}
