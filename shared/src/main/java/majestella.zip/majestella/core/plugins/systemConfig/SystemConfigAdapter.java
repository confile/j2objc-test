package majestella.core.plugins.systemConfig;

import majestella.core.plugins.AbstractPluginAdapter;

public interface SystemConfigAdapter extends AbstractPluginAdapter, SystemConfig {

}
