package majestella.core.plugins.database.app;

import majestella.core.plugins.AbstractPlugin;
import majestella.core.plugins.BPluginType;
import majestella.core.plugins.PluginAdapterHolder;
import majestella.core.plugins.database.ListCallback;
import majestella.core.plugins.database.VoidCallback;

public class AppDataServiceImpl extends AbstractPlugin<AppDataServiceAdapter> implements AppDataService {

  public AppDataServiceImpl(PluginAdapterHolder pluginAdapterHolder) {
    super(pluginAdapterHolder, BPluginType.APP_DATABASE);
  }

  @Override
  public void insertOrReplace(String version, VoidCallback callback) {
    getAdapter().insertOrReplace(version, callback);
  }

  @Override
  public void initTable(VoidCallback callback) {
    getAdapter().initTable(callback);
  }

  @Override
  public void get(ListCallback<String> callback) {
    getAdapter().get(callback);
  }

  @Override
  public void dropTable(VoidCallback callback) {
    getAdapter().dropTable(callback);
  }

}
