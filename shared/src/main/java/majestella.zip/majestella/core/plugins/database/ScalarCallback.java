package majestella.core.plugins.database;

public interface ScalarCallback<T> extends DatabaseErrorCallback {

  void onSuccess(T result);
  
}
