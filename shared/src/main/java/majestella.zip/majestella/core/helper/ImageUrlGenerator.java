package majestella.core.helper;

import majestella.core.dagger.ApplicationComponent;
import majestella.core.dagger.ComponentHolder;
import majestella.core.rest.dto.DeviceDto;

/**
 * Create a URL to request an image from a given url by 
 * appending device specific parameters.
 * @author Dr. Michael Gorski
 *
 */
public final class ImageUrlGenerator {

 
  private static DeviceDto deviceDto;
  
  private ImageUrlGenerator() {
  }
  
  public static String getUrl(String url) {
    if (deviceDto == null) {
      ApplicationComponent component = ComponentHolder.get();
      deviceDto = component.getDeviceDto();
    }
    
    String newUrl = url;
    if (newUrl.contains("?")) {
      newUrl += "&";
    }
    else {
      newUrl += "?";
    }    
    newUrl += "screenW="+deviceDto.getClientWidth()+"&screenH="+deviceDto.getClientHeight();    
    return newUrl;
  }
  
}
