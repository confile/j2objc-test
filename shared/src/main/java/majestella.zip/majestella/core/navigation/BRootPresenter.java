package majestella.core.navigation;


public interface BRootPresenter {

  void init();
  
}
