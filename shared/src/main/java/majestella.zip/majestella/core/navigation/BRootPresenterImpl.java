package majestella.core.navigation;

import java.util.logging.Logger;

import javax.inject.Inject;

import majestella.core.plugins.display.DisplayRoot;
import majestella.core.prototype.BaseParameterConfig;
import majestella.core.prototype.eventBus.BEventBus;
import majestella.core.prototype.mvp.BAbstractPresenter;
import majestella.core.prototype.mvp.BBaseView;
import majestella.core.prototype.navigation.BHistoryStack;
import majestella.core.prototype.navigation.BPlaceManager;
import majestella.core.prototype.navigation.annimation.AnimationCompleteCallback;
import majestella.core.prototype.navigation.annimation.RevealAnimatableDisplayRootContentEvent;
import majestella.core.prototype.navigation.annimation.RevealAnimatableDisplayRootContentEvent.RevealAnimatableDisplayRootContentHandler;
import dagger.Lazy;

public class BRootPresenterImpl implements BRootPresenter, RevealAnimatableDisplayRootContentHandler {

  private boolean isInitialized = false;
  private BAbstractPresenter presenterVisible;
  
  private final BEventBus eventBus;
  private final BHistoryStack historyStack;
  private final BPlaceManager placeManager;
  private final Lazy<DisplayRoot> lazyDisplayRoot;
  
  protected Logger logger;
    
  @Inject
  public BRootPresenterImpl(BEventBus eventBus, BHistoryStack historyStack, BPlaceManager placeManager, 
      Lazy<DisplayRoot> lazyDisplayRoot) {
    this.eventBus = eventBus;
    logger = Logger.getLogger(BaseParameterConfig.LOGGER_MAJESTELLA_NAME);
    this.historyStack = historyStack;   
    this.placeManager = placeManager;
    this.lazyDisplayRoot = lazyDisplayRoot;
    
    eventBus.addHandler(RevealAnimatableDisplayRootContentEvent.getType(), this);
  }
  
  
  @Override
  public void init() {
    if (!isInitialized) {
      isInitialized = true;
      createBase();
    }
  }
  
  /**
   * Use this method to create the basic config
   */
  protected void createBase() {
  }
  
  private void informCurrentPresenterHide() {
    logger.info("BRootPresenterImpl - informCurrentPresenterHide(): presenterVisible: "+presenterVisible);
    if (presenterVisible != null) {
      presenterVisible.setHide();
    }
  }
  
  private void setCurrentPresenter(BAbstractPresenter presenter) {
    if (presenter == null) {
      throw new NullPointerException("BRootPresenterImpl - setCurrentPresenter presenter cannot be null");
    }
    logger.info("BRootPresenterImpl - setCurrentPresenter()");
    presenterVisible = presenter;
    presenterVisible.setReveal();
  }
  
  protected void updatePresenterEvents(BAbstractPresenter presenter) {
    informCurrentPresenterHide();
    setCurrentPresenter(presenter);
    placeManager.navigationFinished();
  }
  
  protected void onDisplayEvent(RevealAnimatableDisplayRootContentEvent event) { 
    logger.info("BRootPresenterImpl - onDisplayEvent()");
    
    BBaseView oldView = null;
    if (presenterVisible != null) {
      oldView = presenterVisible.getView();
    }
    
    final BAbstractPresenter newPresenter = event.getContent();
    
    lazyDisplayRoot.get().onNavigate(oldView, newPresenter.getView(), event.getAnimation(), new AnimationCompleteCallback() {
      
      @Override
      public void onAnimationComplete() {
        updatePresenterEvents(newPresenter);
      }
    });
    
  }
  
  
  // ---------------------------------------------
  // Events
  // ---------------------------------------------

    
  /**
   * Do not use or override this method use onDisplayEvent() instead.
   */
  @Override
  public void onRevealAnimatableDisplayRootContent(RevealAnimatableDisplayRootContentEvent event) {
    logger.info("BRootPresenterImpl - onRevealAnimatableDisplayRootContent()");
    
    // check if it is a backward navigation
    if (historyStack.isBackwardNavigationPending()) {
      logger.info("BRootPresenterImpl - onRevealAnimatableDisplayRootContent(): backward navigation");
      
      // change Animation direction
      event.getAnimation().changeDirection();      
    }
    
    onDisplayEvent(event);
  }

}
