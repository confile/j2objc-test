package majestella.core.network;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.util.Map;
import java.util.logging.Logger;

import majestella.core.bootstrap.ParameterConfig;



/**
 * Source: 
 * http://stackoverflow.com/questions/2793150/using-java-net-urlconnection-to-fire-and-handle-http-requests
 * http://stackoverflow.com/questions/4205980/java-sending-http-parameters-via-post-method-easily
 * http://stackoverflow.com/questions/21404252/post-request-send-json-data-java-httpurlconnection
 * http://stackoverflow.com/questions/10500775/parse-json-from-httpurlconnection-object
 * http://stackoverflow.com/questions/14185338/java-httpurlconnection-returns-json
 * 
 * Uploading Files: http://stackoverflow.com/questions/2793150/using-java-net-urlconnection-to-fire-and-handle-http-requests
 * 
 * @author Dr. Michael Gorski
 *
 */
public class ConnectionImpl implements Connection {

  private static final String CHARSET = "UTF-8";
  
  private final Logger logger;
  
  public ConnectionImpl() {
    logger = Logger.getLogger(ParameterConfig.LOGGER_MAJESTELLA_NAME);
  }
  
 
  @Override
  public void request(HTTPMethod method, String url, Map<String, String> queryParams, ConnectionCallback callback) {
    request(method, url, queryParams, "", callback); 
  }

  @Override
  public void request(HTTPMethod method, String url, Map<String, String> queryParams, String bodyString,
      final ConnectionCallback callback) {
        
    String queryString = "";
    try {
      queryString = getQueryString(queryParams);
    }
    catch(UnsupportedEncodingException e) {
      logger.severe("ConnectionImpl - request(): UnsupportedEncodingException e: "+e.getMessage());
    }    
    URL urlObj = null;
    try {
      urlObj = new URL(url + "?" + queryString);
    } catch (MalformedURLException e) {
      logger.severe("ConnectionImpl - request(): MalformedURLException e: "+e.getMessage());
      e.printStackTrace();
    }
        
    HttpURLConnection connection = null;
    try {
      connection = (HttpURLConnection) urlObj.openConnection();
    } catch (IOException e) {
      logger.severe("ConnectionImpl - request(): IOException e: "+e.getMessage());
      e.printStackTrace();
    }
        
    connection.setDoInput(true);
    connection.setRequestProperty("Content-Type", "application/json; charset="+CHARSET);
    connection.setRequestProperty("Accept", "application/json");
    try {
      if (method == HTTPMethod.GET) {
        connection.setRequestMethod("GET");
      }
      else if (method == HTTPMethod.POST) {
        connection.setRequestMethod("POST");
        connection.setDoOutput(true); // Triggers POST.
      }
      else if (method == HTTPMethod.DELETE) {
        connection.setRequestMethod("DELETE");
      }
      else if (method == HTTPMethod.PUT) {
        connection.setRequestMethod("PUT");
      }
      else {
        throw new IllegalStateException("request method undefined: "+method);
      }
    } catch (ProtocolException e) {
      logger.severe("ConnectionImpl - request(): ProtocolException e: "+e.getMessage());
      e.printStackTrace();
    }
    
    if (bodyString.length() > 0) {
      byte[] postData = bodyString.getBytes(Charset.forName(CHARSET));
      int postDataLength = postData.length;
      
      connection.setRequestProperty( "Content-Length", Integer.toString( postDataLength ));
      try(DataOutputStream wr = new DataOutputStream(connection.getOutputStream())) {
        wr.write(postData);
      } catch (IOException e) {
        logger.severe("ConnectionImpl - request(): IOException e: "+e.getMessage());
        e.printStackTrace();
      }
    }
    else {
      try {
        connection.connect(); 
      } catch (IOException e) {
        logger.severe("ConnectionImpl - request(): IOException e: "+e.getMessage());
        e.printStackTrace();
      }
    }
        
    try {
      int statusCode = connection.getResponseCode();
      
      switch (statusCode) {
        case 200:
        case 201:
            BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line+"\n");
            }
            br.close();
            String jsonString = sb.toString();
            callback.onResponse(statusCode, jsonString);
      }
    } catch (IOException e) {
      logger.severe("ConnectionImpl - request(): IOException e: "+e.getMessage());
      e.printStackTrace();
    }
    finally {
      if (connection != null) {
        connection.disconnect();
      }
    }
    
    
  }


  
  private String getQueryString(Map<String, String> params) throws UnsupportedEncodingException {
    String result = "";
    for(Map.Entry<String, String> entry : params.entrySet()) {
      result += entry.getKey()+"="+ URLEncoder.encode(entry.getValue() == null ? "" : entry.getValue(), CHARSET) + "&";
    }
    return result;
  }

  
  
}
