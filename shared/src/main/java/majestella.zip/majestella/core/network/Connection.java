package majestella.core.network;

import java.util.Map;

public interface Connection {

  public enum HTTPMethod {
    GET, POST, DELETE, PUT;
  }
  
  public interface ConnectionCallback {
    
    void onResponse(int statusCode, String data);
    
    void onError(Exception ex);
    
  }
  
  void request(HTTPMethod method, String url, Map<String, String> queryParams, ConnectionCallback callback);
  
  void request(HTTPMethod method, String url, Map<String, String> queryParams, String bodyString, ConnectionCallback callback);
    
}
