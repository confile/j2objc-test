package majestella.core.rest.dto;

import java.util.ArrayList;
import java.util.List;

import majestella.core.prototype.json.JsonArray;
import majestella.core.prototype.json.JsonObject;


public class RoomServiceCategoryDto extends BaseEntity {

  private static final long serialVersionUID = -1065090042734891828L;
  
  private String title;
  private List<RoomServiceItemDto> roomServiceItems = new ArrayList<>();


  public RoomServiceCategoryDto() {
  }

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  } 
  
  public List<RoomServiceItemDto> getRoomServiceItems() {
    return roomServiceItems;
  }

  public void setRoomServiceItems(List<RoomServiceItemDto> roomServiceItems) {
    this.roomServiceItems = roomServiceItems;
  }
    
  public static RoomServiceCategoryDto fromJsonObject(JsonObject jsonObject) {
    BaseEntity baseEntity = BaseEntity.fromJsonObject(jsonObject);
    RoomServiceCategoryDto dto = new RoomServiceCategoryDto();
    dto.id = baseEntity.getId();
    
    dto.setTitle(jsonObject.getString("title"));
    JsonArray jsonRoomServiceItems = jsonObject.getJsonArray("roomServiceItems");
    
    for (int i = 0; i < jsonRoomServiceItems.length(); i++) {
      JsonObject jso = jsonRoomServiceItems.getJsonObject(i);
      RoomServiceItemDto itemDto = RoomServiceItemDto.fromJsonObject(jso);
      dto.roomServiceItems.add(itemDto);
    }
    
    return dto;
  }








  
  
  
}
