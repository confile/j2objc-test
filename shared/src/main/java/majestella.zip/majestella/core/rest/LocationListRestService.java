package majestella.core.rest;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;

import majestella.core.network.Connection;
import majestella.core.network.Connection.ConnectionCallback;
import majestella.core.network.Connection.HTTPMethod;
import majestella.core.plugins.cookie.Cookie;
import majestella.core.prototype.json.JsonObject;
import majestella.core.prototype.mvp.proxy.BAsyncCallback;
import majestella.core.rest.dto.DeviceDto;
import majestella.core.rest.dto.GetResult;
import majestella.core.rest.dto.LocationListDto;
 

public class LocationListRestService extends AbstractRestService {

  public LocationListRestService(Connection connection, DeviceDto deviceDto, Cookie cookie) {
    super(connection, deviceDto, cookie);
    url += ResourcesPath.LOCATION_LIST;
  }

  public void get(double latitude, double longitude, int type, String objectId, 
        final BAsyncCallback<GetResult<LocationListDto>> callback) {
    logger.info("<<< LocationListRestService get()");
    
    Map<String, String> params = new HashMap<>();
    params.put(RestParameter.COOKIE, cookie.getLoggedInCookie());  
    params.put(RestParameter.LOCALE, deviceDto.getLocale());
    params.put(RestParameter.DEVICE_UUID, deviceDto.getUuid());
    
    params.put(RestParameter.LATITUDE, ""+latitude);
    params.put(RestParameter.LONGITUDE, ""+longitude);
    params.put(RestParameter.LOCATION_TYPE, ""+type);
    params.put(RestParameter.LOCATION_ID, ""+objectId);
    
     
    connection.request(HTTPMethod.GET, url, params, new ConnectionCallback() {

      @Override
      public void onResponse(int statusCode, String data) {
        logger.info(">>> LocationListRestService get(): statusCode: "+statusCode);
        if (statusCode == 200) {
          GetResult<LocationListDto> result = parseString(data);
          callback.onSuccess(result);
        } else {
          callback.onFailure(new Exception("Server responded with status code: " + statusCode));
        }
      }

      @Override
      public void onError(Exception ex) {
        logger.log(Level.SEVERE, "LocationListRestService - get(): onError(): " + ex.getMessage(), ex);
        callback.onFailure(ex);
      }
    });

  }
  
  
  GetResult<LocationListDto> parseString(String jsonString) {
    JsonObject jsonObj = new JsonObject(jsonString);
    jsonObj = jsonObj.getJsonObject("result");
    
    
    LocationListDto locationListDto = LocationListDto.fromJsonObject(jsonObj);
    GetResult<LocationListDto> result = new GetResult<>();
    result.setResult(locationListDto);
  
    return result;
  }
 

}
