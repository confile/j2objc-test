package majestella.core.rest;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;

import majestella.core.network.Connection;
import majestella.core.network.Connection.ConnectionCallback;
import majestella.core.network.Connection.HTTPMethod;
import majestella.core.plugins.cookie.Cookie;
import majestella.core.prototype.json.JsonObject;
import majestella.core.prototype.mvp.proxy.BAsyncCallback;
import majestella.core.rest.dto.DeviceDto;
import majestella.core.rest.dto.LoginResultDto;

public class SignupRestService extends AbstractRestService {

  public SignupRestService(Connection connection, DeviceDto deviceDto, Cookie cookie) {
    super(connection, deviceDto, cookie);
    url += ResourcesPath.SIGNUP;
  }

  public void signup(String firstName, String lastName, String email, String username, String gender, String password,
      String pushToken, String uuid, final BAsyncCallback<LoginResultDto> callback) {
    logger.info("<<< SignupRestService signup()");

    Map<String, String> params = new HashMap<>();
    params.put(RestParameter.FIRST_NAME, firstName);
    params.put(RestParameter.LAST_NAME, lastName);
    params.put(RestParameter.EMAIL, email);
    params.put(RestParameter.USERNAME, username);
    params.put(RestParameter.GENDER, gender);
    params.put(RestParameter.PASSWORD, password);
    params.put(RestParameter.LOCALE, deviceDto.getLocale());
    params.put(RestParameter.PUSH_TOKEN, pushToken);
    params.put(RestParameter.UUID, uuid);

    connection.request(HTTPMethod.POST, url, params, new ConnectionCallback() {

      @Override
      public void onResponse(int statusCode, String data) {
        logger.info(">>> SignupRestService signup(): statusCode: " + statusCode);
        if (statusCode == 200) {
          LoginResultDto result = parseString(data);
          callback.onSuccess(result);
        } else {
          callback.onFailure(new Exception("Server responded with status code: " + statusCode));
        }
      }

      @Override
      public void onError(Exception ex) {
        logger.log(Level.SEVERE, "SignupRestService - signup(): onError(): " + ex.getMessage(), ex);
        callback.onFailure(ex);
      }
    });
  }

  LoginResultDto parseString(String jsonString) {
    JsonObject jsonObj = new JsonObject(jsonString);
    LoginResultDto dto = LoginResultDto.fromJsonObject(jsonObj);
    
    return dto;
  }

}
