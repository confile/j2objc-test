package majestella.core.rest;

import java.util.logging.Logger;

import majestella.core.bootstrap.ParameterConfig;
import majestella.core.network.Connection;
import majestella.core.plugins.cookie.Cookie;
import majestella.core.rest.dto.DeviceDto;

public abstract class AbstractRestService {

  protected String url = ParameterConfig.getApiBaseUrl();
  protected final Connection connection;
  protected final DeviceDto deviceDto;
  protected final Cookie cookie;
  protected Logger logger;
  
  public AbstractRestService(Connection connection, DeviceDto deviceDto, Cookie cookie) {
    this.connection = connection;
    this.deviceDto = deviceDto;
    this.cookie = cookie;
    logger = Logger.getLogger(ParameterConfig.LOGGER_MAJESTELLA_NAME);
  }
  
 
  
}
