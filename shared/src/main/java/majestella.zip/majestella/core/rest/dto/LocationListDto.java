package majestella.core.rest.dto;
 
import java.util.ArrayList;
import java.util.List;

import majestella.core.prototype.json.JsonArray;
import majestella.core.prototype.json.JsonObject;

public class LocationListDto implements Dto {

  private static final long serialVersionUID = 7643123355372857839L;
 
  private List<LocationListItemDto> dtos;  
  private boolean directSelection;
  

  public LocationListDto() { 
	}
	

  public List<LocationListItemDto> getDtos() {
    return dtos;
  }

  public void setDtos(List<LocationListItemDto> dtos) {
    this.dtos = dtos;
  }
  
  /**
   * This is used when a certain location was requested.
   * @return
   */
  public boolean getDirectSelection() {
    return directSelection;
  }

  public void setDirectSelection(boolean directSelection) {
    this.directSelection = directSelection;
  }

  
  public static LocationListDto fromJsonObject(JsonObject jsonObject) {
    LocationListDto locationListDto = new LocationListDto();
    locationListDto.dtos = new ArrayList<>();
   
    JsonArray jsonLocationDtos = jsonObject.getJsonArray("dtos");
    for (int i=0; i < jsonLocationDtos.length(); i++) {
      LocationListItemDto locationListItemDto = LocationListItemDto.fromJsonObject(jsonLocationDtos.getJsonObject(i));
      locationListDto.dtos.add(locationListItemDto);
    }
    
    locationListDto.setDirectSelection(jsonObject.getBoolean("directSelection"));
    
    return locationListDto;
  }


















































	
	
}
