package majestella.core.rest.dto;

import java.util.Map;

import majestella.core.prototype.json.JsonObject;

 

public class StringMapDto implements Dto {

  private Map<String, Long> container;

  public StringMapDto(Map<String, Long> container) {
    this.setContainer(container);
  }
  
  public Map<String, Long> getContainer() {
    return container;
  }

  public void setContainer(Map<String, Long> container) {
    this.container = container;
  }
  
  
  /**
   * Converts this object into a JSON string.
   * @return
   */
  public String toJsonString() {
    String  result = "";
    JsonObject dto = new JsonObject();
    JsonObject jsonObj = new JsonObject();
    for(Map.Entry<String, Long> entry : container.entrySet()) {
      jsonObj.put(entry.getKey(), entry.getValue()); 
    }
    dto.put("container", jsonObj);
    result = dto.toString();
    return result;
  }
  
  
  
}
