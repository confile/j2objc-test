package majestella.core.rest.dto;
 
import majestella.core.prototype.json.JsonObject;

public class RoomServiceItemDto extends BaseEntity {
 
  private static final long serialVersionUID = -3884749706239755036L;
  
  private String title;
  private String description;
  private double price;
   

  public RoomServiceItemDto() { 
	}
	
  public String getTitle() {
    return title;
  }
 
  public void setTitle(String title) {
    this.title = title;
  }
  
  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }
  
  public double getPrice() {
    return price;
  }

  public void setPrice(double price) {
    this.price = price;
  }
  
  public static RoomServiceItemDto fromJsonObject(JsonObject jsonObject) {
    BaseEntity baseEntity = BaseEntity.fromJsonObject(jsonObject);
    RoomServiceItemDto dto = new RoomServiceItemDto();
    dto.id = baseEntity.id;
    
    dto.setTitle(jsonObject.getString("title"));
    dto.setDescription(jsonObject.getString("description"));
    dto.setPrice(jsonObject.getDouble("price"));
    
    return dto;
  }

































	
	
}
