package majestella.core.rest.dto;

import majestella.core.prototype.json.JsonObject;

public class SessionStartResultDto extends BaseEntity {

  private static final long serialVersionUID = -5322590896249806808L;

  private String requiredAppVersion; // this is the version required to work fine

  public SessionStartResultDto() {
  }

  public String getRequiredAppVersion() {
    return requiredAppVersion;
  }

  public void setRequiredAppVersion(String requiredAppVersion) {
    this.requiredAppVersion = requiredAppVersion;
  }

  public static SessionStartResultDto fromJsonObject(JsonObject jsonObject) {
    SessionStartResultDto dto = new SessionStartResultDto();
    dto.setRequiredAppVersion(jsonObject.getString("requiredAppVersion"));

    return dto;
  }

}
