package majestella.core.rest.dto;

import java.util.ArrayList;
import java.util.List;

import majestella.core.prototype.json.JsonArray;
import majestella.core.prototype.json.JsonObject;


public class RoomServiceDomainDto extends BaseEntity {

  private static final long serialVersionUID = 3284173257165640542L;
  
  private String titleImageUrl;
  private List<RoomServiceCategoryDto> roomServiceCategoryDtos = new ArrayList<>(); 

  
  public RoomServiceDomainDto() {
  }

  public String getTitleImageUrl() {
    return titleImageUrl;
  }

  public void setTitleImageUrl(String titleImageUrl) {
    this.titleImageUrl = titleImageUrl;
  }
  
  public List<RoomServiceCategoryDto> getRoomServiceCategoryDtos() {
    return roomServiceCategoryDtos;
  }

  public void setRoomServiceCategoryDtos(List<RoomServiceCategoryDto> roomServiceCategoryDtos) {
    this.roomServiceCategoryDtos = roomServiceCategoryDtos;
  }
  
    
  public static RoomServiceDomainDto fromJsonObject(JsonObject jsonObject) {
    BaseEntity baseEntity = BaseEntity.fromJsonObject(jsonObject);
    RoomServiceDomainDto dto = new RoomServiceDomainDto();
    dto.id = baseEntity.getId();
    
    dto.setTitleImageUrl(jsonObject.getString("titleImageUrl"));
    JsonArray jsonRoomServiceCategoryDtos = 
         jsonObject.getJsonArray("roomServiceCategoryDtos");
    
    for (int i = 0; i < jsonRoomServiceCategoryDtos.length(); i++) {
      JsonObject jso = jsonRoomServiceCategoryDtos.getJsonObject(i);
      RoomServiceCategoryDto categoryDto = RoomServiceCategoryDto.fromJsonObject(jso);
      dto.roomServiceCategoryDtos.add(categoryDto);
    }
    
    return dto;
  }












  
  
  
}
