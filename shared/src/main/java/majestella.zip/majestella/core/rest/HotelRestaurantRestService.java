package majestella.core.rest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

import majestella.core.network.Connection;
import majestella.core.network.Connection.ConnectionCallback;
import majestella.core.network.Connection.HTTPMethod;
import majestella.core.plugins.cookie.Cookie;
import majestella.core.prototype.json.JsonArray;
import majestella.core.prototype.json.JsonObject;
import majestella.core.prototype.mvp.proxy.BAsyncCallback;
import majestella.core.rest.dto.DeviceDto;
import majestella.core.rest.dto.GetResults;
import majestella.core.rest.dto.HotelRestaurantDto;
 

public class HotelRestaurantRestService extends AbstractRestService {

  public HotelRestaurantRestService(Connection connection, DeviceDto deviceDto, Cookie cookie) {
    super(connection, deviceDto, cookie);
    url += ResourcesPath.HOTEL_RESTAURANT;
  }

  public void get(String locationId, final BAsyncCallback<GetResults<HotelRestaurantDto>> callback) {
    logger.info("<<< HotelRestaurantRestService get()");
    
    Map<String, String> params = new HashMap<>();
    params.put(RestParameter.LOCATION_ID, locationId);
    params.put(RestParameter.COOKIE, cookie.getLoggedInCookie());  
    params.put(RestParameter.LOCALE, deviceDto.getLocale());
    params.put(RestParameter.DEVICE_UUID, deviceDto.getUuid());
    

    connection.request(HTTPMethod.GET, url, params, new ConnectionCallback() {

      @Override
      public void onResponse(int statusCode, String data) {
        logger.info(">>> HotelRestaurantRestService get(): statusCode: "+statusCode);
        if (statusCode == 200) {
          GetResults<HotelRestaurantDto> result = parseString(data);
          callback.onSuccess(result);
        } else {
          callback.onFailure(new Exception("Server responded with status code: " + statusCode));
        }
      }

      @Override
      public void onError(Exception ex) {
        logger.log(Level.SEVERE, "HotelRestaurantRestService - get(): onError(): " + ex.getMessage(), ex);
        callback.onFailure(ex);
      }
    });

  }
  
  
  GetResults<HotelRestaurantDto> parseString(String jsonString) {
    JsonObject jsonObj = new JsonObject(jsonString);
    JsonArray array = jsonObj.getJsonArray("results");
    
    final List<HotelRestaurantDto> dtos = new ArrayList<>();
    for(int i=0; i<array.length(); i++) {
      JsonObject value = array.getJsonObject(i);
      HotelRestaurantDto dto = HotelRestaurantDto.fromJsonObject(value);
      dtos.add(dto);
    }
    
    GetResults<HotelRestaurantDto> result = new GetResults<>();
    result.setResults(dtos);
    
    return result;
  }
 

}
