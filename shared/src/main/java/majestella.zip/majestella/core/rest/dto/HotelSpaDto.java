package majestella.core.rest.dto;
 
import majestella.core.prototype.json.JsonObject;

public class HotelSpaDto extends BaseEntity {

  private static final long serialVersionUID = -822800017858473855L;
  private String name;
  private String type;
  private String reservationNumber;
  private String contentItem;
  private String titleImageUrl;

  public HotelSpaDto() { 
	}

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getReservationNumber() {
    return reservationNumber;
  }

  public void setReservationNumber(String reservationNumber) {
    this.reservationNumber = reservationNumber;
  }

  public String getContentItem() {
    return contentItem;
  }

  public void setContentItem(String contentItem) {
    this.contentItem = contentItem;
  }

  public String getTitleImageUrl() {
    return titleImageUrl;
  }

  public void setTitleImageUrl(String titleImageUrl) {
    this.titleImageUrl = titleImageUrl;
  }
	
  
  public static HotelSpaDto fromJsonObject(JsonObject jsonObject) {
    BaseEntity baseEntity = BaseEntity.fromJsonObject(jsonObject);
    HotelSpaDto dto = new HotelSpaDto();
    dto.id = baseEntity.id;
    
    dto.setName(jsonObject.getString("name"));
    dto.setType(jsonObject.getString("type"));
    dto.setReservationNumber(jsonObject.getString("reservationNumber")); 
    dto.setContentItem(jsonObject.getString("contentItem")); 
    dto.setTitleImageUrl(jsonObject.getString("titleImageUrl"));
    
    return dto;
  }

























	
	
}
