package majestella.core.rest.dto;

import majestella.core.prototype.json.JsonObject;

 

public class LoginRequestDto {
	String username = "";
	String email = "";
	String password = "";
	String cookie = "";
	String accessToken = "";
	String expiresIn = "";
	DeviceDto deviceDto;

    protected LoginRequestDto() {
    }

    /**
     * This constructor is used when the user loggs in with username or email.
     * @param usernameOrEmail
     * @param password
     * @param isUsername
     */
    public LoginRequestDto(String usernameOrEmail, String password, boolean isUsername, DeviceDto deviceDto) {
        this.password = password;
       
        if (isUsername) {
        	this.username = usernameOrEmail;
        }
        else {
        	this.email = usernameOrEmail;
        }
        this.deviceDto = deviceDto;
    }
    
    /**
     * This constructor is used when the user loggs in with facebook.
     * @param accessToken
     * @param expiresIn
     */
    public LoginRequestDto(String accessToken, String expiresIn, DeviceDto deviceDto) {
    	this.accessToken = accessToken;
    	this.expiresIn = expiresIn;
    	this.deviceDto = deviceDto;
    }

    /**
     * This constructor is used when the user loggs in with cookie.
     * @param cookie
     */
    public LoginRequestDto(String cookie, DeviceDto deviceDto) {
        this.cookie = cookie;
        this.deviceDto = deviceDto;
    }

    public String getUsername() {
        return username;
    }

    
    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public String getCookie() {
        return cookie;
    }
    
    public String getAccessToken() {
    	return accessToken;
    }
    
    public String getExpiresIn() {
    	return expiresIn;
    }
    
    public DeviceDto getDeviceDto() {
    	return deviceDto;
    }
    
    
    /**
     * Converts this object into a JSON string.
     * @return
     */
    public String toJsonString() {
      String  result = "";
      
      JsonObject jsonObject = new JsonObject();
      jsonObject.put("username", username);
      jsonObject.put("email", email);
      jsonObject.put("password", password);
      jsonObject.put("cookie", cookie);
      jsonObject.put("accessToken", accessToken);
      jsonObject.put("expiresIn", expiresIn); 
      jsonObject.put("deviceDto", deviceDto.toJsonObject());   
      
      result = jsonObject.toString();
      return result;
    }

 
    
}
