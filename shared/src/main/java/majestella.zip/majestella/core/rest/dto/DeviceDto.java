package majestella.core.rest.dto;

import java.util.Arrays;
import java.util.List;

import majestella.core.prototype.json.JsonObject;

import com.google.common.base.Strings;

/**
 * Store device informations of the users browser.
 * 
 * @author Dr. Michael Gorski
 *
 */
public class DeviceDto {

  String locale;
  String platform;
  double clientWidth;
  double clientHeight;
  boolean retina;
  String uuid; // the uuid of the device
  String model; // model name of the device
  String version; // the operating system version
  String appVersion; // this is the version of the app as specified in iOS or Android.
  String pushToken; // this is the token for GCM or APNS push
  double pixelRatio;
  
  public DeviceDto() {
  }

  public void setData(String locale, String platform, int clientWidth, int clientHeight, boolean retina) {
    setLocale(locale);
    this.platform = platform;
    this.clientWidth = clientWidth;
    this.clientHeight = clientHeight;
    this.retina = retina;
  }

  public String getLocale() {
    return locale;
  }

  public void setLocale(String locale) {
    if (locale.equals("default")) {
      this.locale = "en";
    } else {
      this.locale = locale;
    }
  }

  public String getPlatform() {
    return platform;
  }

  public void setPlatform(String platform) {
    this.platform = platform;
  }

  public void setRetina(boolean value) {
    this.retina = value;
  }

  public boolean isRetina() {
    return retina;
  }

  /**
   * Check if the data has been set.
   * 
   * @return
   */
  public boolean isEmpty() {
    if (locale == null) {
      return true;
    }
    return false;
  }

  public String getUuid() {
    return uuid;
  }

  public void setUuid(String uuid) {
    if (Strings.isNullOrEmpty(this.uuid)) {
      this.uuid = uuid;
    }
  }

  public String getModel() {
    return model;
  }

  public void setModel(String model) {
    if (Strings.isNullOrEmpty(this.model)) {
      this.model = model;
    }
  }

  public String getVersion() {
    return version;
  }

  public void setVersion(String version) {
    if (Strings.isNullOrEmpty(this.version)) {
      this.version = version;
    }
  }

  public String getAppVersion() {
    return appVersion;
  }

  public void setAppVersion(String appVersion) {
    this.appVersion = appVersion;
  }

  public String getPushToken() {
    return pushToken;
  }

  public void setPushToken(String pushToken) {
    this.pushToken = pushToken;
  }
  
  public void setClientWidth(double width) {
    this.clientWidth = width;
  }
  
  public double getClientWidth() {
    return clientWidth;
  }
  
  public void setClientHeight(double height) {
    this.clientHeight = height;
  }
  
  public double getClientHeight() {
    return clientHeight;
  }
  
  public void setPixelRatio(double pixelRatio) {
    this.pixelRatio = pixelRatio;
  }

  /**
   * Convert a string app version into an integer app version.
   * 
   * @param appVersion
   * @return
   */
  public static int getVersionNumber(String appVersion) {
    List<String> numberStrings = Arrays.asList(appVersion.split("\\.*"));
    if (numberStrings.size() < 2) {
      numberStrings.add("0");
    }
    if (numberStrings.size() < 3) {
      numberStrings.add("0");
    }
    appVersion = "";
    for (String entry : numberStrings) {
      appVersion += entry;
    }    
    return Integer.parseInt(appVersion);
  }

  /**
   * Compare app version of the form 1.0.0, 1.0 or 1 with each other. <br>
   * <br>
   * If the appVersion1 > appVersion2 return 1. <br>
   * If the appVersion1 == appVersion2 return 0. <br>
   * If the appVersion1 < appVersion2 return -1. <br>
   * 
   * @param appVersion1
   * @param appVersion2
   * @return
   */
  public static int compareAppVersion(String appVersion1, String appVersion2) {
    int version1 = getVersionNumber(appVersion1);
    int version2 = getVersionNumber(appVersion2);
    if (version1 > version2) {
      return 1;
    } else if (version1 == version2) {
      return 0;
    } else {
      return -1;
    }
  }

  public JsonObject toJsonObject() {
    JsonObject jsonObject = new JsonObject();
    jsonObject.put("locale", locale);
    jsonObject.put("platform", platform);
    jsonObject.put("clientWidth", clientWidth);
    jsonObject.put("clientHeight", clientHeight);
    jsonObject.put("retina", retina);
    jsonObject.put("uuid", uuid);
    jsonObject.put("model", model);
    jsonObject.put("version", version);
    jsonObject.put("appVersion", appVersion);
    jsonObject.put("pushToken", pushToken);
    jsonObject.put("pixelRatio", pixelRatio);    
    return jsonObject;
  }

  /**
   * Converts this object into a JSON string.
   * 
   * @return
   */
  public String toJsonString() {
    return toJsonObject().toString();
  }

}
