package majestella.core.rest.dto;
 
import majestella.core.prototype.json.JsonObject;

public class PlaceDto extends BaseEntity {

  private static final long serialVersionUID = 5549669509155822970L;
  
  private String name;
  private String logoImageUrl;
  private String titleImageUrl;
  private double latitude;
  private double longitude; 
  

  public PlaceDto() { 
	}
  
  public static int getType() {
    return 0;
  }
	
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getLogoImageUrl() {
    return logoImageUrl;
  }

  public void setLogoImageUrl(String logoImageUrl) {
    this.logoImageUrl = logoImageUrl;
  }

  public String getTitleImageUrl() {
    return titleImageUrl;
  }

  public void setTitleImageUrl(String titleImageUrl) {
    this.titleImageUrl = titleImageUrl;
  }

  public double getLatitude() {
    return latitude;
  }

  public void setLatitude(double latitude) {
    this.latitude = latitude;
  }

  public double getLongitude() {
    return longitude;
  }

  public void setLongitude(double longitude) {
    this.longitude = longitude;
  }

  
  public static PlaceDto fromJsonObject(JsonObject jsonObject) {
    BaseEntity baseEntity = BaseEntity.fromJsonObject(jsonObject);
    PlaceDto dto = new PlaceDto();
    dto.id = baseEntity.id;
    
    dto.setName(jsonObject.getString("name"));
    dto.setLogoImageUrl(jsonObject.getString("logoImageUrl"));
    dto.setTitleImageUrl(jsonObject.getString("titleImageUrl"));
    dto.setLatitude(jsonObject.getDouble("latitude"));
    dto.setLongitude(jsonObject.getDouble("longitude"));
    
    return dto;
  }




}
