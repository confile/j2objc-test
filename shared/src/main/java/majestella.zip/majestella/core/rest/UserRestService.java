package majestella.core.rest;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;

import majestella.core.network.Connection;
import majestella.core.network.Connection.ConnectionCallback;
import majestella.core.network.Connection.HTTPMethod;
import majestella.core.plugins.cookie.Cookie;
import majestella.core.prototype.json.JsonObject;
import majestella.core.prototype.mvp.proxy.BAsyncCallback;
import majestella.core.rest.dto.DeviceDto;
import majestella.core.rest.dto.GetResult;
import majestella.core.rest.dto.UserDto;
 

public class UserRestService extends AbstractRestService {

  public UserRestService(Connection connection, DeviceDto deviceDto, Cookie cookie) {
    super(connection, deviceDto, cookie);
    url += ResourcesPath.USER;
  }

  public void get(String username, final BAsyncCallback<GetResult<UserDto>> callback) {
    logger.info("<<< UserRestService get()");
    
    Map<String, String> params = new HashMap<>();
    params.put(RestParameter.USERNAME, username);
    params.put(RestParameter.COOKIE, cookie.getLoggedInCookie());
    params.put(RestParameter.LOCALE, deviceDto.getLocale());
    params.put(RestParameter.DEVICE_UUID, deviceDto.getUuid());

    connection.request(HTTPMethod.GET, url, params, new ConnectionCallback() {

      @Override
      public void onResponse(int statusCode, String data) {
        logger.info(">>> UserRestService get(): statusCode: "+statusCode);
        if (statusCode == 200) {
          GetResult<UserDto> result = parseString(data);
          callback.onSuccess(result);
        } else {
          callback.onFailure(new Exception("Server responded with status code: " + statusCode));
        }
      }

      @Override
      public void onError(Exception ex) {
        logger.log(Level.SEVERE, "UserRestService - get(): onError(): " + ex.getMessage(), ex);
        callback.onFailure(ex);
      }
    });

  }

  GetResult<UserDto> parseString(String jsonString) {
    JsonObject jsonObj = new JsonObject(jsonString);
    jsonObj = jsonObj.getJsonObject("result");
    
    UserDto userDto = UserDto.fromJsonObject(jsonObj);
    GetResult<UserDto> result = new GetResult<>();
    result.setResult(userDto);
    
    return result;
  }

}
