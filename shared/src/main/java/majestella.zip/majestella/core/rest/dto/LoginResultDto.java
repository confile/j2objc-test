package majestella.core.rest.dto;

import majestella.core.prototype.json.JsonObject;

 
public class LoginResultDto {

  private static final long serialVersionUID = 2053046574256266029L;

  private UserDetailsDto userDetailsDto;
  private String cookieName;
  private String cookieValue;
  private long maxAge;
  private String path;
  private boolean useSecureCookie;

  public LoginResultDto() {
  }

  public LoginResultDto(UserDetailsDto userDetailsDto) {
    this.userDetailsDto = userDetailsDto;
  }

  public LoginResultDto(UserDetailsDto userDetailsDto, String cookieName, String cookieValue, long maxAge, String path,
      boolean useSecureCookie) {
    this.userDetailsDto = userDetailsDto;
    this.cookieName = cookieName;
    this.cookieValue = cookieValue;
    this.maxAge = maxAge;
    this.path = path;
    this.useSecureCookie = useSecureCookie;
  }

  public UserDetailsDto getUserDetailsDto() {
    return userDetailsDto;
  }

  public void setUserDetailsDto(UserDetailsDto userDetailsDto) {
    this.userDetailsDto = userDetailsDto;
  }

  public boolean isLoggedin() {
    if (userDetailsDto == null) {
      return false;
    } else if (userDetailsDto.getErrorCount() == 0) {
      return true;
    }
    return false;
  }

  public String getCookieName() {
    return cookieName;
  }

  public void setCookieName(String cookieName) {
    this.cookieName = cookieName;
  }

  public String getCookieValue() {
    return cookieValue;
  }

  public void setCookieValue(String cookieValue) {
    this.cookieValue = cookieValue;
  }

  public long getMaxAge() {
    return maxAge;
  }

  public void setMaxAge(long maxAge) {
    this.maxAge = maxAge;
  }

  public String getPath() {
    return path;
  }

  public void setPath(String path) {
    this.path = path;
  }

  public boolean getUseSecureCookie() {
    return useSecureCookie;
  }

  public void setUseSecureCookie(boolean useSecureCookie) {
    this.useSecureCookie = useSecureCookie;
  }

  public static LoginResultDto fromJsonObject(JsonObject jsonObject) {
    LoginResultDto dto = new LoginResultDto();     
    UserDetailsDto userDetailsDto = UserDetailsDto.fromJsonObject(jsonObject.getJsonObject("userDetailsDto"));
    dto.setUserDetailsDto(userDetailsDto);
    dto.setCookieName(jsonObject.getString("cookieName"));
    dto.setCookieValue(jsonObject.getString("cookieValue"));
    dto.setMaxAge((int)jsonObject.getDouble("maxAge"));
    dto.setPath(jsonObject.getString("path"));
    dto.setUseSecureCookie(jsonObject.getBoolean("useSecureCookie"));
    
    return dto;
  }

}
