package majestella.core.rest;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;

import majestella.core.network.Connection;
import majestella.core.network.Connection.ConnectionCallback;
import majestella.core.network.Connection.HTTPMethod;
import majestella.core.plugins.cookie.Cookie;
import majestella.core.prototype.json.JsonObject;
import majestella.core.prototype.mvp.proxy.BAsyncCallback;
import majestella.core.rest.dto.BooleanDto;
import majestella.core.rest.dto.DeviceDto;
import majestella.core.rest.dto.GetResult;
import majestella.core.rest.dto.RoomServiceDomainDto;
import majestella.core.rest.dto.RoomServiceOrderDto;
 

public class RoomServiceRestService extends AbstractRestService {

  public RoomServiceRestService(Connection connection, DeviceDto deviceDto, Cookie cookie) {
    super(connection, deviceDto, cookie);
    url += ResourcesPath.ROOM_SERVICE;
  }

  public void get(String locationId, final BAsyncCallback<GetResult<RoomServiceDomainDto>> callback) {
    logger.info("<<< RoomServiceRestService get()");
    
    Map<String, String> params = new HashMap<>();
    params.put(RestParameter.LOCATION_ID, locationId);  
    params.put(RestParameter.COOKIE, cookie.getLoggedInCookie());  
    params.put(RestParameter.LOCALE, deviceDto.getLocale());
    params.put(RestParameter.DEVICE_UUID, deviceDto.getUuid());

    connection.request(HTTPMethod.GET, url, params, new ConnectionCallback() {

      @Override
      public void onResponse(int statusCode, String data) {
        logger.info(">>> RoomServiceRestService get(): statusCode: "+statusCode);
        if (statusCode == 200) {
          GetResult<RoomServiceDomainDto> result = parseString(data);
          callback.onSuccess(result);
        } else {
          callback.onFailure(new Exception("Server responded with status code: " + statusCode));
        }
      }

      @Override
      public void onError(Exception ex) {
        logger.log(Level.SEVERE, "RoomServiceRestService - get(): onError(): " + ex.getMessage(), ex);
        callback.onFailure(ex);
      }
    });

  }
  
  
  GetResult<RoomServiceDomainDto> parseString(String jsonString) {
    JsonObject jsonObj = new JsonObject(jsonString);
    jsonObj = jsonObj.getJsonObject("result");
    
    RoomServiceDomainDto dto = RoomServiceDomainDto.fromJsonObject(jsonObj);
    GetResult<RoomServiceDomainDto> result = new GetResult<>();
    result.setResult(dto);
    
    return result;
  }
 
  
  public void sendShoppingCard(String locationId, RoomServiceOrderDto roomServiceOrderDto, 
      String lastName, int roomNumber, Date departureDate, 
      final BAsyncCallback<GetResult<BooleanDto>> callback) {
    logger.info("<<< RoomServiceRestService post()");
    
    Map<String, String> params = new HashMap<>();
    params.put(RestParameter.LOCATION_ID, locationId);  
    params.put(RestParameter.COOKIE, cookie.getLoggedInCookie());  
    params.put(RestParameter.LOCALE, deviceDto.getLocale());
    params.put(RestParameter.DEVICE_UUID, deviceDto.getUuid());
    params.put(RestParameter.LAST_NAME, lastName);
    params.put(RestParameter.ROOM_NUMBER, ""+roomNumber);
    params.put(RestParameter.DEPARTURE_DATE, ""+departureDate.getTime());
        
    String bodyString = roomServiceOrderDto.toJsonString();    
    
    connection.request(HTTPMethod.POST, url, params, bodyString, new ConnectionCallback() {
      
      @Override
      public void onResponse(int statusCode, String data) {
        logger.info(">>> RoomServiceRestService sendShoppingCard(): statusCode: "+statusCode);
        if (statusCode == 200) {
          GetResult<BooleanDto> result = parsePostResultString(data);
          callback.onSuccess(result);
        }
        else {
          callback.onFailure(new Exception("Server responded with status code: "+statusCode));
        }
      }
      
      @Override
      public void onError(Exception ex) {
        logger.log(Level.SEVERE, "RoomServiceRestService - sendShoppingCard(): onError(): "+ex.getMessage(), ex);
        callback.onFailure(ex);
      }
    });
    
  }
  
  
  GetResult<BooleanDto> parsePostResultString(String jsonString) {
    JsonObject jsonObj = new JsonObject(jsonString);
    jsonObj = jsonObj.getJsonObject("result");
    BooleanDto dto = BooleanDto.fromJsonObject(jsonObj);
    GetResult<BooleanDto> result = new GetResult<BooleanDto>();
    result.setResult(dto);
    
    return result;
  }
  
  

}
