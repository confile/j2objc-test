package majestella.core.rest.dto;

import java.util.logging.Logger;

import majestella.core.prototype.json.JsonObject;

 public class BaseEntity implements Dto {

  protected String id;

  Logger logger;
  
  public BaseEntity() {
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((id == null) ? 0 : id.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }

    if (obj == null) {
      return false;
    }

    if (getClass() != obj.getClass()) {
      return false;
    }

    BaseEntity other = (BaseEntity) obj;

    if (id == null) {
      if (other.id != null) {
        return false;
      }
    } else if (!id.equals(other.id)) {
      return false;
    }

    return true;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }
  
  
  public static BaseEntity fromJsonObject(JsonObject jsonObject) {
    BaseEntity dto = new BaseEntity();
    dto.setId(jsonObject.getString("id"));
    return dto;
  }
  
  
  public JsonObject getBaseEntityJsonObject() {
    JsonObject jsonObject = new JsonObject();
    jsonObject.put("id", id); 
 
    return jsonObject;
  }

}
