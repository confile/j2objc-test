package majestella.core.rest;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;

import majestella.core.network.Connection;
import majestella.core.network.Connection.ConnectionCallback;
import majestella.core.network.Connection.HTTPMethod;
import majestella.core.plugins.cookie.Cookie;
import majestella.core.prototype.json.JsonObject;
import majestella.core.prototype.mvp.proxy.BAsyncCallback;
import majestella.core.rest.dto.DeviceDto;
import majestella.core.rest.dto.GetResult;
import majestella.core.rest.dto.LocationDto;
 

public class LocationRestService extends AbstractRestService {

  public LocationRestService(Connection connection, DeviceDto deviceDto, Cookie cookie) {
    super(connection, deviceDto, cookie);
    url += ResourcesPath.LOCATION;
  }

  public void get(String objectId, int locationType, final BAsyncCallback<GetResult<LocationDto>> callback) {
    logger.info("<<< LocationRestService get()");
    
    Map<String, String> params = new HashMap<>();
    params.put(RestParameter.LOCATION_ID, objectId);
    params.put(RestParameter.LOCATION_TYPE, ""+locationType);
    params.put(RestParameter.COOKIE, cookie.getLoggedInCookie());
    params.put(RestParameter.LOCALE, deviceDto.getLocale());
    params.put(RestParameter.DEVICE_UUID, deviceDto.getUuid());
    

    connection.request(HTTPMethod.GET, url, params, new ConnectionCallback() {

      @Override
      public void onResponse(int statusCode, String data) {
        logger.info(">>> LocationRestService get(): statusCode: "+statusCode);
        if (statusCode == 200) {
          GetResult<LocationDto> result = parseString(data);
          callback.onSuccess(result);
        } else {
          callback.onFailure(new Exception("Server responded with status code: " + statusCode));
        }
      }

      @Override
      public void onError(Exception ex) {
        logger.log(Level.SEVERE, "LocationRestService - get(): onError(): " + ex.getMessage(), ex);
        callback.onFailure(ex);
      }
    });

  }

  GetResult<LocationDto> parseString(String jsonString) {
    JsonObject jsonObj = new JsonObject(jsonString);
    jsonObj = jsonObj.getJsonObject("result");
    
    LocationDto locationDto = LocationDto.fromJsonObject(jsonObj);
    GetResult<LocationDto> result = new GetResult<>();
    result.setResult(locationDto);
    
    return result;
  }

}
