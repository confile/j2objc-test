package majestella.core.rest.dto;


public class SignupDto extends BaseEntity {

	// 0: user with email exists
	// 1: user with username exists
	// 2: success
    private int resultCode;
    private String text;

    
    protected SignupDto() {
        // Needed for serialization
    }

    public SignupDto(int resultCode, String text) {
    	this.setResultCode(resultCode);
    	this.setText(text);
    }

	public int getResultCode() {
		return resultCode;
	}

	public void setResultCode(int resultCode) {
		this.resultCode = resultCode;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
    
  

    

}
