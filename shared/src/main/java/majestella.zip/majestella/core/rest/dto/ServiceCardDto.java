package majestella.core.rest.dto;
 
import java.util.ArrayList;
import java.util.List;

import majestella.core.prototype.json.JsonArray;
import majestella.core.prototype.json.JsonObject;

public class ServiceCardDto extends BaseEntity {

  private static final long serialVersionUID = -437580048503173599L;
  
  private String title;
  private String description;
  private String priceDescription;
  private List<String> imageUrls;
  private double latitude;
  private double longitude;
  private String imageCopyright;
  private String bookingUrl;
  private String bookingEmail;
  private String bookingPhone;
  private long lastUpdatedTime;
  private String companyName;  
  private String companyId;
  
  
  public ServiceCardDto() { 
	}
	
  
  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }
 
  public String getPriceDescription() {
    return priceDescription;
  }

  public void setPriceDescription(String priceDescription) {
    this.priceDescription = priceDescription;
  }
  
  public List<String> getImageUrls() {
    return imageUrls;
  }

  public void setImageUrls(List<String> imageUrls) {
    this.imageUrls = imageUrls;
  }
  
  public double getLatitude() {
    return latitude;
  }

  public void setLatitude(double latitude) {
    this.latitude = latitude;
  }

  public double getLongitude() {
    return longitude;
  }

  public void setLongitude(double longitude) {
    this.longitude = longitude;
  }
  
  public String getImageCopyright() {
    return imageCopyright;
  }

  public void setImageCopyright(String imageCopyright) {
    this.imageCopyright = imageCopyright;
  }
  
  public String getBookingUrl() {
    return bookingUrl;
  }

  public void setBookingUrl(String bookingUrl) {
    this.bookingUrl = bookingUrl;
  }

  public String getBookingEmail() {
    return bookingEmail;
  }

  public void setBookingEmail(String bookingEmail) {
    this.bookingEmail = bookingEmail;
  }

  public String getBookingPhone() {
    return bookingPhone;
  }

  public void setBookingPhone(String bookingPhone) {
    this.bookingPhone = bookingPhone;
  }
  
  public long getLastUpdatedTime() {
    return lastUpdatedTime;
  }

  public void setLastUpdatedTime(long lastUpdatedTime) {
    this.lastUpdatedTime = lastUpdatedTime;
  }

  public String getCompanyName() {
    return companyName;
  }

  public void setCompanyName(String companyName) {
    this.companyName = companyName;
  }
  
  public String getCompanyId() {
    return companyId;
  }

  public void setCompanyId(String companyId) {
    this.companyId = companyId;
  }
  
  public static ServiceCardDto fromJsonObject(JsonObject jsonObject) {
    BaseEntity baseEntity = BaseEntity.fromJsonObject(jsonObject);
    ServiceCardDto dto = new ServiceCardDto();
    dto.id = baseEntity.id;
    
    dto.setTitle(jsonObject.getString("title"));
    dto.setDescription(jsonObject.getString("description"));
    dto.setPriceDescription(jsonObject.getString("priceDescription"));
    
    List<String> urls = new ArrayList<>();
    JsonArray jsonImageUrls = jsonObject.getJsonArray("imageUrls");
    if (jsonImageUrls.length() > 0) {
      for (int i=0; i < jsonImageUrls.length(); i++) {
        String url = jsonImageUrls.getString(i);
        urls.add(url);
      }      
    }
    dto.setImageUrls(urls);
    
    dto.setLatitude(jsonObject.getDouble("latitude"));
    dto.setLongitude(jsonObject.getDouble("longitude"));
    dto.setImageCopyright(jsonObject.getString("imageCopyright"));
    dto.setBookingUrl(jsonObject.getString("bookingUrl"));
    dto.setBookingEmail(jsonObject.getString("bookingEmail"));
    dto.setBookingPhone(jsonObject.getString("bookingPhone")); 
    dto.setLastUpdatedTime((long)jsonObject.getDouble("lastUpdatedTime"));
    dto.setCompanyName(jsonObject.getString("companyName"));
    dto.setCompanyId(jsonObject.getString("companyId"));
    
    return dto;
  }


























































	
	
}
