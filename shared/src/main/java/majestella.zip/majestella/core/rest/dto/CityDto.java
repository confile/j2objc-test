package majestella.core.rest.dto;
 
import majestella.core.prototype.json.JsonObject;

public class CityDto extends BaseEntity {

  private static final long serialVersionUID = 1372378685894056840L;
   
  private String name;
  private String logoImageUrl;
  private String titleImageUrl;
  private double latitude;
  private double longitude;
  

  public CityDto() { 
	}
	

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }
  
  public String getLogoImageUrl() {
    return logoImageUrl;
  }

  public void setLogoImageUrl(String logoImageUrl) {
    this.logoImageUrl = logoImageUrl;
  }
   
  public String getTitleImageUrl() {
    return titleImageUrl;
  }

  public void setTitleImageUrl(String titleImageUrl) {
    this.titleImageUrl = titleImageUrl;
  }
  
  public double getLatitude() {
    return latitude;
  }

  public void setLatitude(double latitude) {
    this.latitude = latitude;
  }

  public double getLongitude() {
    return longitude;
  }

  public void setLongitude(double longitude) {
    this.longitude = longitude;
  }
  
  
  public static CityDto fromJsonObject(JsonObject jsonObject) {
    BaseEntity baseEntity = BaseEntity.fromJsonObject(jsonObject);
    CityDto dto = new CityDto();
    dto.id = baseEntity.id;
    
    dto.setName(jsonObject.getString("name"));
    dto.setLogoImageUrl(jsonObject.getString("logoImageUrl"));
    dto.setTitleImageUrl(jsonObject.getString("titleImageUrl"));
    dto.setLatitude(jsonObject.getDouble("latitude"));
    dto.setLongitude(jsonObject.getDouble("longitude"));
    
    return dto;
  }





































	
	
}
