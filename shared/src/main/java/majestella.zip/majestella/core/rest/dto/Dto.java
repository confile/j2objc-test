package majestella.core.rest.dto;

import java.io.Serializable;

public interface Dto extends Serializable {
}
