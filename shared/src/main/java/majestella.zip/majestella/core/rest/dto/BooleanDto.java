package majestella.core.rest.dto;

import majestella.core.prototype.json.JsonObject;


public class BooleanDto implements Dto {

  private static final long serialVersionUID = 5405128162156639013L;
  
  private boolean value;

  public BooleanDto() {
    setValue(false);
  }

  public boolean getValue() {
    return value;
  }

  public void setValue(boolean value) {
    this.value = value;
  }
  
  
  
  public static BooleanDto fromJsonObject(JsonObject jsonObject) {
    BooleanDto dto = new BooleanDto();
    dto.setValue(jsonObject.getBoolean("value"));
    
    return dto;
  }
  

}
