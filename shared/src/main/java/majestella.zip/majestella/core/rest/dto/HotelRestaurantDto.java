package majestella.core.rest.dto;

import majestella.core.prototype.json.JsonObject;


public class HotelRestaurantDto extends BaseEntity {

  private static final long serialVersionUID = 1L;
 
  private String restaurantType;
  private String name;
  private String reservationNumber;
  private String contentItem;
  private String titleImageUrl;
  
  
  public HotelRestaurantDto() {
  }

  
  public String getRestaurantType() {
    return restaurantType;
  }
 
  public void setRestaurantType(String restaurantType) {
    this.restaurantType = restaurantType;
  } 
  
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }
  
  public String getReservationNumber() {
    return reservationNumber;
  }

  public void setReservationNumber(String reservationNumber) {
    this.reservationNumber = reservationNumber;
  }
  
  public String getContentItem() {
    return contentItem;
  }

  public void setContentItem(String contentItem) {
    this.contentItem = contentItem;
  }

  public String getTitleImageUrl() {
    return titleImageUrl;
  }

  public void setTitleImageUrl(String titleImageUrl) {
    this.titleImageUrl = titleImageUrl;
  }
  
  
  public static HotelRestaurantDto fromJsonObject(JsonObject jsonObject) {
    BaseEntity baseEntity = BaseEntity.fromJsonObject(jsonObject);
    HotelRestaurantDto dto = new HotelRestaurantDto();
    dto.id = baseEntity.getId();
    
    dto.setRestaurantType(jsonObject.getString("restaurantType"));
    dto.setName(jsonObject.getString("name")); 
    dto.setReservationNumber(jsonObject.getString("reservationNumber"));
    dto.setContentItem(jsonObject.getString("contentItem"));
    dto.setTitleImageUrl(jsonObject.getString("titleImageUrl"));    
    
    return dto;
  }












  
  
  
}
