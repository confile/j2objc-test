package majestella.core.rest;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;

import majestella.core.network.Connection;
import majestella.core.network.Connection.ConnectionCallback;
import majestella.core.network.Connection.HTTPMethod;
import majestella.core.plugins.cookie.Cookie;
import majestella.core.prototype.json.JsonObject;
import majestella.core.prototype.mvp.proxy.BAsyncCallback;
import majestella.core.rest.dto.BooleanDto;
import majestella.core.rest.dto.DeviceDto;
import majestella.core.rest.dto.GetResult;
 

public class ServiceDetailsRestService extends AbstractRestService {


  public ServiceDetailsRestService(Connection connection, DeviceDto deviceDto, Cookie cookie) {
    super(connection, deviceDto, cookie);
    url += ResourcesPath.SERVICE_DETAILS;
  }
   
  public void post(String serviceCardId, final BAsyncCallback<GetResult<BooleanDto>> callback) {
    logger.info("<<< ServiceDetailsRestService post()");
    
    Map<String, String> params = new HashMap<>();
    params.put(RestParameter.SERVICE_CARD_ID, serviceCardId);
    params.put(RestParameter.COOKIE, cookie.getLoggedInCookie());  
    params.put(RestParameter.LOCALE, deviceDto.getLocale());
    params.put(RestParameter.DEVICE_UUID, deviceDto.getUuid());
    
    connection.request(HTTPMethod.POST, url, params, new ConnectionCallback() {

      @Override
      public void onResponse(int statusCode, String data) {
        logger.info(">>> ServiceDetailsRestService post(): statusCode: "+statusCode);
        if (statusCode == 200) {
          GetResult<BooleanDto> result = parsePostResultString(data);
          callback.onSuccess(result);
        } else {
          callback.onFailure(new Exception("Server responded with status code: " + statusCode));
        }
      }

      @Override
      public void onError(Exception ex) {
        logger.log(Level.SEVERE, "ServiceDetailsRestService - post(): onError(): " + ex.getMessage(), ex);
        callback.onFailure(ex);
      }
    });
    
  }
  
  
  GetResult<BooleanDto> parsePostResultString(String jsonString) {
    JsonObject jsonObj = new JsonObject(jsonString);
    jsonObj = jsonObj.getJsonObject("result");
    BooleanDto dto = BooleanDto.fromJsonObject(jsonObj);
    GetResult<BooleanDto> result = new GetResult<BooleanDto>();
    result.setResult(dto);
    
    return result;
  }
  
  

}
