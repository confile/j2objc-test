package majestella.core.rest.dto;
 
import majestella.core.prototype.json.JsonObject;

public class HotelDto extends BaseEntity {

  private static final long serialVersionUID = 6539941817654407911L;

  private String logoImageUrl;
  private String city;
  private String titleImageUrl;
  private String name;
  private String zipCode;
  private String street;
  private String country;
  private String contentItem;
  private boolean hasRoomService;
  private boolean hasRestaurants;
  private boolean hasSpa;
  private String number1;
  private String number1Title;
  private double latitude;
  private double longitude;
  

  public HotelDto() { 
	}
  
  public static int getType() {
    return 1;
  }
	
  public String getLogoImageUrl() {
    return logoImageUrl;
  }

  public void setLogoImageUrl(String logoImageUrl) {
    this.logoImageUrl = logoImageUrl;
  }
   
  public String getCity() {
    return city;
  }

  public void setCity(String city) {
    this.city = city;
  }
  
  public String getTitleImageUrl() {
    return titleImageUrl;
  }

  public void setTitleImageUrl(String titleImageUrl) {
    this.titleImageUrl = titleImageUrl;
  }
  
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }
  
  public String getZipCode() {
    return zipCode;
  }

  public void setZipCode(String zipCode) {
    this.zipCode = zipCode;
  }
  
  public String getStreet() {
    return street;
  }

  public void setStreet(String street) {
    this.street = street;
  }
  
  public String getCountry() {
    return country;
  }

  public void setCountry(String country) {
    this.country = country;
  }
  
  public String getContentItem() {
    return contentItem;
  }

  public void setContentItem(String contentItem) {
    this.contentItem = contentItem;
  }
  
  public boolean getHasRoomService() {
    return hasRoomService;
  }

  public void setHasRoomService(boolean hasRoomService) {
    this.hasRoomService = hasRoomService;
  }

  public boolean getHasRestaurants() {
    return hasRestaurants;
  }

  public void setHasRestaurants(boolean hasRestaurants) {
    this.hasRestaurants = hasRestaurants;
  }
  
  public boolean getHasSpa() {
    return hasSpa;
  }

  public void setHasSpa(boolean hasSpa) {
    this.hasSpa = hasSpa;
  }
  
  public String getNumber1() {
    return number1;
  }

  public void setNumber1(String number1) {
    this.number1 = number1;
  }

  public String getNumber1Title() {
    return number1Title;
  }

  public void setNumber1Title(String number1Title) {
    this.number1Title = number1Title;
  }
  
  public double getLatitude() {
    return latitude;
  }

  public void setLatitude(double latitude) {
    this.latitude = latitude;
  }

  public double getLongitude() {
    return longitude;
  }

  public void setLongitude(double longitude) {
    this.longitude = longitude;
  }

  
  public static HotelDto fromJsonObject(JsonObject jsonObject) {
    BaseEntity baseEntity = BaseEntity.fromJsonObject(jsonObject);
    HotelDto dto = new HotelDto();
    dto.id = baseEntity.id;
    
    dto.setLogoImageUrl(jsonObject.getString("logoImageUrl"));
    dto.setCity(jsonObject.getString("city"));
    dto.setTitleImageUrl(jsonObject.getString("titleImageUrl"));
    dto.setName(jsonObject.getString("name"));
    dto.setZipCode(jsonObject.getString("zipCode"));
    dto.setStreet(jsonObject.getString("street"));
    dto.setCountry(jsonObject.getString("country"));
    dto.setContentItem(jsonObject.getString("contentItem"));
    dto.setHasRoomService(jsonObject.getBoolean("hasRoomService"));
    dto.setHasRestaurants(jsonObject.getBoolean("hasRestaurants"));
    dto.setHasSpa(jsonObject.getBoolean("hasSpa"));
    dto.setNumber1(jsonObject.getString("number1"));
    dto.setNumber1Title(jsonObject.getString("number1Title"));
    dto.setLatitude(jsonObject.getDouble("latitude"));
    dto.setLongitude(jsonObject.getDouble("longitude"));
    
    return dto;
  }




























	
	
}
