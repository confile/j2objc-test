package majestella.core.rest;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;

import majestella.core.network.Connection;
import majestella.core.network.Connection.ConnectionCallback;
import majestella.core.network.Connection.HTTPMethod;
import majestella.core.plugins.cookie.Cookie;
import majestella.core.prototype.json.JsonObject;
import majestella.core.prototype.mvp.proxy.BAsyncCallback;
import majestella.core.rest.dto.DeviceDto;
import majestella.core.rest.dto.GetResult;
import majestella.core.rest.dto.SessionStartResultDto;


public class SessionStartRestService extends AbstractRestService {

  public SessionStartRestService(Connection connection, DeviceDto deviceDto, Cookie cookie) {
    super(connection, deviceDto, cookie);
    url += ResourcesPath.SESSION_START;
  }

  
  public void saveOrCreate(final BAsyncCallback<GetResult<SessionStartResultDto>> callback) {
    
    logger.info("<<< SessionStartRestService saveOrCreate()");
    
    Map<String, String> params = new HashMap<>();
    params.put(RestParameter.COOKIE, cookie.getLoggedInCookie());
    
    String bodyString = deviceDto.toJsonString();
    
    connection.request(HTTPMethod.POST, url, params, bodyString, new ConnectionCallback() {
      
      @Override
      public void onResponse(int statusCode, String data) {
        logger.info(">>> SessionStartRestService saveOrCreate(): statusCode: "+statusCode);
        if (statusCode == 200) {
          GetResult<SessionStartResultDto> result = parseString(data);
          callback.onSuccess(result);
        }
        else {
          callback.onFailure(new Exception("Server responded with status code: "+statusCode));
        }
      }
      
      @Override
      public void onError(Exception ex) {
        logger.log(Level.SEVERE, "SessionStartRestService - saveOrCreate(): onError(): "+ex.getMessage(), ex);
        callback.onFailure(ex);
      }
    });
  }
  
  
  GetResult<SessionStartResultDto> parseString(String jsonString) {
    JsonObject jsonObj = new JsonObject(jsonString);
    jsonObj = jsonObj.getJsonObject("result");
    SessionStartResultDto dto = SessionStartResultDto.fromJsonObject(jsonObj);
    
    GetResult<SessionStartResultDto> reslut = new GetResult<SessionStartResultDto>();
    reslut.setResult(dto);    
    
    return reslut;
  }

  
}

