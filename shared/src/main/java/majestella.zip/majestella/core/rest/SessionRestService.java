package majestella.core.rest;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;

import majestella.core.network.Connection;
import majestella.core.network.Connection.ConnectionCallback;
import majestella.core.network.Connection.HTTPMethod;
import majestella.core.plugins.cookie.Cookie;
import majestella.core.prototype.json.JsonObject;
import majestella.core.prototype.mvp.proxy.BAsyncCallback;
import majestella.core.rest.dto.DeviceDto;
import majestella.core.rest.dto.LoginRequestDto;
import majestella.core.rest.dto.LoginResultDto;

public class SessionRestService extends AbstractRestService {

  public SessionRestService(Connection connection, DeviceDto deviceDto, Cookie cookie) {
    super(connection, deviceDto, cookie);
    url += ResourcesPath.SESSION;
  }
  
  public void login(LoginRequestDto loginRequest, final BAsyncCallback<LoginResultDto> callback) {
    Map<String, String> params = new HashMap<>();
    
    logger.info("<<< SessionRestService login()");
    
    String bodyString = loginRequest.toJsonString();
    logger.info("SessionRestService login(): "+bodyString);
    
    connection.request(HTTPMethod.POST, url, params, bodyString, new ConnectionCallback() {
      
      @Override
      public void onResponse(int statusCode, String data) {
        logger.info(">>> SessionRestService login(): statusCode: "+statusCode);
        if (statusCode == 200) {
          LoginResultDto result = parseStringLoginResultDto(data);
          callback.onSuccess(result);
        }
        else {
          callback.onFailure(new Exception("Server responded with status code: "+statusCode));
        }
      }
      
      @Override
      public void onError(Exception ex) {
        logger.log(Level.SEVERE, "SessionService - login(): onError(): "+ex.getMessage(), ex);
        callback.onFailure(ex);
      }
    });   
  }
  
  
  
  LoginResultDto parseStringLoginResultDto(String jsonString) {
    logger.info("SessionRestService parseStringLoginResultDto 1 jsonString: "+jsonString);
    JsonObject jsonObj = new JsonObject(jsonString);
    logger.info("SessionRestService parseStringLoginResultDto 2");
    LoginResultDto dto = LoginResultDto.fromJsonObject(jsonObj); 
    logger.info("SessionRestService parseStringLoginResultDto 3");
    return dto;
  }
  
  
  
  public void logout(String cookie, String pushToken, String uuid, final BAsyncCallback<Void> callback) {
    logger.info("<<< SessionRestService logout()");
    
    Map<String, String> params = new HashMap<>();
    params.put(RestParameter.COOKIE, cookie);
    params.put(RestParameter.PUSH_TOKEN, pushToken);
    params.put(RestParameter.UUID, uuid);
    
    connection.request(HTTPMethod.DELETE, url, params, new ConnectionCallback() {
      
      @Override
      public void onResponse(int statusCode, String data) {
        logger.info(">>> SessionRestService logout(): statusCode: "+statusCode);
        if ((statusCode == 200) || (statusCode == 204)) {
          callback.onSuccess(null);
        }
        else {
          callback.onFailure(new Exception("Server responded with status code: "+statusCode));
        }
      }
      
      @Override
      public void onError(Exception ex) {
        logger.log(Level.SEVERE, "SessionService - logout(): onError(): "+ex.getMessage(), ex);
        callback.onFailure(ex);
      }
    });
  }
  
  
  
  
}






 








