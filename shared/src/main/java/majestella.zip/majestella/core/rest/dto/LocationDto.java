package majestella.core.rest.dto;
 
import majestella.core.prototype.json.JsonObject;

public class LocationDto extends BaseEntity {
 
  private static final long serialVersionUID = -3281198825853461208L;
 
  
  private int type;
  private PlaceDto placeDto;
  private HotelDto hotelDto;
  private TouristOrganizationDto touristOrganizationDto;
  

  public LocationDto() { 
	}
	
  public int getType() {
    return type;
  }

  public void setType(int type) {
    this.type = type;
  }
  
  public PlaceDto getPlaceDto() {
    return placeDto;
  }

  public void setPlaceDto(PlaceDto placeDto) {
    this.placeDto = placeDto;
  }

  public HotelDto getHotelDto() {
    return hotelDto;
  }

  public void setHotelDto(HotelDto hotelDto) {
    this.hotelDto = hotelDto;
  }
   
  public TouristOrganizationDto getTouristOrganizationDto() {
    return touristOrganizationDto;
  }

  public void setTouristOrganizationDto(TouristOrganizationDto touristOrganizationDto) {
    this.touristOrganizationDto = touristOrganizationDto;
  }
  
  
  public static LocationDto fromJsonObject(JsonObject jsonObject) {
    BaseEntity baseEntity = BaseEntity.fromJsonObject(jsonObject);
    LocationDto dto = new LocationDto();
    dto.id = baseEntity.id;
    
    dto.setType((int)jsonObject.getDouble("type"));
    
    if (jsonObject.getJsonObject("placeDto") != null) {
      PlaceDto placeDto = PlaceDto.fromJsonObject(jsonObject.getJsonObject("placeDto"));
      dto.setPlaceDto(placeDto);
    }
    
    if (jsonObject.getJsonObject("hotelDto") != null) {
      HotelDto hotelDto = HotelDto.fromJsonObject(jsonObject.getJsonObject("hotelDto"));
      dto.setHotelDto(hotelDto);
    }
    
    if (jsonObject.getJsonObject("touristOrganizationDto") != null) {
      TouristOrganizationDto touristOrganizationDto = 
        TouristOrganizationDto.fromJsonObject(jsonObject.getJsonObject("touristOrganizationDto"));
      dto.setTouristOrganizationDto(touristOrganizationDto);
    }
    
    return dto;
  }


  public double getLatitude() {
    double result = 0;
    if (placeDto != null) {
      result = placeDto.getLatitude();
    }
    else if (hotelDto != null) {
      result = hotelDto.getLatitude();
    }
    else if (touristOrganizationDto != null) {
      result = touristOrganizationDto.getLatitude();
    }
    return result;
  }
  

  public double getLongitude() {
    double result = 0;
    if (placeDto != null) {
      result = placeDto.getLongitude();
    }
    else if (hotelDto != null) {
      result = hotelDto.getLongitude();
    }
    else if (touristOrganizationDto != null) {
      result = touristOrganizationDto.getLongitude();
    }
    return result;
  }

  public String getName() {
    String result = "";
    if (placeDto != null) {
      result = placeDto.getName();
    }
    else if (hotelDto != null) {
      result = hotelDto.getName();
    }
    else if (touristOrganizationDto != null) {
      result = touristOrganizationDto.getName();
    }
    return result;
  }

  public String getCity() {
    String result = "";
    if (placeDto != null) {
      result = placeDto.getName();
    }
    else if (hotelDto != null) {
      result = hotelDto.getCity();
    }
    else if (touristOrganizationDto != null) {
      result = touristOrganizationDto.getCity();
    }
    return result;
  }


  public String getLogoImageUrl() {
    String result = "";
    if (placeDto != null) {
      result = placeDto.getLogoImageUrl();
    }
    else if (hotelDto != null) {
      result = hotelDto.getLogoImageUrl();
    }
    else if (touristOrganizationDto != null) {
      result = touristOrganizationDto.getLogoImageUrl();
    }
    return result;
  }

  public String getTitleImageUrl() {
    String result = "";
    if (placeDto != null) {
      result = placeDto.getTitleImageUrl();
    }
    else if (hotelDto != null) {
      result = hotelDto.getTitleImageUrl();
    }
    else if (touristOrganizationDto != null) {
      result = touristOrganizationDto.getTitleImageUrl();
    }
    return result;
  }


 

















	
	
}
