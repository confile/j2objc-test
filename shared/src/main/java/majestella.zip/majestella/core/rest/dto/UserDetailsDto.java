package majestella.core.rest.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import majestella.core.prototype.json.JsonArray;
import majestella.core.prototype.json.JsonObject;
 

public class UserDetailsDto extends UserDto {

	private String email;
	private String password;
	private String gender;
	private Date birthday;
	private long birthdayString;		// This is the date string as long.

	private String facebookProfileLinkUrl;
	private String addressLine;
	private boolean validFacbookToken;
	
	
	private int errorCount;
	private List<String> errorMessages;
	
	
	public UserDetailsDto() { }

	public UserDetailsDto(UserDto userDto) {
	  setUsername(userDto.getUsername());
	  setFirstName(userDto.getFirstName());
	  setLastName(userDto.getLastName());
	  setUserImageSmallUrl(userDto.getUserImageSmallUrl());
	  setUserImageUrl(userDto.getUserImageUrl());
	  setDescription(userDto.getDescription());
	  setLastUpdatedTime(userDto.getLastUpdatedTime());
  }
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
		if (birthday != null) {
			this.birthdayString = birthday.getTime();
		}
		else {
			this.birthdayString = -1;
		}
	}

	public long getBirthdayString() {
		return birthdayString;
	}

	public void setBirthdayString(long birthdayString) {
		this.birthdayString = birthdayString;
		if (birthdayString > 0) {
			this.birthday = new Date(birthdayString);
		}
	}

	public String getFacebookProfileLinkUrl() {
		return facebookProfileLinkUrl;
	}

	public void setFacebookProfileLinkUrl(String facebookProfileLinkUrl) {
		this.facebookProfileLinkUrl = facebookProfileLinkUrl;
	}

	public String getAddressLine() {
		return addressLine;
	}

	public void setAddressLine(String addressLine) {
		this.addressLine = addressLine;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getErrorCount() {
		return errorCount;
	}

	public void setErrorCount(int errorCount) {
		this.errorCount = errorCount;
	}

	public List<String> getErrorMessages() {
		return errorMessages;
	}

	public void setErrorMessages(List<String> errorMessages) {
		this.errorMessages = errorMessages;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

  public boolean isValidFacbookToken() {
    return validFacbookToken;
  }

  public void setValidFacbookToken(boolean validFacbookToken) {
    this.validFacbookToken = validFacbookToken;
  }

  
  public static UserDetailsDto fromJsonObject(JsonObject jsonObject) {
      
    if (jsonObject == null) {
      return null;
    }
    
    UserDto userDto = UserDto.fromJsonObject(jsonObject);
    UserDetailsDto dto = new UserDetailsDto(userDto);
    
    dto.setEmail(jsonObject.getString("email"));
    dto.setPassword(jsonObject.getString("password"));
    dto.setGender(jsonObject.getString("gender"));
    dto.setBirthdayString((long)jsonObject.getDouble("birthdayString"));
    dto.setFacebookProfileLinkUrl(jsonObject.getString("facebookProfileLinkUrl"));
    dto.setAddressLine(jsonObject.getString("addressLine"));
    dto.setValidFacbookToken(jsonObject.getBoolean("validFacbookToken"));
    dto.setErrorCount((int)jsonObject.getDouble("errorCount"));
    
    JsonArray array = jsonObject.getJsonArray("errorMessages");
    final List<String> errorMessages = new ArrayList<String>();
    for(int i=0; i<array.length(); i++) {
      errorMessages.add(array.getString(i));
    }

    dto.setErrorMessages(errorMessages);
    
    return dto;
  }
   
  

	
}
