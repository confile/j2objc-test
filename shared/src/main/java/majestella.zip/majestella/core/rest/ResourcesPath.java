package majestella.core.rest;

/**
 * These are the url paths used for the REST api.
 * @author Dr. Michael Gorski
 *
 */
public final class ResourcesPath {
  
  private ResourcesPath() {}
  
	public static final String SESSION_START = "/sessionStart";
	public static final String LOCATION = "/location";
	public static final String LOCATION_LIST = "/locationList";
	public static final String SERVICE_CARD = "/serviceCard";
	public static final String ROOM_SERVICE = "/roomService";
	public static final String HOTEL_RESTAURANT = "/hotelRestaurant";
	public static final String HOTEL_SPA = "/hotelSpa";
	public static final String SERVICE_DETAILS = "/serviceDetails";
	
	
	
  // old unused
	public static final String SIGNUP = "/signup";
	public static final String SESSION = "/session";
	public static final String USER = "/user";
	public static final String USER_DETAILS = "/userdetails";
	public static final String USER_PET = "/userpet";
	public static final String ITEM = "/item";
	public static final String ITEM_DETAILS = "/itemdetails";
	public static final String FEEDBACK = "/feedback";
	public static final String LOCAL_ITEM = "/localitem";
	
	public static final String PET = "/pet";
	public static final String PET_DETAILS = "/petdetails";
	public static final String PET_FOLLOWER = "/petfollower";
	public static final String PETITEMS = "/petitems";
	public static final String PETNAME = "/petname";
	public static final String FOLLOWER = "/follower";
	public static final String FEED_ITEM = "/feeditem";
	public static final String USER_ITEM = "/useritem";
	public static final String USER_FOLLOWING = "/userfollowing";
	public static final String RATING = "/rating";
	public static final String SEARCH = "/search";
	public static final String NOTIFICATION = "/notification";
	public static final String COMMENT = "/comment";
	public static final String UPLOAD_ITEM = "/uploaditem";
	public static final String FEED_CREATE = "/feedcreate";
	public static final String PET_LATEST = "/petlatest";
	
	public static final String STICKER_LIST = "/stickerList";
	public static final String STICKER_GROUP_LIST = "/stickerGroupList";

	
	
	
}
