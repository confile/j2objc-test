package majestella.core.rest.dto;
 
import majestella.core.prototype.json.JsonObject;

public class LocationListItemDto extends BaseEntity {
 
  private static final long serialVersionUID = 2475745485729030700L;
 
  private String title;
  private String logoImageUrl;
  private int type;
  

  public LocationListItemDto() { 
	}
	
  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public String getLogoImageUrl() {
    return logoImageUrl;
  }

  public void setLogoImageUrl(String logoImageUrl) {
    this.logoImageUrl = logoImageUrl;
  }

  public int getType() {
    return type;
  }

  public void setType(int type) {
    this.type = type;
  }
   
  
  public static LocationListItemDto fromJsonObject(JsonObject jsonObject) {
    BaseEntity baseEntity = BaseEntity.fromJsonObject(jsonObject);
    LocationListItemDto dto = new LocationListItemDto();
    dto.id = baseEntity.id;
    
    dto.setTitle(jsonObject.getString("title"));
    dto.setLogoImageUrl(jsonObject.getString("logoImageUrl"));
    dto.setType((int)jsonObject.getDouble("type"));
    
    return dto;
  }






























	
	
}
