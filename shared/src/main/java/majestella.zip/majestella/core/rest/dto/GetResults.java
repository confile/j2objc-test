package majestella.core.rest.dto;

import java.util.List;

/**
 * A container class for a list of results.
 * 
 * @author Dr. Michael Gorski
 *
 * @param <T>
 */
public class GetResults<T extends Dto> {

  List<T> results;

  public GetResults() {
  }

  public GetResults(List<T> results) {
    this.results = results;
  }

  public List<T> getResults() {
    return results;
  }

  public void setResults(List<T> results) {
    this.results = results;
  }
}
