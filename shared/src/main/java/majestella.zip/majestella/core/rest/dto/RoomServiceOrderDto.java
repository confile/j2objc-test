package majestella.core.rest.dto;
 
import java.util.LinkedHashMap;
import java.util.Map;

import majestella.core.prototype.json.JsonObject;

public class RoomServiceOrderDto extends BaseEntity {

  private static final long serialVersionUID = -3200185956015244925L;
 
  
  private Map<String, Integer> itemsMap;
  

  public RoomServiceOrderDto() { 
    itemsMap = new LinkedHashMap<>();
	}
	
 
  public void addItem(String itemId, int amount) {
    itemsMap.put(itemId, amount);
  }
 

  public JsonObject toJsonObject() {
    JsonObject dto = new JsonObject();
    JsonObject jsonObject = new JsonObject();
    for (Map.Entry<String, Integer> entry : itemsMap.entrySet()) {
      jsonObject.put(entry.getKey(), entry.getValue());
    }
    dto.put("itemsMap", jsonObject);
    
    return dto;
  }
  
  
  /**
   * Converts this object into a JSON string.
   * 
   * @return
   */
  public String toJsonString() {
    return toJsonObject().toString();
  }


	
}
