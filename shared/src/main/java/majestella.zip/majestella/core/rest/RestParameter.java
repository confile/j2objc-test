package majestella.core.rest;

/**
 * This class contains the REST parameter being used.
 * @author Dr. Michael Gorski
 *
 */
public class RestParameter {

	public static final String COOKIE = "cookie"; 
	public static final String LOCALE = "locale"; 
	public static final String OFFSET = "offset"; 
	public static final String DEVICE_UUID = "deviceUUID"; 
	public static final String SERVICE_CARD_ID = "serviceCardId";
	public static final String LIKED = "liked";
	public static final String LATITUDE = "latitude";
	public static final String LONGITUDE = "longitude";
	public static final String LOCATION_TYPE = "locationType";
	public static final String LOCATION_ID = "locationId";
	public static final String AROUND_ME = "aroundMe";
	public static final String LAST_NAME = "lastName";
	public static final String ROOM_NUMBER = "roomNumber";
	public static final String DEPARTURE_DATE = "departureDate";
	public static final String REMOVED = "removed";
	
	
	
	// old unused
	public static final String ID = "id";
	public static final String PUSH_TOKEN = "pushToken";
	public static final String UUID = "uuid";

	public static final String UPLOAD_IMAGE_ID = "uploadImageId";
	public static final String FEEDBACK_TEXT = "feedbackText";
	public static final String USERNAME = "username";
	public static final String LIMIT = "limit";
	public static final String OLDEST_ITEM_TIME = "oldestItemTime";
	public static final String LATEST_POSITION = "latestPosition";
	public static final String STICKER_GROUP_ID = "stickerGroupId";
	public static final String PASSWORD = "password";
	public static final String GENDER = "gender";
	public static final String EMAIL = "email";
	public static final String FIRST_NAME = "firstName"; 
	
	
	
}
