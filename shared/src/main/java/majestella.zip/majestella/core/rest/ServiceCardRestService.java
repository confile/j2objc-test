package majestella.core.rest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

import majestella.core.network.Connection;
import majestella.core.network.Connection.ConnectionCallback;
import majestella.core.network.Connection.HTTPMethod;
import majestella.core.plugins.cookie.Cookie;
import majestella.core.prototype.json.JsonArray;
import majestella.core.prototype.json.JsonObject;
import majestella.core.prototype.mvp.proxy.BAsyncCallback;
import majestella.core.rest.dto.BooleanDto;
import majestella.core.rest.dto.DeviceDto;
import majestella.core.rest.dto.GetResult;
import majestella.core.rest.dto.GetResults;
import majestella.core.rest.dto.ServiceCardDto;
 

public class ServiceCardRestService extends AbstractRestService {


  public ServiceCardRestService(Connection connection, DeviceDto deviceDto, Cookie cookie) {
    super(connection, deviceDto, cookie);
    url += ResourcesPath.SERVICE_CARD;
  }

  public void get(int locationType, String locationId, int offset, boolean aroundMe, 
        final BAsyncCallback<GetResults<ServiceCardDto>> callback) {
    logger.info("<<< ServiceCardRestService get()");
    
    Map<String, String> params = new HashMap<>();
    params.put(RestParameter.LOCATION_ID, locationId);
    params.put(RestParameter.LOCATION_TYPE, ""+locationType);
    params.put(RestParameter.AROUND_ME, ""+aroundMe);
    params.put(RestParameter.OFFSET, ""+offset);
    params.put(RestParameter.COOKIE, cookie.getLoggedInCookie());  
    params.put(RestParameter.LOCALE, deviceDto.getLocale());
    params.put(RestParameter.DEVICE_UUID, deviceDto.getUuid());
    
    connection.request(HTTPMethod.GET, url, params, new ConnectionCallback() {

      @Override
      public void onResponse(int statusCode, String data) {
        logger.info(">>> ServiceCardRestService get(): statusCode: "+statusCode);
        if (statusCode == 200) {
          GetResults<ServiceCardDto> result = parseString(data);
          callback.onSuccess(result);
        } else {
          callback.onFailure(new Exception("Server responded with status code: " + statusCode));
        }
      }

      @Override
      public void onError(Exception ex) {
        logger.log(Level.SEVERE, "ServiceCardRestService - get(): onError(): " + ex.getMessage(), ex);
        callback.onFailure(ex);
      }
    });

  }
  
  
  GetResults<ServiceCardDto> parseString(String jsonString) {
    JsonObject jsonObj = new JsonObject(jsonString);
    JsonArray array = jsonObj.getJsonArray("results");
    
    final List<ServiceCardDto> dtos = new ArrayList<>();
    for(int i=0; i<array.length(); i++) {
      JsonObject value = array.getJsonObject(i);
      ServiceCardDto dto = ServiceCardDto.fromJsonObject(value);
      dtos.add(dto);
    }
    
    GetResults<ServiceCardDto> result = new GetResults<ServiceCardDto>();
    result.setResults(dtos);
    
    return result;
  }
 
  
  public void post(String serviceCardId, boolean liked, final BAsyncCallback<GetResult<BooleanDto>> callback) {
    post(serviceCardId, liked, false, callback);
  }
  
  public void post(String serviceCardId, boolean liked, boolean removedFromWishList, final BAsyncCallback<GetResult<BooleanDto>> callback) {
    logger.info("<<< ServiceCardRestService post()");
    
    Map<String, String> params = new HashMap<>();
    params.put(RestParameter.SERVICE_CARD_ID, serviceCardId);
    params.put(RestParameter.LIKED, ""+liked);
    params.put(RestParameter.COOKIE, cookie.getLoggedInCookie());  
    params.put(RestParameter.LOCALE, deviceDto.getLocale());
    params.put(RestParameter.DEVICE_UUID, deviceDto.getUuid());
    params.put(RestParameter.REMOVED, ""+removedFromWishList);
    
    connection.request(HTTPMethod.POST, url, params, new ConnectionCallback() {

      @Override
      public void onResponse(int statusCode, String data) {
        logger.info(">>> ServiceCardRestService post(): statusCode: "+statusCode);
        if (statusCode == 200) {
          GetResult<BooleanDto> result = parsePostResultString(data);
          callback.onSuccess(result);
        } else {
          callback.onFailure(new Exception("Server responded with status code: " + statusCode));
        }
      }

      @Override
      public void onError(Exception ex) {
        logger.log(Level.SEVERE, "ServiceCardRestService - post(): onError(): " + ex.getMessage(), ex);
        callback.onFailure(ex);
      }
    });
    
  }
  
  
  GetResult<BooleanDto> parsePostResultString(String jsonString) {
    JsonObject jsonObj = new JsonObject(jsonString);
    jsonObj = jsonObj.getJsonObject("result");
    BooleanDto dto = BooleanDto.fromJsonObject(jsonObj);
    GetResult<BooleanDto> result = new GetResult<BooleanDto>();
    result.setResult(dto);
    
    return result;
  }
  
  

}
