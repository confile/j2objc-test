package majestella.core.rest.dto;



/**
 * A container class for a single result.
 * 
 * @author Dr. Michael Gorski
 *
 * @param <T>
 */
public class GetResult<T extends Dto> {
  
  T result;

  public GetResult() {
  }

  public GetResult(T result) {
    this.result = result;
  }

  public T getResult() {
    return result;
  }

  public void setResult(T result) {
    this.result = result;
  }
 
}
