package majestella.core.dagger;

import majestella.core.app.database.AppDatabaseHelper;
import majestella.core.app.database.ServiceCardDatabaseHelper;
import majestella.core.bootstrap.CurrentUser;
import majestella.core.plugins.PluginAdapterHolder;
import majestella.core.plugins.googleAnalytics.GoogleAnalyticsNavigationTracker;
import majestella.core.prototype.navigation.BHistoryStack;
import majestella.core.rest.dto.DeviceDto;


/**
 * Helper class which is used to create eager Singleton instances. All static instances in this class will be instanciated 
 * upon startup.
 * @author Dr. Michael Gorski
 *
 */
public class EagerSingletons {

  private static BHistoryStack historyStack = ComponentHolder.get().getBHistoryStack();
  private static PluginAdapterHolder pluginAdapterHolder = ComponentHolder.get().getPluginAdapterHolder();
  private static GoogleAnalyticsNavigationTracker googleAnalyticsNavigationTracker = 
        ComponentHolder.get().getGoogleAnalyticsNavigationTracker();

  private static DeviceDto devideDto = ComponentHolder.get().getDeviceDto();
  private static CurrentUser currentUser = ComponentHolder.get().getCurrentUser();
//  private static PresenterWidgetHolder presenterWidgetHolder = ComponentHolder.get().getPresenterWidgetHolder();
//  private static UploadController uploadController = ComponentHolder.get().getUploadControllerFactory().create();
//  private static ToastDisplayController hintDisplayController = ComponentHolder.get().getToastDisplayControllerFactory().create();
//  private static SignupController signupController = ComponentHolder.get().getSignupControllerFactory().create();
  
  // database
  private static AppDatabaseHelper appDatabaseHelper = ComponentHolder.get().getAppDatabaseHelper();
//  private static UserDatabaseController userDatabaseController = ComponentHolder.get().getUserDatabaseController();
  private static ServiceCardDatabaseHelper serviceCardDatabaseHelper = ComponentHolder.get().getServiceCardDatabaseHelper();
//  private static StickerDatabaseController stickerDatabaseController = ComponentHolder.get().getStickerDatabaseController();
//  private static StickerGroupDatabaseController stickerGroupDatabaseController = ComponentHolder.get().getStickerGroupDatabaseController();
  
  
}
