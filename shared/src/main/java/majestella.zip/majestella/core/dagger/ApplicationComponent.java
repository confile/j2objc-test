package majestella.core.dagger;

import generated.ProxyModule;

import javax.inject.Singleton;

import majestella.core.app.database.AppDatabaseHelper;
import majestella.core.app.database.ServiceCardDatabaseHelper;
import majestella.core.app.hotelRestaurant.HotelRestaurantPresenterFactory;
import majestella.core.app.hotelSpa.HotelSpaPresenterFactory;
import majestella.core.app.locationInfo.LocationInfoPresenterFactory;
import majestella.core.app.locationMain.LocationMainPresenterFactory;
import majestella.core.app.locationSetting.LocationSettingPresenterFactory;
import majestella.core.app.mainNavigation.MainNavigationPresenterFactory;
import majestella.core.app.roomService.RoomServicePresenterFactory;
import majestella.core.app.roomServiceCard.RoomServiceCardPresenterFactory;
import majestella.core.app.serviceDetails.ServiceDetailsPresenterFactory;
import majestella.core.app.serviceSelection.ServiceSelectionPresenterFactory;
import majestella.core.app.setting.SettingPresenterFactory;
import majestella.core.app.start.StartPresenterFactory;
import majestella.core.app.wishList.WishListPresenterPresenterFactory;
import majestella.core.bootstrap.CurrentUser;
import majestella.core.i18n.BMessage;
import majestella.core.navigation.BRootPresenter;
import majestella.core.network.Connection;
import majestella.core.plugins.PluginAdapterHolder;
import majestella.core.plugins.appInfo.AppInfo;
import majestella.core.plugins.cookie.Cookie;
import majestella.core.plugins.database.app.AppDataService;
import majestella.core.plugins.database.serviceCard.ServiceCardDataService;
import majestella.core.plugins.googleAnalytics.GoogleAnalytics;
import majestella.core.plugins.googleAnalytics.GoogleAnalyticsNavigationTracker;
import majestella.core.plugins.inappbrowser.Inappbrowser;
import majestella.core.plugins.notification.Notification;
import majestella.core.plugins.uniqueDeviceId.UniqueDeviceId;
import majestella.core.plugins.weather.Weather;
import majestella.core.prototype.eventBus.BEventBus;
import majestella.core.prototype.navigation.BHistoryStack;
import majestella.core.prototype.navigation.BPlaceManager;
import majestella.core.prototype.navigation.BPlaceTokenRegistry;
import majestella.core.prototype.navigation.BTokenFormatter;
import majestella.core.prototype.navigation.UrlUtils;
import majestella.core.rest.HotelRestaurantRestService;
import majestella.core.rest.HotelSpaRestService;
import majestella.core.rest.LocationListRestService;
import majestella.core.rest.LocationRestService;
import majestella.core.rest.RoomServiceRestService;
import majestella.core.rest.ServiceCardRestService;
import majestella.core.rest.ServiceDetailsRestService;
import majestella.core.rest.SessionRestService;
import majestella.core.rest.SessionStartRestService;
import majestella.core.rest.SignupRestService;
import majestella.core.rest.UserRestService;
import majestella.core.rest.dto.DeviceDto;
import dagger.Component;


@Component(modules = {ApplicationModule.class, CoreModule.class, ProxyModule.class})
@Singleton
public interface ApplicationComponent {

  // rest services
  SessionStartRestService getSessionStartRestService();
  LocationListRestService getLocationRestService();
  LocationRestService getHotelRestService();
  ServiceCardRestService getHotelServiceCardRestService();
  RoomServiceRestService getRoomServiceRestService();
  HotelRestaurantRestService getHotelRestaurantRestService();
  HotelSpaRestService getHotelSpaRestService();
  ServiceDetailsRestService getServiceDetailsRestService();
  
 
  // old Rest still unused
  SessionRestService getSessionRestService();
  SignupRestService getSignupRestService();
  UserRestService getUserRestService();
  
  
  BPlaceManager getBPlaceManager();
  
  BEventBus getEventBus();
  
  Connection getConnection();
  
  BTokenFormatter getBTokenFormatter();
  
  UrlUtils getUrlUtils();
 
  BRootPresenter getBRootPresenter();
  
  BHistoryStack getBHistoryStack();
  
  PluginAdapterHolder getPluginAdapterHolder();
  
//  CameraManager getCameraManager();
  
  BMessage getMessage();
  
  DeviceDto getDeviceDto();
  
  CurrentUser getCurrentUser();
   
  BPlaceTokenRegistry getPlaceTokenRegistry();
  
  GoogleAnalyticsNavigationTracker getGoogleAnalyticsNavigationTracker();
 
//  ItemServerConnection getItemServerConnection();
//  StickerGroupServerConnection getStickerGroupServerConnection();
//  StickerServerConnection getStickerServerConnection();
//  
//  ItemDatabaseConnection getItemDatabaseConnection();
//  StickerDatabaseConnection getStickerDatabaseConnection();
//  StickerGroupDatabaseConnection getStickerGroupDatabaseConnection();
//  
//  ItemDatabaseController getItemDatabaseController();
//  StickerDatabaseController getStickerDatabaseController();
//  StickerGroupDatabaseController getStickerGroupDatabaseController();
//  UserDatabaseController getUserDatabaseController();
  
  
 
  
  // Presenter

  StartPresenterFactory getStartPresenterFactory();
  MainNavigationPresenterFactory getMainNavigationPresenterFactory();
  ServiceSelectionPresenterFactory getServiceSelectionPresenterFactory();
  LocationMainPresenterFactory getLocationMainPresenterFactory();
  WishListPresenterPresenterFactory getWishListPresenterPresenterFactory();
  LocationSettingPresenterFactory getLocationSettingPresenterFactory();
  LocationInfoPresenterFactory getLocationInfoPresenterFactory();
  ServiceDetailsPresenterFactory getServiceDetailsPresenterFactory();
  RoomServicePresenterFactory getRoomServicePresenterFactory();
  RoomServiceCardPresenterFactory getRoomServiceCardPresenterFactory();
  HotelRestaurantPresenterFactory getHotelRestaurantPresenterFactory();
  HotelSpaPresenterFactory getHotelSpaPresenterFactory();
  SettingPresenterFactory getSettingPresenterFactory();
  
  
  // database
  
  AppDataService getAppDataService();
  AppDatabaseHelper getAppDatabaseHelper();
  
  ServiceCardDataService getServiceCardDataService();
  ServiceCardDatabaseHelper getServiceCardDatabaseHelper();
  
  
  // plugins
  
//  ActionSheet getActionSheet();
//  
//  AppAvailability getAppAvailability();
  
 
//  BCamera getBCamera();
//  
//  Canvas2Image getCanvas2Image();
//  
  Cookie getCookie();
//  
//  EmailComposer getEmailComposer();
//  
  Inappbrowser getInappbrowser();
//  
//  Instagram getInstagram();
//  
//  Keyboard getKeyboard();
//  
//  Push getPush();
//  
//  SocialSharing getSocialSharing();
//  
//  StatusBar getStatusBar();
//  
  UniqueDeviceId getUniqueDeviceId();
//  
  GoogleAnalytics getGoogleAnalytics();
//  
//  Facebook getFacebook();
//   
//  SystemConfig getSystemConfig();
//  
  Notification getNotification();
//  
//  Spinner getSpinner();
// 
//  CameraFallback getCameraFallback();
//  
//  PhotoEditor getPhotoEditor();
//  
//  FileUpload getFileUpload();
//
//  ToastPlugin getToastPlugin();
//  
//  DeviceEvents getDeviceEvents();
  
  Weather getWeather();
  
  AppInfo getAppInfo();
  
}
