package majestella.core.dagger;

import javax.inject.Singleton;

import majestella.core.app.database.AppDatabaseHelper;
import majestella.core.app.database.ServiceCardDatabaseHelper;
import majestella.core.bootstrap.CurrentUser;
import majestella.core.i18n.BMessage;
import majestella.core.i18n.MessageImpl;
import majestella.core.navigation.BRootPresenter;
import majestella.core.navigation.BRootPresenterImpl;
import majestella.core.plugins.PluginAdapterHolder;
import majestella.core.plugins.appInfo.AppInfo;
import majestella.core.plugins.appInfo.AppInfoImpl;
import majestella.core.plugins.cookie.Cookie;
import majestella.core.plugins.cookie.CookieImpl;
import majestella.core.plugins.database.app.AppDataService;
import majestella.core.plugins.database.app.AppDataServiceImpl;
import majestella.core.plugins.database.serviceCard.ServiceCardDataService;
import majestella.core.plugins.database.serviceCard.ServiceCardDataServiceImpl;
import majestella.core.plugins.display.DisplayRoot;
import majestella.core.plugins.display.DisplayRootImpl;
import majestella.core.plugins.email.EmailComposer;
import majestella.core.plugins.email.EmailComposerImpl;
import majestella.core.plugins.googleAnalytics.GoogleAnalytics;
import majestella.core.plugins.googleAnalytics.GoogleAnalyticsImpl;
import majestella.core.plugins.googleAnalytics.GoogleAnalyticsNavigationTracker;
import majestella.core.plugins.inappbrowser.Inappbrowser;
import majestella.core.plugins.inappbrowser.InappbrowserImpl;
import majestella.core.plugins.notification.Notification;
import majestella.core.plugins.notification.NotificationImpl;
import majestella.core.plugins.spinner.Spinner;
import majestella.core.plugins.spinner.SpinnerImpl;
import majestella.core.plugins.systemConfig.SystemConfig;
import majestella.core.plugins.systemConfig.SystemConfigImpl;
import majestella.core.plugins.uniqueDeviceId.UniqueDeviceId;
import majestella.core.plugins.uniqueDeviceId.UniqueDeviceIdImpl;
import majestella.core.plugins.weather.Weather;
import majestella.core.plugins.weather.WeatherImpl;
import majestella.core.prototype.eventBus.BEventBus;
import majestella.core.prototype.navigation.BHistoryStack;
import majestella.core.prototype.navigation.BHistoryStackImpl;
import majestella.core.prototype.navigation.BPlaceManager;
import majestella.core.prototype.navigation.BPlaceManagerImpl;
import majestella.core.prototype.navigation.BPlaceTokenRegistry;
import majestella.core.prototype.navigation.BRouteTokenFormatter;
import majestella.core.prototype.navigation.BTokenFormatter;
import majestella.core.prototype.navigation.ClientUrlUtils;
import majestella.core.prototype.navigation.UrlUtils;
import majestella.core.rest.dto.DeviceDto;
import dagger.Lazy;
import dagger.Module;
import dagger.Provides;

// staticInjections = AppStarter.class
@Module()
public class CoreModule {

  @Provides @Singleton
  BTokenFormatter provideBTokenFormatter(UrlUtils urlUtils, BPlaceTokenRegistry tokenRegistry) {
    return new BRouteTokenFormatter(urlUtils, tokenRegistry);
  }
  
  @Provides @Singleton
  UrlUtils provideUrlUtils() {
    return new ClientUrlUtils();
  }  
  
  @Provides @Singleton
  BPlaceManager provideBSimplePlaceManager(BEventBus eventBus, BTokenFormatter tokenFormatter) {
    return new BPlaceManagerImpl(eventBus, tokenFormatter);
  }
  
  @Provides @Singleton
  BRootPresenter provideBRootPresenter(BEventBus eventBus, BHistoryStack historyStack, BPlaceManager placeManager, 
      Lazy<DisplayRoot> lazyDisplayRoot) {
    return new BRootPresenterImpl(eventBus, historyStack, placeManager, lazyDisplayRoot);
  }
  
  @Provides @Singleton
  BHistoryStack provideBHistoryStack(BEventBus eventBus, BTokenFormatter tokenFormatter, BPlaceManager placeManager) {
    return new BHistoryStackImpl(eventBus, tokenFormatter, placeManager);
  }
  
  @Provides @Singleton
  BMessage provideMessage() {
    return new MessageImpl();
  }  
  
  @Provides @Singleton
  DeviceDto provideDeviceDto() {
    return new DeviceDto();
  }  
  
  @Provides @Singleton
  CurrentUser provideCurrentUser() {
    return new CurrentUser();
  }  
  
  @Provides @Singleton
  PluginAdapterHolder providePluginAdapterHolder() {
    return new PluginAdapterHolder();
  }  

  @Provides @Singleton
  DisplayRoot provideDisplayRoot(PluginAdapterHolder pluginAdapterHolder) {
    return new DisplayRootImpl(pluginAdapterHolder);
  } 
  
  @Provides @Singleton Lazy<DisplayRoot> provideLazyDisplayRoot(Lazy<DisplayRoot> lazy) {
    return lazy;
  } 
  

  
  // plugins
  
  @Provides @Singleton
  GoogleAnalyticsNavigationTracker provideGoogleAnalyticsNavigationTracker(BEventBus eventBus, BPlaceManager placeManager, 
      GoogleAnalytics googleAnalytics) {
    return new GoogleAnalyticsNavigationTracker(eventBus, placeManager, googleAnalytics);
  }
    
//  @Provides @Singleton
//  ActionSheet provideLazyActionSheet(PluginAdapterHolder pluginAdapterHolder) {
//    return new ActionSheetImpl(pluginAdapterHolder);
//  } 
//  
//  @Provides @Singleton Lazy<ActionSheet> provideActionSheet(Lazy<ActionSheet> lazy) {
//    return lazy;
//  }
//  
//  @Provides @Singleton
//  AppAvailability provideAppAvailability(PluginAdapterHolder pluginAdapterHolder) {
//    return new AppAvailabilityImpl(pluginAdapterHolder);
//  } 
//  
//  @Provides @Singleton Lazy<AppAvailability> provideLazyAppAvailability(Lazy<AppAvailability> lazy) {
//    return lazy;
//  }
//  
 
  
//  @Provides @Singleton
//  BCamera provideBCamera(PluginAdapterHolder pluginAdapterHolder) {
//    return new BCameraImpl(pluginAdapterHolder);
//  } 
//  
//  @Provides @Singleton
//  Canvas2Image provideCanvas2Image(PluginAdapterHolder pluginAdapterHolder) {
//    return new Canvas2ImageImpl(pluginAdapterHolder);
//  } 
//  
//  @Provides @Singleton Lazy<Canvas2Image> provideLazyCanvas2Image(Lazy<Canvas2Image> lazy) {
//    return lazy;
//  }
//  
  @Provides @Singleton
  Cookie provideCookie(PluginAdapterHolder pluginAdapterHolder) {
    return new CookieImpl(pluginAdapterHolder);
  } 
  
  @Provides @Singleton Lazy<Cookie> provideLazyCookie(Lazy<Cookie> lazy) {
    return lazy;
  }
  
  @Provides @Singleton
  Weather provideWeather(PluginAdapterHolder pluginAdapterHolder) {
    return new WeatherImpl(pluginAdapterHolder);
  } 
  
  @Provides @Singleton Lazy<Weather> provideLazyWeather(Lazy<Weather> lazy) {
    return lazy;
  } 
  
  @Provides @Singleton
  AppInfo provideAppInfo(PluginAdapterHolder pluginAdapterHolder) {
    return new AppInfoImpl(pluginAdapterHolder);
  } 
  
  @Provides @Singleton Lazy<AppInfo> provideLazyAppInfo(Lazy<AppInfo> lazy) {
    return lazy;
  } 
  
  
  
  @Provides @Singleton
  EmailComposer provideEmailComposer(PluginAdapterHolder pluginAdapterHolder) {
    return new EmailComposerImpl(pluginAdapterHolder);
  } 
  
  @Provides @Singleton Lazy<EmailComposer> provideLazyEmailComposer(Lazy<EmailComposer> lazy) {
    return lazy;
  }
  
  @Provides @Singleton
  Inappbrowser provideInappbrowser(PluginAdapterHolder pluginAdapterHolder) {
    return new InappbrowserImpl(pluginAdapterHolder);
  } 
  
  @Provides @Singleton Lazy<Inappbrowser> provideLazyInappbrowser(Lazy<Inappbrowser> lazy) {
    return lazy;
  }
//  
//  @Provides @Singleton
//  Instagram provideInstagram(PluginAdapterHolder pluginAdapterHolder) {
//    return new InstagramImpl(pluginAdapterHolder);
//  } 
//  
//  @Provides @Singleton Lazy<Instagram> provideLazyInstagram(Lazy<Instagram> lazy) {
//    return lazy;
//  }
//  
//  @Provides @Singleton
//  Keyboard provideKeyboard(PluginAdapterHolder pluginAdapterHolder) {
//    return new KeyboardImpl(pluginAdapterHolder);
//  } 
//  
//  @Provides @Singleton Lazy<Keyboard> provideLazyKeyboard(Lazy<Keyboard> lazy) {
//    return lazy;
//  }
//  
//  @Provides @Singleton
//  Push providePush(PluginAdapterHolder pluginAdapterHolder) {
//    return new PushImpl(pluginAdapterHolder);
//  } 
//  
//  @Provides @Singleton
//  SocialSharing provideSocialSharing(PluginAdapterHolder pluginAdapterHolder) {
//    return new SocialSharingImpl(pluginAdapterHolder);
//  } 
//  
//  @Provides @Singleton Lazy<SocialSharing> provideLazySocialSharing(Lazy<SocialSharing> lazy) {
//    return lazy;
//  }
//  
//  @Provides @Singleton
//  StatusBar provideStatusBar(PluginAdapterHolder pluginAdapterHolder) {
//    return new StatusBarImpl(pluginAdapterHolder);
//  } 
//  
//  @Provides @Singleton Lazy<StatusBar> provideLazyStatusBar(Lazy<StatusBar> lazy) {
//    return lazy;
//  }
  
  @Provides @Singleton
  UniqueDeviceId provideUniqueDeviceId(PluginAdapterHolder pluginAdapterHolder) {
    return new UniqueDeviceIdImpl(pluginAdapterHolder);
  }   
  
  @Provides @Singleton
  GoogleAnalytics provideGoogleAnalytics(PluginAdapterHolder pluginAdapterHolder) {
    return new GoogleAnalyticsImpl(pluginAdapterHolder);
  } 
  
  @Provides @Singleton Lazy<GoogleAnalytics> provideLazyGoogleAnalytics(Lazy<GoogleAnalytics> lazy) {
    return lazy;
  }
  
//  @Provides @Singleton
//  Facebook provideFacebook(PluginAdapterHolder pluginAdapterHolder) {
//    return new FacebookImpl(pluginAdapterHolder);
//  } 
//  
//  @Provides @Singleton Lazy<Facebook> provideLazyFacebook(Lazy<Facebook> lazy) {
//    return lazy;
//  }
//  
//  @Provides @Singleton
//  DeviceEvents provideDeviceEvents(PluginAdapterHolder pluginAdapterHolder) {
//    return new DeviceEventsImpl(pluginAdapterHolder);
//  }  
  
  @Provides @Singleton
  SystemConfig provideSystemConfig(PluginAdapterHolder pluginAdapterHolder) {
    return new SystemConfigImpl(pluginAdapterHolder);
  } 
  
  @Provides @Singleton Lazy<SystemConfig> provideLazySystemConfig(Lazy<SystemConfig> lazy) {
    return lazy;
  }

  @Provides @Singleton
  Notification provideNotification(PluginAdapterHolder pluginAdapterHolder) {
    return new NotificationImpl(pluginAdapterHolder);
  } 
    
  @Provides @Singleton Lazy<Notification> provideLazyNotification(Lazy<Notification> lazy) {
    return lazy;
  }

  @Provides @Singleton
  Spinner provideSpinner(PluginAdapterHolder pluginAdapterHolder) {
    return new SpinnerImpl(pluginAdapterHolder);
  } 
  
  @Provides @Singleton Lazy<Spinner> provideLazySpinner(Lazy<Spinner> lazy) {
    return lazy;
  }
  
//  @Provides @Singleton
//  CameraFallback provideCameraFallback(PluginAdapterHolder pluginAdapterHolder) {
//    return new CameraFallbackImpl(pluginAdapterHolder);
//  } 
//  
//  @Provides @Singleton
//  PhotoEditor providePhotoEditor(PluginAdapterHolder pluginAdapterHolder) {
//    return new PhotoEditorImpl(pluginAdapterHolder);
//  } 
//  
//  @Provides @Singleton Lazy<PhotoEditor> provideLazyPhotoEditor(Lazy<PhotoEditor> lazy) {
//    return lazy;
//  }
//  
//  @Provides @Singleton
//  FileUpload provideFileUpload(PluginAdapterHolder pluginAdapterHolder) {
//    return new FileUploadImpl(pluginAdapterHolder);
//  } 
//  
//  @Provides @Singleton Lazy<FileUpload> provideLazyFileUpload(Lazy<FileUpload> lazy) {
//    return lazy;
//  }
//  
//  @Provides @Singleton
//  ToastPlugin provideToastPlugin(PluginAdapterHolder pluginAdapterHolder) {
//    return new ToastPluginImpl(pluginAdapterHolder);
//  } 
//  
//  @Provides @Singleton Lazy<ToastPlugin> provideLazyToastPlugin(Lazy<ToastPlugin> lazy) {
//    return lazy;
//  }  
//  
//  @Provides @Singleton
//  ItemDataService provideItemDataService(PluginAdapterHolder pluginAdapterHolder) {
//    return new ItemDataServiceImpl(pluginAdapterHolder);
//  }
//  
//  @Provides @Singleton
//  StickerDataService provideStickerDataService(PluginAdapterHolder pluginAdapterHolder) {
//    return new StickerDataServiceImpl(pluginAdapterHolder);
//  }
//  
//  @Provides @Singleton
//  StickerGroupDataService provideStickerGroupDataService(PluginAdapterHolder pluginAdapterHolder) {
//    return new StickerGroupDataServiceImpl(pluginAdapterHolder);
//  }
//  

  
//  @Provides @Singleton
//  UserDataService provideUserDataService(PluginAdapterHolder pluginAdapterHolder) {
//    return new UserDataServiceImpl(pluginAdapterHolder);
//  }
//  
 
  
  

  // database
  
  @Provides @Singleton
  AppDataService provideAppDataService(PluginAdapterHolder pluginAdapterHolder) {
    return new AppDataServiceImpl(pluginAdapterHolder);
  }
  
  @Provides @Singleton Lazy<AppDataService> provideLazyAppDataService(Lazy<AppDataService> lazy) {
    return lazy;
  }
  
  @Provides @Singleton
  AppDatabaseHelper provideAppDatabaseHelper(Lazy<AppDataService> lazyAppDataService) {
    return new AppDatabaseHelper(lazyAppDataService);
  } 
   
  
  @Provides @Singleton
  ServiceCardDataService provideServiceCardDataService(PluginAdapterHolder pluginAdapterHolder) {
    return new ServiceCardDataServiceImpl(pluginAdapterHolder);
  }
    
  @Provides @Singleton Lazy<ServiceCardDataService> provideLazyServiceCardDataService(Lazy<ServiceCardDataService> lazy) {
    return lazy;
  }
  
  @Provides @Singleton
  ServiceCardDatabaseHelper provideServiceCardDatabaseHelper(Lazy<ServiceCardDataService> lazyServiceCardDataService, 
      BEventBus eventBus) {
    return new ServiceCardDatabaseHelper(lazyServiceCardDataService, eventBus);
  } 
 
  
}
