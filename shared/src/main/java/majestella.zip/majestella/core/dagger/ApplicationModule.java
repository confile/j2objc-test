package majestella.core.dagger;

import javax.inject.Singleton;

import majestella.core.network.Connection;
import majestella.core.network.ConnectionImpl;
import majestella.core.plugins.cookie.Cookie;
import majestella.core.prototype.eventBus.BEventBus;
import majestella.core.prototype.eventBus.BSimpleEventBus;
import majestella.core.rest.HotelRestaurantRestService;
import majestella.core.rest.HotelSpaRestService;
import majestella.core.rest.LocationListRestService;
import majestella.core.rest.LocationRestService;
import majestella.core.rest.RoomServiceRestService;
import majestella.core.rest.ServiceCardRestService;
import majestella.core.rest.ServiceDetailsRestService;
import majestella.core.rest.SessionRestService;
import majestella.core.rest.SessionStartRestService;
import majestella.core.rest.SignupRestService;
import majestella.core.rest.UserRestService;
import majestella.core.rest.dto.DeviceDto;
import dagger.Lazy;
import dagger.Module;
import dagger.Provides;

@Module
public class ApplicationModule {

  @Provides @Singleton
  BEventBus provideBEventBus() {
    return new BSimpleEventBus();
  }
  
    
  @Provides @Singleton
  Connection provideConnection() {
    return new ConnectionImpl();
  }
  
  
  // REST services
  
  @Provides @Singleton
  SessionStartRestService provideSessionStartRestService(Connection connection, DeviceDto deviceDto, Cookie cookie) {
    return new SessionStartRestService(connection, deviceDto, cookie);
  }
  
  @Provides @Singleton
  LocationListRestService provideLocationRestService(Connection connection, DeviceDto deviceDto, Cookie cookie) {
    return new LocationListRestService(connection, deviceDto, cookie);
  }
  
  @Provides @Singleton Lazy<LocationListRestService> provideLazyLocationRestService(Lazy<LocationListRestService> lazy) {
    return lazy;
  } 
    
  @Provides @Singleton
  LocationRestService provideHotelRestService(Connection connection, DeviceDto deviceDto, Cookie cookie) {
    return new LocationRestService(connection, deviceDto, cookie);
  }
  
  @Provides @Singleton Lazy<LocationRestService> provideLazyHotelRestService(Lazy<LocationRestService> lazy) {
    return lazy;
  } 
  
  @Provides @Singleton
  ServiceCardRestService provideHotelServiceCardRestService(Connection connection, DeviceDto deviceDto, Cookie cookie) {
    return new ServiceCardRestService(connection, deviceDto, cookie);
  }
  
  @Provides @Singleton Lazy<ServiceCardRestService> provideLazyHotelServiceCardRestService(
      Lazy<ServiceCardRestService> lazy) {
    return lazy;
  } 
  
  @Provides @Singleton
  RoomServiceRestService provideRoomServiceRestService(Connection connection, DeviceDto deviceDto, Cookie cookie) {
    return new RoomServiceRestService(connection, deviceDto, cookie);
  }
  
  @Provides @Singleton Lazy<RoomServiceRestService> provideLazyRoomServiceRestService(
      Lazy<RoomServiceRestService> lazy) {
    return lazy;
  } 
  
  @Provides @Singleton
  HotelRestaurantRestService provideHotelRestaurantRestService(Connection connection, DeviceDto deviceDto, Cookie cookie) {
    return new HotelRestaurantRestService(connection, deviceDto, cookie);
  }
  
  @Provides @Singleton Lazy<HotelRestaurantRestService> provideLazyHotelRestaurantRestService(
      Lazy<HotelRestaurantRestService> lazy) {
    return lazy;
  } 
  
  @Provides @Singleton
  HotelSpaRestService provideHotelSpaRestService(Connection connection, DeviceDto deviceDto, Cookie cookie) {
    return new HotelSpaRestService(connection, deviceDto, cookie);
  }
  
  @Provides @Singleton Lazy<HotelSpaRestService> provideLazyHotelSpaRestService(
      Lazy<HotelSpaRestService> lazy) {
    return lazy;
  } 
    
  @Provides @Singleton
  ServiceDetailsRestService provideServiceDetailsRestService(Connection connection, DeviceDto deviceDto, Cookie cookie) {
    return new ServiceDetailsRestService(connection, deviceDto, cookie);
  }
  
  @Provides @Singleton Lazy<ServiceDetailsRestService> provideLazyServiceDetailsRestService(
      Lazy<ServiceDetailsRestService> lazy) {
    return lazy;
  } 
  
  
  // old REST still unuesd
  
  @Provides @Singleton
  SessionRestService provideSessionRestService(Connection connection, DeviceDto deviceDto, Cookie cookie) {
    return new SessionRestService(connection, deviceDto, cookie);
  }
  
  @Provides @Singleton Lazy<SessionRestService> provideLazySessionRestService(Lazy<SessionRestService> lazy) {
    return lazy;
  }
 
  @Provides @Singleton
  SignupRestService provideSignupRestService(Connection connection, DeviceDto deviceDto, Cookie cookie) {
    return new SignupRestService(connection, deviceDto, cookie);
  }
  
  @Provides @Singleton Lazy<SignupRestService> provideLazySignupRestService(Lazy<SignupRestService> lazy) {
    return lazy;
  }
  
  @Provides @Singleton
  UserRestService provideUserRestService(Connection connection, DeviceDto deviceDto, Cookie cookie) {
    return new UserRestService(connection, deviceDto, cookie);
  }
  
  

  
  
}
