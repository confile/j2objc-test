package majestella.core.dagger;

/**
 * This class is used to guarantee that there is only one ApplicationComponent available.
 * @author Dr. Michael Gorski
 *
 */
public final class ComponentHolder {

  private static ApplicationComponent injector = DaggerApplicationComponent.create();
  
  private ComponentHolder() {
  }
  
  public static ApplicationComponent get() {
    return injector;
  }
  
}
